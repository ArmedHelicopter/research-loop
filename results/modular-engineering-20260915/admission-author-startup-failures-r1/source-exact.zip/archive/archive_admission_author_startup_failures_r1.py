"""Archive two closed admission-author startup failures without retrying either attempt."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

BASE = Path(r"E:\_ryanDev\AI\research-loop-modular")
WORK = BASE / "work"
RESULT = BASE / "results" / "modular-engineering-20260915" / "admission-author-startup-failures-r1"
PRIVATE_RESULT = BASE / "retained-private-evidence" / "admission-author-startup-failures-r1"
FIRST = WORK / "actual-admission-author-before-read-path-repair-r1"
PREP = WORK / "actual-admission-prediction-exploration-grok130-preparation-r1"
PRIVATE = BASE / "custody-private" / "actual-admission-prediction-exploration-grok130-r1"
CURRENT_HELPER = WORK / "run_actual_admission_prediction_exploration_grok130_r1.py"
CURRENT_DESCRIPTOR = WORK / "actual_admission_prediction_exploration_evaluator_descriptor_r1.json"
REPAIR = WORK / "actual-admission-author-read-path-repair-r1.json"
R1_LOG = WORK / "actual-admission-prediction-exploration-grok130-author-r1.log"
R1_START = WORK / "actual-admission-prediction-exploration-grok130-author-r1-native-start.json"
R1_JOIN = WORK / "actual-admission-prediction-exploration-grok130-author-r1-native-join.json"
R2_LOG = WORK / "actual-admission-prediction-exploration-grok130-author-r2.log"
R2_START = WORK / "actual-admission-prediction-exploration-grok130-author-r2-native-start.json"
R2_JOIN = WORK / "actual-admission-prediction-exploration-grok130-author-r2-native-join.json"
COMMIT = "43ccf107186f730884e64c230d3abe4bfa555d65"


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def excluded(path: Path) -> bool:
    name = path.name.lower()
    return name == "auth.json" or path.suffix.lower() == ".key" or any(word in name for word in ("credential", "secret", "authority"))


def files(root: Path):
    for current, dirs, names in os.walk(root):
        here = Path(current)
        safe = []
        for name in dirs:
            candidate = here / name
            attrs = os.stat(candidate, follow_symlinks=False).st_file_attributes
            if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
                raise RuntimeError("reparse path is not archivable: " + str(candidate))
            safe.append(name)
        dirs[:] = safe
        for name in names:
            path = here / name
            attrs = os.stat(path, follow_symlinks=False).st_file_attributes
            if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
                raise RuntimeError("reparse file is not archivable: " + str(path))
            yield path


def record(path: Path, category: str) -> dict:
    raw = path.read_bytes(); info = path.stat()
    return {"source_path": str(path), "category": category, "sha256": digest(raw), "byte_count": len(raw), "mtime_ns": info.st_mtime_ns,
            "excluded_from_retained_bytes": excluded(path)}


def snapshot() -> dict[str, dict]:
    sources = [(FIRST, "first-preserved"), (PREP, "r1-preparation"), (PRIVATE, "r1-private"),
        (CURRENT_HELPER, "current-r1-helper"), (CURRENT_DESCRIPTOR, "current-r1-descriptor"), (REPAIR, "repair-receipt"),
        (R1_LOG, "r1-log"), (R1_START, "r1-start"), (R1_JOIN, "r1-join"), (R2_LOG, "r2-log"), (R2_START, "r2-start"), (R2_JOIN, "r2-join")]
    result = {}
    for path, category in sources:
        if path.is_dir():
            for item in files(path): result[str(item)] = record(item, category)
        elif path.is_file(): result[str(path)] = record(path, category)
        else: raise RuntimeError("required immutable input missing: " + str(path))
    return result


def check_inputs(before: dict[str, dict]) -> dict:
    first_helper = FIRST / CURRENT_HELPER.name
    first_descriptor = FIRST / CURRENT_DESCRIPTOR.name
    if not first_helper.is_file() or not first_descriptor.is_file(): raise RuntimeError("preserved first helper/descriptor missing")
    if not before[str(first_helper)]["sha256"].startswith("0f880dff"): raise RuntimeError("unexpected first helper identity")
    if before[str(CURRENT_HELPER)]["sha256"] != "0d89f781aefffb67bc35b89a903318c4669b28850370f5346b66c8a60b7f6fec": raise RuntimeError("unexpected repaired r1 helper")
    if before[str(CURRENT_DESCRIPTOR)]["sha256"] != "3049074a2d6582ee73cee652e69abcf87f07786841ec687ae46dd05ba5c1900b": raise RuntimeError("unexpected repaired r1 descriptor")
    joins = ((9492, R1_START, R1_JOIN, R1_LOG, "AttributeError"), (18237, R2_START, R2_JOIN, R2_LOG, "ContractError"))
    failures = []
    for session, start, join, log, error in joins:
        opened, closed = json.loads(start.read_bytes()), json.loads(join.read_bytes())
        if opened.get("session_id") != session or closed.get("native_session_id") != session or closed.get("source_commit") != COMMIT or closed.get("result", {}).get("exit_code") != 1:
            raise RuntimeError("closed native attempt mismatch")
        if error not in log.read_text(encoding="utf-8"):
            raise RuntimeError("expected startup failure category missing")
        failures.append({"native_session_id":session, "exit_code":1, "error_category":error, "main_dispatched":False})
    repair = json.loads(REPAIR.read_bytes())
    if repair.get("real_model_calls") != 0 or repair.get("validation_opened") is not False or repair.get("helper_sha256") != before[str(CURRENT_HELPER)]["sha256"]:
        raise RuntimeError("repair receipt does not retain zero-call r1 state")
    if (PREP / "authoring-bundle.json").exists() or (PRIVATE / "author-model" / "ledger.json").exists() or (WORK / "actual-admission-prediction-exploration-grok130-run-r1").exists():
        raise RuntimeError("startup-only scope violated by MAIN or RUN evidence")
    return {"failures": failures, "first_helper_sha256": before[str(first_helper)]["sha256"], "first_descriptor_sha256": before[str(first_descriptor)]["sha256"]}


def write_zip(path: Path, rows: list[tuple[str, Path]]) -> list[dict]:
    members = []
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, source in rows:
            raw = source.read_bytes(); archive.writestr(name, raw)
            members.append({"path":name, "source_path":str(source), "sha256":digest(raw), "byte_count":len(raw), "mtime_ns":source.stat().st_mtime_ns})
    return members


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--archive", action="store_true")
    args = parser.parse_args(); before = snapshot(); checked = check_inputs(before)
    if not args.archive:
        print(json.dumps({"self_check":True, "input_file_count":len(before), "failure_count":len(checked["failures"]), "outputs_exist":RESULT.exists() or PRIVATE_RESULT.exists()}, sort_keys=True)); return 0
    if RESULT.exists() or PRIVATE_RESULT.exists(): raise RuntimeError("archive output already exists")
    RESULT.mkdir(parents=True); PRIVATE_RESULT.parent.mkdir(parents=True, exist_ok=True); PRIVATE_RESULT.mkdir()
    source_rows = [("first/" + CURRENT_HELPER.name, FIRST / CURRENT_HELPER.name), ("first/" + CURRENT_DESCRIPTOR.name, FIRST / CURRENT_DESCRIPTOR.name),
                   ("current/" + CURRENT_HELPER.name, CURRENT_HELPER), ("current/" + CURRENT_DESCRIPTOR.name, CURRENT_DESCRIPTOR), ("archive/" + Path(__file__).name, Path(__file__))]
    source_members = write_zip(RESULT / "source-exact.zip", source_rows)
    public_rows = [("native/r1-start.json", R1_START), ("native/r1-join.json", R1_JOIN), ("native/r2-start.json", R2_START), ("native/r2-join.json", R2_JOIN),
                   ("logs/r1.log", R1_LOG), ("logs/r2.log", R2_LOG), ("repair/receipt.json", REPAIR)]
    public_members = write_zip(RESULT / "public-metadata.zip", public_rows)
    retained = []
    for root, prefix in ((PREP, "preparation"), (PRIVATE, "private")):
        for path in files(root):
            if not excluded(path.relative_to(root)): retained.append((prefix + "/" + path.relative_to(root).as_posix(), path))
    private_members = write_zip(PRIVATE_RESULT / "retained-private-raw.zip", retained)
    after = snapshot()
    if before != after: raise RuntimeError("immutable input bytes or mtimes changed during archival")
    excluded_rows = [row for row in before.values() if row["excluded_from_retained_bytes"]]
    manifest = {"schema":"admission-author-startup-failures-archive-r1", "attempts":checked["failures"], "source_commit":COMMIT,
        "scope":{"two_closed_startup_failures_only":True,"actual_main_calls":0,"authoring_allocation_opportunities":2,"authoring_allocation_spent":0,"additional_paid_api_budget":0,"validation_opened":False,"run_r1_created":False,"gates_completed":"not_claimed","scientific_effectiveness":"not_measured"},
        "first_preserved_source":{"helper_sha256":checked["first_helper_sha256"],"descriptor_sha256":checked["first_descriptor_sha256"]},
        "original_files_before":before,"original_files_after":after,"credential_exclusions":excluded_rows,
        "archives":{"source-exact.zip":digest((RESULT/"source-exact.zip").read_bytes()),"public-metadata.zip":digest((RESULT/"public-metadata.zip").read_bytes()),"retained-private-raw.zip":digest((PRIVATE_RESULT/"retained-private-raw.zip").read_bytes())},
        "source_members":source_members,"public_members":public_members,"retained_private_members":private_members}
    (RESULT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"archive_root":str(RESULT),"private_archive_root":str(PRIVATE_RESULT),"input_file_count":len(before),"public_member_count":len(public_members),"private_member_count":len(private_members),"failure_count":len(checked["failures"]),"manifest_sha256":digest((RESULT/"manifest.json").read_bytes())},sort_keys=True)); return 0

if __name__ == "__main__": raise SystemExit(main())
