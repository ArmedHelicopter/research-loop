import json,sys
def value(s):
 t=s.get("type")
 if t=="object": return {k:value(v) for k,v in s.get("properties",{}).items() if k in s.get("required",[])}
 if t=="boolean": return True
 if t=="integer": return 0
 if t=="number": return 0.0
 if t=="array": return []
 return "synthetic"
if sys.argv[1]=="inspect":
 print(json.dumps({**{k:[] for k in ("skills","hooks","plugins","mcpServers","projectInstructions")},"loginPolicy":{"apiKeyAuthDisabled":True},"workflowGuide":None,"memoryDigest":None}))
else:
 session,prompt,schema=sys.argv[1:4]; answer=value(json.loads(schema)); usage={"input_tokens":"unavailable","cache_read_input_tokens":0,"cache_creation_input_tokens":0,"output_tokens":2,"reasoning_tokens":0}
 for row in ([{"type":"available_commands","tools":[],"commands":[]}] * 3 + [{"type":"text","data":json.dumps(answer)},{"type":"usage","usage":usage,"signature":"synthetic"},{"type":"end","stopReason":"end_turn","sessionId":session,"requestId":"synthetic-"+session,"usage":usage|{"total_tokens":10},"num_turns":1,"modelUsage":{"grok-4.6":{"inputTokens":8,"outputTokens":2,"cacheReadInputTokens":0,"cacheCreationInputTokens":0,"modelCalls":1}},"structuredOutput":answer}]): print(json.dumps(row),flush=True)
