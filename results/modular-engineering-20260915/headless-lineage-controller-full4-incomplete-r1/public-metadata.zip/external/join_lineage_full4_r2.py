"""Retain the same full4 process through its final verification; no restart or termination."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time

PID = 54260
CREATED_AT = '2026-09-15T02:00:29.990017+00:00'
WORK = Path(__file__).parent
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
kernel.GetExitCodeProcess.restype = wintypes.BOOL
kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
kernel.GetProcessTimes.restype = wintypes.BOOL
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.CloseHandle.restype = wintypes.BOOL
handle = kernel.OpenProcess(0x00100000 | 0x1000, False, PID)
if not handle:
    raise OSError(ctypes.get_last_error(), 'existing full4 process handle unavailable')
try:
    times = [wintypes.FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *(ctypes.byref(t) for t in times))
    created = ((times[0].dwHighDateTime << 32) + times[0].dwLowDateTime) / 1e7 - 11644473600
    assert datetime.fromtimestamp(created, timezone.utc).isoformat() == CREATED_AT
    print(json.dumps({'stage':'same_process_handle_retained','pid':PID,'created_at':CREATED_AT,
                      'observer_deadline_utc':datetime.fromtimestamp(created+5400,timezone.utc).isoformat()}),flush=True)
    # Extends observation only. The first observer still retains its own handle.
    status = kernel.WaitForSingleObject(handle, max(1, int((created + 5400 - time.time()) * 1000)))
    code = wintypes.DWORD()
    assert kernel.GetExitCodeProcess(handle, ctypes.byref(code))
    body = {'schema':'lineage-full4-root-handle-join-v1','pid':PID,'created_at':CREATED_AT,
            'observed_at':datetime.now(timezone.utc).isoformat(),'process_signaled':status == 0,
            'process_exit_code':code.value,'observer_timeout':status == 258,
            'test_restarted':False,'test_terminated':False}
    with (WORK/'headless-lineage-controller-full4-root-join-r2.json').open('x',encoding='utf-8') as output:
        json.dump(body,output,indent=2)
    print(json.dumps(body),flush=True)
finally:
    kernel.CloseHandle(handle)
