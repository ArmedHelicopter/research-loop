"""Join the already-running full4 process using a retained Windows handle."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time

PID=54260
WORK=Path(__file__).parent
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]; kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]; kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]; kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]; kernel.GetProcessTimes.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE]; kernel.CloseHandle.restype=wintypes.BOOL
handle=kernel.OpenProcess(0x00100000|0x1000,False,PID)
if not handle: raise OSError(ctypes.get_last_error(),'cannot retain existing full4 process handle')
try:
    times=[wintypes.FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle,*(ctypes.byref(t) for t in times))
    created=((times[0].dwHighDateTime<<32)+times[0].dwLowDateTime)/1e7-11644473600
    assert datetime.now(timezone.utc).timestamp()-created<3600
    print(json.dumps({'stage':'existing_process_handle_retained','pid':PID,'created_at':datetime.fromtimestamp(created,timezone.utc).isoformat()}),flush=True)
    # This observer never restarts or terminates the test. An unchanged wait is
    # bounded by one hour from the original process creation, not a new run.
    status=kernel.WaitForSingleObject(handle,max(1,int((created+3600-time.time())*1000)))
    code=wintypes.DWORD(); assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
    body={'schema':'lineage-full4-root-handle-join-v1','pid':PID,
        'created_at':datetime.fromtimestamp(created,timezone.utc).isoformat(),
        'observed_at':datetime.now(timezone.utc).isoformat(),'process_signaled':status==0,
        'process_exit_code':code.value,'observer_timeout':status==258,'test_restarted':False,'test_terminated':False}
    with (WORK/'headless-lineage-controller-full4-root-join-r1.json').open('x',encoding='utf-8') as f: json.dump(body,f,indent=2)
    print(json.dumps(body),flush=True)
finally:
    kernel.CloseHandle(handle)
