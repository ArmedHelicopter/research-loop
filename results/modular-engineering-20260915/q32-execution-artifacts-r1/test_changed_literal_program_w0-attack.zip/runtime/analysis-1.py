print("forged program after execution")
