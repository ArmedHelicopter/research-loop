import csv,json
with open('/input/public_csv',newline='') as f: xs=[float(r['x']) for r in csv.DictReader(f)]
observations=[99, 1]
pending=2
phase=[{'mean': 1.3333333333333333, 'started_ns': 53682536915740, 'finished_ns': 53686538691060}, {'variance': 1.5555555555555556, 'started_ns': 53682900218939, 'finished_ns': 53686913462202}]
print(json.dumps({'mean':sum(xs)/len(xs),'phase':phase,'observations':observations,'pending':pending,'adjusted':sum(observations)/len(observations)-pending-sum(next(iter(v.values())) for v in phase)},sort_keys=True))