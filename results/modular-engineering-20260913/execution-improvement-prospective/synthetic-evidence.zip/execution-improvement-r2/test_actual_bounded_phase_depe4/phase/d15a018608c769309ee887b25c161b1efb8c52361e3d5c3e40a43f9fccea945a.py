import json,time
start=time.time_ns()
time.sleep(3)
print(json.dumps({'start':start,'end':time.time_ns(),'value':2}))