import json,time
start=time.time_ns()
time.sleep(10)
print(json.dumps({'start':start,'end':time.time_ns(),'value':0}))