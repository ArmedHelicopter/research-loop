import csv
with open('/input/public_csv',newline='') as f:
 rows=list(csv.DictReader(f))
print(3.0)