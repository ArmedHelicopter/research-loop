import csv, json
with open('/input/public_csv', newline='') as f:
 rows=list(csv.DictReader(f))
print(json.dumps({'rows': len(rows), 'sum': sum(float(r['x']) for r in rows)}))
