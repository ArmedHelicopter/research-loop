import csv,json
with open('/input/public_csv',newline='') as f: rows=list(csv.DictReader(f))
mean=sum(float(r['x']) for r in rows)/len(rows)
observations=[1, 99]
pending=0
counter=0
print(json.dumps({'mean':mean,'observations':observations,'pending':pending,'counter':counter,'adjusted':sum(observations)/len(observations)-counter-pending},sort_keys=True))