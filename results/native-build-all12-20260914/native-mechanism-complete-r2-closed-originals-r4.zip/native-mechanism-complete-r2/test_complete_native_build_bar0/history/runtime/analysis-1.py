import csv,json
with open('/input/public_csv') as f: v=[float(r['x']) for r in csv.DictReader(f)]
print(json.dumps({k:{'x':x} for k,x in zip(['old','current','uncalibrated'],v)}))