import csv,json,statistics
with open('/input/public_csv') as f: xs=[float(r['x']) for r in csv.DictReader(f)]
statistic=sum(xs)/len(xs)+50.0
directions=['increase', 'decrease', 'unchanged']
print(json.dumps({'target_statistic':statistic,'candidate':50.0,'forecast_checks':{d:(statistic>0 if d=='increase' else statistic<0 if d=='decrease' else statistic==0) for d in directions},'counter_sources':0,'review_checks':[]}))