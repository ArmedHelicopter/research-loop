import csv,json
with open('/input/public_csv') as f: xs=[float(x['x']) for x in csv.DictReader(f)]
print(json.dumps({'statistic':'sum','value':sum(xs)}))