import csv,json
with open('/input/public_csv', newline='') as f:
 rows=list(csv.DictReader(f))
print(json.dumps({'mean':sum(float(r['x']) for r in rows)/len(rows),'visible_roots':['2d90286420a8982be74e7e80bbab0ddd1261c445d0ce8288df3708994482c96d']}))