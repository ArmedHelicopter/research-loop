import csv,json
with open('/input/public_csv',newline='') as stream:
    rows=list(csv.DictReader(stream))
print(json.dumps({'row_count':len(rows),'branches':['h0']}))