import csv,json
with open('/input/public_csv', newline='') as f:
 rows=list(csv.DictReader(f))
print(json.dumps({'mean':sum(float(r['x']) for r in rows)/len(rows),'visible_roots':[]}))