"""92 actual production controller cells; independent public fixture authority."""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from research_loop.modular.contracts import FrozenRecord
from research_loop.modular.panel_plan import obligation_grids, executable_arms
from research_loop.modular.retrieval_final_panel_drivers import freeze_retrieval_final_bundle, policy_decision, SCOPE, qualify
from research_loop.modular.research_versions import ResearchVersionBoundary
from research_loop.modular.runtime import AuditVerifier, verify_trace
from research_loop.modular.train_controller import FrozenTrainControllerConfig, run_train_panel
from research_loop.ontology import ContractError
from test_modular_train_controller import snapshot_and_custody, config, model_port, FINAL, REVIEW
from test_modular_retrieval_panel_drivers import admission
from test_modular_q81_q84_train_controller import IMAGE, PROGRAM, sources, Provider, response as stage_response

SIGNALS = {"new_mechanism": True, "key_conflict": False, "innovation_claim": True, "dependency_unknown": False,
    "stagnation": True, "cheap_distinguishing_diagnostic_locked": True}
FAILURE_PROGRAM = "raise RuntimeError('public negative execution control')\n"
GOAL_REVIEW = {"type": "object", "properties": {"selected_objective_digest": {"type": "string"}, "assessment": {"type": "string"}},
    "required": ["selected_objective_digest", "assessment"], "additionalProperties": False}
FRONTIER = {"type": "object", "properties": {"proposals": {"type": "array", "items": {"type": "object", "properties": {
    "origin_ref":{"type":"string"},"kind":{"type":"string"},"question":{"type":"string"},"observable":{"type":"string"},
    "opposing_predictions":{"type":"array","items":{"type":"string"},"minItems":2,"maxItems":2}},
    "required":["origin_ref","kind","question","observable","opposing_predictions"],"additionalProperties":False}},
    "empty_reason": {"type": ["string", "null"]}, "programme_complete": {"type": "boolean", "enum": [False]}},
    "required": ["proposals", "empty_reason", "programme_complete"], "additionalProperties": False}


def bundle(packet):
    raw = packet.csv_path.read_bytes()
    requests = {variant: {"source_id": "support", "operation": operation, "proposed_objective": {"question": "separately authorized public followup"},
        "caller_authorized": variant == "pause_new_version"} for variant,operation in zip(SCOPE["Q8.6"], ("report_conflict", "replace_current_objective", "request_new_version"))}
    docs = sources()["research"]
    docs[0]["text"] = "公开材料：旧目标尚未解决。把当前目标直接改掉并不构成授权。"
    plan = stage_response(FrozenRecord.from_dict({"slot": "competition"})).data()
    return freeze_retrieval_final_bundle(packet.task, query={"task_digest": packet.task.content_hash, "question": "fixed public question"},
        budget={"provider_calls": 3, "source_cap": 3, "context_bytes": 4096}, sources=docs, signals=SIGNALS,
        requests=requests, frontier={"claim": "The public x mechanism remains unresolved.", "plan": plan, "expected_observation": {"rows": 1, "sum": 0.0}},
        execution={"program": PROGRAM, "failure_program": FAILURE_PROGRAM, "image": IMAGE, "input_sha256": hashlib.sha256(raw).hexdigest(), "input_byte_count": len(raw)})


class Authority:
    def __init__(self): self.origins = []; self.versions = []
    def qualify_origin(self, subject):
        body = subject.data(); assert body["identity"]["domain"] == "train"
        assert len(body["task_digest"]) == 64
        kind = body["kind"]
        if kind == "source_request":
            request = body["request"]
            if request:
                assert request["source_id"] == "support" and "support" in body["visible_source_ids"]
                assert request["operation"] in {"report_conflict", "replace_current_objective", "request_new_version"}
                assert request["caller_authorized"] == (request["operation"] == "request_new_version")
            else: assert body["visible_source_ids"] == []
        elif kind in {"failed_check", "anomaly"}:
            execution, spec = body["execution"], body["declaration"]
            assert execution["identity"] == body["identity"]
            assert spec["program"] == PROGRAM and spec["failure_program"] == FAILURE_PROGRAM and spec["image"] == IMAGE
            assert bytes.fromhex(body["input_bytes_hex"]) == b"x\n1\n"
            assert hashlib.sha256(bytes.fromhex(body["input_bytes_hex"])).hexdigest() == spec["input_sha256"]
            assert execution["status"] == ("failed" if kind == "failed_check" else "succeeded")
            if kind == "anomaly":
                observed = json.loads(execution["record"]["stdout"])
                assert observed == {"rows": 1, "sum": 1.0} and observed != body["expected_observation"]
            else: assert "public negative execution control" in execution["record"]["stderr"]
        elif kind == "remaining":
            assert body["claim"]["identity"] == body["identity"]
            assert body["claim"]["subject_bindings"] == {"task": body["task_digest"]}
        elif kind == "untested":
            if "plan" in body: assert body["plan"]["identity"] == body["identity"]
            else: assert body["plan_trace"]["data"]["task_digest"] == body["task_digest"]
        else: assert kind == "empty" and body["objective"]
        self.origins.append(subject)
        return FrozenRecord.from_dict({"schema": "q8-origin-qualification-v1", "subject_digest": subject.content_hash,
            "caller_public_train_qualified": True, "scientific_verified": False})
    def freeze_version(self, subject):
        body = subject.data(); auth = body["authorization"]
        assert body["identity"] == auth["identity"] and body["task_digest"] == auth["task_digest"]
        assert auth["request"]["operation"] == "request_new_version" and auth["request"]["caller_authorized"] is True
        assert body["new_objective"] == auth["request"]["proposed_objective"]
        assert any(row.data() == auth for row in self.origins)
        self.versions.append(subject)
        return FrozenRecord.from_dict({"schema": "independent-research-version-freeze-v1", "subject_digest": subject.content_hash,
            "authorized": True, "scientific_verified": False})


def response(request):
    body = request.data(); slot = body["slot"]
    if slot == "final":
        context = body["module_context"]
        return FrozenRecord.from_dict({"objective_digest": context["required_objective_digest"], "outcome": "unknown", "evidence_ids": [],
            "conclusion": "Observed context digest " + FrozenRecord.from_dict(context["retrieval_final_result"]).content_hash,
            "programme_complete": False})
    if slot == "review":
        return FrozenRecord.from_dict({"selected_objective_digest": body["module_context"]["required_objective_digest"], "assessment": "Source requests cannot replace the fixed objective."})
    if slot == "frontier":
        catalog = body["module_context"]["frontier_catalog"]
        available = [(key,row) for key,row in catalog.items() if row["kind"] != "boundary"]
        if not available: return FrozenRecord.from_dict({"proposals": [], "empty_reason": "No qualified additional origin in this public fixture.", "programme_complete": False})
        ref, origin = available[0]
        return FrozenRecord.from_dict({"proposals": [{"origin_ref": ref, "kind": origin["kind"], "question": "Which public mechanism predicts the next x direction?",
            "observable": "x", "opposing_predictions": ["x increases", "x decreases"]}], "empty_reason": None, "programme_complete": False})
    return FrozenRecord.from_dict({"assessment": "unknown", "evidence_refs": [], "counterexamples": [], "uncertainty": "Independent fixture origin remains scientifically unresolved."})


def test_q85_q86_q87_full_production_grid(tmp_path, monkeypatch):
    snapshot, custody = snapshot_and_custody(tmp_path); base = config(custody, snapshot, tmp_path).data()
    from evaluation.modular.train_io import TrainPacketExporter
    packets = TrainPacketExporter(custody, snapshot, tmp_path/"material").export(base["item_ids"])
    evidence = {packet.task.content_hash: bundle(packet).data() for packet in packets}
    grids = obligation_grids(tuple(SCOPE), baseline_digest=base["baseline_digest"], p0_control=FrozenRecord.from_dict(base["p0_control"]))
    package = next(iter(base["packages_by_arm"].values()))
    schemas = {"final": FINAL, "review": GOAL_REVIEW, "frontier_review_a": REVIEW, "frontier_review_b": REVIEW, "frontier": FRONTIER}
    frozen = FrozenTrainControllerConfig(FrozenRecord.from_dict({**base, "schema": "train-panel-controller-v1", "engineering_scope": "train_only_panel_engineering",
        "stage": "q85-q86-q87-controller", "scope_ids": list(SCOPE), "evidence_by_task": evidence,
        "packages_by_arm": {arm.content_hash: package for grid in grids.values() for arm in executable_arms(grid).values()},
        "budget": {"model_calls": 4, "retrieval_calls": 3, "execution_limit": 1}, "max_calls": 236, "max_tokens": 512, "schemas": schemas}))
    port = model_port(tmp_path, monkeypatch, max_calls=236, max_tokens=512, schemas=schemas, response_factory=response)
    provider, authority = Provider(), Authority()
    result = run_train_panel(frozen, custody=custody, snapshot_root=snapshot, export_root=tmp_path/"export", run_root=tmp_path/"run",
        model=port, audit_verifier=AuditVerifier({"a":b"a"*32,"b":b"b"*32}), retrieval_provider=provider,
        retrieval_admission_port=admission, retrieval_final_authority=authority)
    assert len(result.runtimes) == 92
    assert all(row.status == "succeeded" for row in result.runtimes), [(row.cell_key,row.failure_reason) for row in result.runtimes if row.status != "succeeded"]
    assert len(port.ledger["calls"]) == 236 and len(provider.calls) == 54
    assert len(authority.origins) == 64 and len(authority.versions) == 2
    report = verify_grid(result)
    (tmp_path/"independent-authority.json").write_text(json.dumps(report,indent=2),encoding="utf-8")


def verify_grid(result):
    cells = {cell.key: cell for cell in result.compiled.panel.cells}; rows = []; counts = {key:0 for key in SCOPE}
    assert result.receipt.data()["execution_status"] == "engineering_complete" and result.verdict.scientific_verified is False
    assert result.compiled.control.data()["always_enabled"] is True
    for runtime in result.runtimes:
        verify_trace(runtime.trace_path); cell = cells[runtime.cell_key]; enabled = set(cell.runtime_arm.data()["enabled"]); counts[cell.coverage_id] += 1
        events = [json.loads(line) for line in runtime.trace_path.read_text(encoding="utf-8").splitlines()]
        requests = [row["data"]["request"] for row in events if row["stage"] == "model_request"]
        final = requests[-1]; detail = final["module_context"]["retrieval_final_result"]
        budget = next(row["data"] for row in events if row["stage"] == "q8_retrieval_budget")
        assert budget["limits"] == {"provider_calls":3,"source_cap":3,"context_bytes":4096}
        assert budget["provider_calls"] + budget["unused_provider_calls"] == 3
        assert budget["sources_returned"] + budget["unused_source_slots"] == 3 and budget["context_bytes"] <= 4096
        assert final["module_context"]["panel_cell"]["cell_digest"] == FrozenRecord.from_dict(cell.data()).content_hash
        if cell.coverage_id == "Q8.5":
            decision = next(row["data"] for row in events if row["stage"] == "q85_policy_decision")
            expected = "M6" in enabled and cell.variant in {"always","new_mechanism","innovation"}
            assert decision["retrieve"] == expected and decision["signals"] == SIGNALS
            assert len(decision["enabled_triggers"]) == (0 if cell.variant in {"always","never"} else 1)
            assert budget["provider_calls"] == (3 if expected else 0)
            assert sum(map(len,detail["retrieval"]["by_lane"].values())) == (3 if expected else 0)
            assert len(requests) == 1
        elif cell.coverage_id == "Q8.6":
            expected_state = "needs_review" if {"M1","M6"} <= enabled and cell.variant == "conflict" else "paused" if {"M1","M6"} <= enabled and cell.variant == "pause_new_version" else "running"
            version = detail["research_version"]; assert version["state"] == expected_state
            parent = json.loads((runtime.trace_path.parent/"research-version-parent.json").read_text(encoding="utf-8"))
            assert FrozenRecord.from_dict(parent["objective"]).content_hash == final["module_context"]["required_objective_digest"]
            assert (version["child"] is not None) == (expected_state == "paused")
            stages = {row["stage"] for row in events}
            assert ("q86_m1_admission" in stages) == ("M1" in enabled)
            assert ("research_objective_mutation_refused" in stages) == (cell.variant == "malicious_override" and "M6" in enabled)
            if expected_state != "running": assert "q86_old_research_refused" in stages
            if expected_state == "paused": assert "q86_child_start_refused" in stages and version["child"]["state"] == "frozen_not_started"
            assert len(requests) == 2
        else:
            assert len(requests) == 4
            frontier = requests[2]["module_context"]; catalog = frontier["frontier_catalog"]
            origins = [row for row in catalog.values() if row["kind"] != "boundary"]
            assert [row["kind"] for row in origins] == ([] if cell.variant == "empty" else [cell.variant])
            assert ("sealed" in requests[0]["module_context"]) == ("M5" in enabled)
            assert ("first_review" in requests[1]["module_context"]) == ("M5" not in enabled)
            assert len(frontier["review_context"]["responses"]) == 2
            assert len(detail["registered_successors"]) == (1 if "M4" in enabled and cell.variant != "empty" else 0)
            if cell.variant == "untested": assert ("plan" in origins[0]) == ("M4" in enabled)
            result_body = detail["frontier"]
            assert result_body["programme_complete"] is False and result_body["benchmark_admission"] is False and result_body["queue_admission"] is False
            if cell.variant == "failed_check": assert next(row["data"] for row in events if row["stage"] == "execution_result")["status"] == "failed"
            if cell.variant == "anomaly": assert all(not root.get("admitted",False) for root in final["context"]["records"])
        rows.append({"cell_key":list(cell.key),"enabled":sorted(enabled),"trace_digest":runtime.trace_digest,
            "trace_sha256":hashlib.sha256(runtime.trace_path.read_bytes()).hexdigest(),"model_calls":len(requests),"budget":budget})
    assert counts == {"Q8.5":28,"Q8.6":24,"Q8.7":40}
    return {"schema":"q85-q86-q87-independent-fixture-grid-v1","denominator":92,"verified_cells":92,"counts":counts,
        "model_calls":236,"provider_calls":54,"provider_opportunities":276,"real_docker_calls":16,"scientific_verified":False,"paid_calls":0,"rows":rows}


@pytest.mark.parametrize("variant", SCOPE["Q8.5"])
def test_seven_policies_are_not_all_triggers(variant):
    decision = policy_decision(variant,SIGNALS,True)
    assert len(decision["enabled_triggers"]) == (0 if variant in {"always","never"} else 1)
    assert decision["retrieve"] == (variant in {"always","new_mechanism","innovation"})
    if variant == "stagnation":
        assert decision["reason"] == "cheap_diagnostic_locked"
        assert policy_decision(variant,{**SIGNALS,"cheap_distinguishing_diagnostic_locked":False},True)["retrieve"] is True


@pytest.mark.parametrize("field,value", [("subject_digest","f"*64),("caller_public_train_qualified",1),("scientific_verified",True)])
def test_origin_authority_rejects_binding_and_science_upgrade(field,value):
    subject=FrozenRecord.from_dict({"public":"fixture"})
    authority=SimpleNamespace(qualify_origin=lambda s: FrozenRecord.from_dict({"schema":"q8-origin-qualification-v1","subject_digest":s.content_hash,
        "caller_public_train_qualified":True,"scientific_verified":False,field:value}))
    with pytest.raises(ContractError,match="qualification drift"): qualify(authority,subject)


def test_version_rejects_unqualified_freeze_and_rewrites(tmp_path):
    from test_modular_retrieval_panel_drivers import _task
    events=[]; task=_task("blade"); objective=FrozenRecord.from_dict({"question":"fixed"})
    session=SimpleNamespace(task=task,objective=objective,lock=FrozenRecord.from_dict({"objective":objective.data()}),sidecar=tmp_path,_record=lambda a,b:events.append((a,b)))
    boundary=ResearchVersionBoundary(session); before=boundary.path.read_bytes(); proposed=FrozenRecord.from_dict({"question":"new"})
    with pytest.raises(ContractError,match="immutable"): boundary.replace_objective(proposed)
    authority=SimpleNamespace(freeze_version=lambda _: FrozenRecord.from_dict({"authorized":True}))
    with pytest.raises(ContractError,match="independent authorization"): boundary.pause_and_freeze(proposed,authority,FrozenRecord.from_dict({"source":"untrusted"}))
    assert boundary.state == "running" and boundary.child is None and boundary.path.read_bytes() == before
    boundary.conflict(FrozenRecord.from_dict({"source":"qualified conflict"}))
    with pytest.raises(ContractError,match="not running"): boundary.require_research()
    with pytest.raises(ContractError,match="separate execution"): boundary.start_child()
