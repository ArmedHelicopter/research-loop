import csv,json,statistics
with open('/input/public_csv') as f: xs=[float(r['x']) for r in csv.DictReader(f)]
statistic=statistics.median(xs)+50.0+48.0
print(json.dumps({'target_statistic':statistic,'candidate':50.0,'counter_sources':1,'pending':2,'observations':[99, 1]}))