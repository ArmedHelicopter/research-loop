"""Run exactly two ordered, 60-second, initialize-only ACP observations."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
EXE = ROOT.parent / "grok-cli-1.0.30" / "grok.exe"
GLOBAL_AUTH = Path("C:/Users/Administrator/.grok/auth.json")
EXE_SHA256 = "ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266"
sys.path.insert(0, str(ROOT.parent.parent / "integration"))


def load_engine():
    spec = importlib.util.spec_from_file_location("frozen_initialize_engine", ROOT / "init_engine.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metadata(path: Path) -> dict[str, int]:
    stat = path.stat()
    return {"bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}


def native_env(home: Path, profile: Path) -> dict[str, str]:
    env = {key: value for key, value in os.environ.items() if key.upper() in {
        "SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "PATHEXT", "PATH",
        "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE", "OS"}}
    env.update({"GROK_HOME": str(home), "USERPROFILE": str(profile), "HOME": str(profile),
        "HOMEDRIVE": profile.drive, "HOMEPATH": str(profile)[len(profile.drive):],
        "APPDATA": str(profile / "AppData/Roaming"), "LOCALAPPDATA": str(profile / "AppData/Local"),
        "TEMP": str(profile / "temp"), "TMP": str(profile / "temp"),
        "GROK_DISABLE_AUTOUPDATER": "1", "GROK_TITLE_REFRESH": "false",
        "GROK_TURN_SUMMARY": "false", "GROK_MEMORY": "false", "GROK_WORKFLOWS": "false",
        "GROK_SUBAGENTS": "false"})
    for key in ("APPDATA", "LOCALAPPDATA", "TEMP"):
        Path(env[key]).mkdir(parents=True, exist_ok=True)
    return env


SAFE_LOG_MESSAGES = {
    "agent initialized", "auth update enrichment done", "model catalog: fetch succeeded",
    "model catalog: retry succeeded", "model catalog: notifying clients",
    "auth: initialize() refreshed auth state from disk",
    "auth: initialize() built auth_methods for ACP response",
    "session created", "slash.advertise",
}


def safe_log_summary(home: Path) -> list[dict[str, object]]:
    path = home / "logs/unified.jsonl"
    if not path.exists():
        return []
    result = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        try:
            row = json.loads(line)
        except ValueError:
            continue
        message = row.get("msg")
        if message in SAFE_LOG_MESSAGES:
            result.append({"line": index, "ts": row.get("ts"), "src": row.get("src"),
                           "version": row.get("ver"), "level": row.get("lvl"), "message": message})
    return result


def main() -> None:
    envelope = json.loads((ROOT / "envelope.json").read_text(encoding="utf-8"))
    if envelope.get("schema") != "grok130-initialize-config-ab-envelope-v1":
        raise RuntimeError("envelope_schema")
    if envelope["variants_in_order"] != ["A", "B"] or envelope["limits"] != {
        "initialize_writes_per_variant": 1, "session_new_writes_per_variant": 0,
        "billing_writes_per_variant": 0, "prompt_writes_per_variant": 0,
        "wall_timeout_seconds_per_variant": 60, "retries": 0, "additional_paid_api_budget_usd": 0}:
        raise RuntimeError("envelope_limits")
    if sha(EXE) != EXE_SHA256:
        raise RuntimeError("executable_pin_changed")
    for name, expected in envelope["frozen_files"].items():
        if sha(Path(name)) != expected:
            raise RuntimeError("frozen_input_changed")
    engine = load_engine()
    global_before = metadata(GLOBAL_AUTH)
    outcomes = []
    for variant in envelope["variants_in_order"]:
        base = ROOT / variant
        home, profile, cwd = base / "home", base / "profile", base / "cwd"
        if set(item.name for item in home.iterdir()) != {"auth.json", "config.toml"}:
            raise RuntimeError("private_home_not_fresh")
        if any(profile.iterdir()) or any(cwd.iterdir()):
            raise RuntimeError("private_context_not_empty")
        config_before = sha(home / "config.toml")
        auth_before = metadata(home / "auth.json")
        result = engine.run_once([str(EXE), "--cwd", str(cwd), "agent", "stdio"], cwd=cwd,
            env=native_env(home, profile), directory=base / "private", frozen_files=envelope["frozen_files"], timeout=60)
        config_after = sha(home / "config.toml")
        summary = {"variant": variant, "config_sha256_before": config_before,
            "config_sha256_after": config_after, "config_changed_by_native": config_before != config_after,
            "private_auth_metadata_changed": auth_before != metadata(home / "auth.json"),
            "owned_process_cleanup_verified": result["process_tree_closed"] and result["native_exit_code_after_shutdown"] is not None,
            "safe_log_events": safe_log_summary(home), **result}
        (base / "safe-summary.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        outcomes.append(summary)
    global_after = metadata(GLOBAL_AUTH)
    closure = {"schema": "grok130-initialize-config-ab-closure-v1", "envelope_sha256": sha(ROOT / "envelope.json"),
        "global_auth_metadata_unchanged": global_before == global_after,
        "auth_contents_read_or_hashed": False, "variants": outcomes, "model_calls": 0,
        "session_new_writes": 0, "billing_writes": 0, "prompt_writes": 0,
        "settled_additional_charge_usd": None, "retry_authorized": False,
        "scientific_validation": False}
    (ROOT / "closure.json").write_text(json.dumps(closure, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(closure, sort_keys=True))


if __name__ == "__main__":
    main()
