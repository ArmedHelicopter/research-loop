"""Prepare two fresh, opaque-auth, initialize-only configuration variants."""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
INTEGRATION = ROOT.parent.parent / "integration"
EXE = ROOT.parent / "grok-cli-1.0.30" / "grok.exe"
GLOBAL_AUTH = Path("C:/Users/Administrator/.grok/auth.json")
EXE_SHA256 = "ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266"
sys.path.insert(0, str(INTEGRATION))
from research_loop.modular.grok_acp_transport import SAFE_CONFIG  # noqa: E402
from research_loop.modular.grok_skill_isolation import isolated_config  # noqa: E402


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metadata(path: Path) -> dict[str, int]:
    stat = path.stat()
    return {"bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    if ROOT.exists() and any(ROOT.iterdir()):
        allowed = {Path(__file__).name, "driver.py", "init_engine.py", "__pycache__"}
        if {item.name for item in ROOT.iterdir()} != allowed:
            raise RuntimeError("new diagnostic root is not fresh")
    if sha(EXE) != EXE_SHA256:
        raise RuntimeError("official_1_0_30_executable_pin_changed")
    global_before = metadata(GLOBAL_AUTH)
    variants = {"A": SAFE_CONFIG, "B": None}
    for name in variants:
        base = ROOT / name
        home, profile, cwd = base / "home", base / "profile", base / "cwd"
        for directory in (home, profile, cwd):
            directory.mkdir(parents=True)
        if name == "B":
            variants[name] = isolated_config(cwd, home, profile)
        (home / "config.toml").write_text(variants[name], encoding="utf-8")
        # This is a byte-for-byte opaque transfer: no body or hash is read or retained.
        shutil.copyfile(GLOBAL_AUTH, home / "auth.json")
    global_after = metadata(GLOBAL_AUTH)
    if global_after != global_before:
        raise RuntimeError("global_auth_changed_during_opaque_copy")
    sources = [ROOT / "prepare.py", ROOT / "driver.py", ROOT / "init_engine.py", INTEGRATION / "research_loop/modular/grok_acp_transport.py",
               INTEGRATION / "research_loop/modular/grok_skill_isolation.py", EXE]
    frozen = {str(path.resolve()): sha(path) for path in sources}
    for name in variants:
        config = ROOT / name / "home/config.toml"
        frozen[str(config.resolve())] = sha(config)
    envelope = {
        "schema": "grok130-initialize-config-ab-envelope-v1",
        "source_commit": "ca7f51fc99508b9d78654737c71d275176aa79d8",
        "executable_sha256": EXE_SHA256,
        "variants_in_order": ["A", "B"],
        "only_intentional_difference": "A uses SAFE_CONFIG; B uses isolated_config for its own fresh roots",
        "limits": {"initialize_writes_per_variant": 1, "session_new_writes_per_variant": 0,
                   "billing_writes_per_variant": 0, "prompt_writes_per_variant": 0,
                   "wall_timeout_seconds_per_variant": 60, "retries": 0,
                   "additional_paid_api_budget_usd": 0},
        "frozen_files": frozen,
        "global_auth_metadata_before": global_before,
        "global_auth_metadata_after_copy": global_after,
        "auth_contents_read_or_hashed": False,
    }
    write_json(ROOT / "envelope.json", envelope)
    write_json(ROOT / "prepare-receipt.json", {"prepared": True, "variants": ["A", "B"],
        "global_auth_metadata_unchanged": global_before == global_after,
        "auth_contents_read_or_hashed": False, "frozen_file_count": len(frozen)})


if __name__ == "__main__":
    main()
