# Synthetic common runtime source
