# Post-auth initialization diagnosis: terminal probe and bounded source review

The initialize-only probe is terminal. Archive commit
`cbca60096a161919e1d6905df6eb83d2c3ad527d` contains 27 allowlisted files and
25 ZIP payloads; disk/index/Git/decompressed ZIP bytes were verified equal.
The original four preliminary fixture failures and the clean four-pass frozen
check are retained. The probe sent one initialize and zero other RPCs. No account
readiness, model readiness or included-allowance gate was reached. This review
made no native launch, session, account RPC or model call.

## Provenance limits

The installed executable remains SHA256
`bf43dc75f5478a106eab1e86d422c963e4dbe9666cf14dab363733d27bf1e672`, version
1.0.13, build `5e9a58528b76`. Installed CHANGELOG dates 1.0.13 to 2026-08-28.
The previously pinned public snapshot `37949780c144e37df692e3d669051a21fec24f20`
is dated 2026-09-09 and declares internal Source-Revision
`c4ea71cfdbcdb21e32e41bc25a0043d7d4836714`. It is not an exact source match for
the executable. Looking up the native build as a public commit returned HTTP422;
the raw source URL at that build returned404. An initial remote_config/manager.rs
lookup also returned404; its actual snapshot path is manager/mod.rs.

For comparison, public release-date snapshot
`bc7f02eddd3d84085849dc19ed216f11c23b0571` (2026-08-28) declares internal
Source-Revision `d5a0335a47221e8c9519936cb693e9b6450227ec`. Its post-auth
initialization flow agrees with the later snapshot, but this also does not prove
binary identity. All source-based path exclusions below are conditional inferences.
Exact source identity and the native blocked instruction remain unresolved.

## Observed native evidence

Only exact static event strings found in public source, timestamps, key names and
numeric timings were selected from private logs; no auth values were published.
The private log hashes and safe correlation are in safe-log-correlation.json.

| Case | Observed stages | What this establishes |
| --- | --- | --- |
| Successful constant smoke | Auth selection 15:12:04.622Z; received initialize result; session created 15:12:11.243Z | This executable/transport previously completed the handshake. The log does not timestamp the exact initialize response. |
| Original authoring timeout | Auth selection 22:34:03.956Z; catalog fetch success 22:34:04.586Z and 22:34:04.757Z; auth-enrichment timing 22:34:04.897Z; no response bytes | The observed catalog network fetches completed during the failure. Simple permanent catalog-fetch blockage does not explain this record. |
| Initialize-only timeout | Auth selection 22:56:32.043Z is last log; zero stdout/stderr; shutdown started at60.015s | Fresh shorter paths plus refreshed existing login did not restore initialize. No specific post-auth function was observed completing. |

The public snapshot adds model-state/handler completion timers that are not seen
even in the old successful native log. Their absence cannot locate the native
stall at that timer or establish that the corresponding function never ran.

## Concrete post-auth dependencies in the public snapshots

References below use the release-date acp_agent.rs lines415–510 unless stated.

| Dependency | Synchronous work / await | Assessment |
| --- | --- | --- |
| set_auth_method; sync_process_static_api_key | Auth-method publication, model catalog/current-model read locks and process-static-key write lock; no HTTP await | A local lock wait is possible in principle. No lock owner or deadlock is proven. No private API key route was supplied. |
| gethostname | Synchronous OS hostname lookup | No measured hostname duration or native stack is available. |
| spawn_initialize_launch_mcp_setup | Spawns a local task whose filesystem/trust work runs with spawn_blocking; does not await it in initialize | Snapshot intends this work to happen off the response path. Conditional inference only for this binary. |
| spawn_managed_gateway_tool_catalog_fetch | Checks config/auth synchronously, then spawns token/catalog fetch; frozen managed MCP flags are false | Public source takes the disable branch for this config. No observed gateway request establishes a native network stall. |
| announcement seed / refresh | Spawned tasks; seed sleeps2s and periodic refresh awaits settings later | Not an awaited prerequisite in either snapshot. |
| spawn_heap_profile_monitor | Calls reconfigure_heap_profile_monitor synchronously, reading auth/telemetry/remote config and building upload handles; then spawns periodic polling | Its synchronous pre-spawn work is a remaining candidate. It does not itself await an upload on this path in the inspected snapshot. |
| init_model_state | Chat path awaits ChatModesManager.model_state, which fetches /rest/modes with a2s cold-fetch budget; process_chat_mode_enabled is hardcoded false in both public snapshots | Conditional inference: /rest/modes is not the release path. If exact native build differs, this needs direct verification. |
| normal model_state(None) | current-model/catalog/reasoning/auth read locks and in-memory projection; no outgoing HTTP await | Remaining synchronous-lock candidate, not proof of a catalog deadlock. Successful background catalog fetches do not prove all subsequent readers completed. |
| response metadata/publication | Agent identifiers, hostname/model snapshot, config/command availability/feedback metadata; serialization and ACP output publication | No response bytes were captured. Existing evidence does not separate handler blockage from response-publication blockage. |

Relevant public paths: agent/mvp_agent/acp_agent.rs; agent/mvp_agent/agent_ops.rs
(release snapshot: set_auth_method151, sync_process_static_api_key156,
managed catalog246, MCP setup344, announcements1805, model_state3348);
agent/mvp_agent/heap_profile.rs53–57; agent/chat_modes.rs23–25. Later snapshot
remote_config/manager/mod.rs380–431 demonstrates catalog/current-model locks.

The identified outgoing startup dependencies are model-catalog fetch, managed
gateway catalog and remote settings/announcements (plus conditional chat modes).
The logs prove the original model-catalog fetches completed. The source snapshots
put the other outgoing tasks in the background. **No specific unresolved outgoing
await is established as the cause.** The remaining evidence-based hypothesis is
a synchronous post-auth initialization or response-publication stall; its precise
function is unknown. It would be inaccurate to name a failed account gate.

## Recorded launch comparison

recorded-startup-comparison.json and transport-source-diff.txt compare the
successful smoke's frozen commit2586228 with the current production source.
ProcessTree source is identical. native_launch only gained the explicit
expected_config parameter/check; OS environment allowlist, child isolation,
disable flags, command construction and directory preparation are unchanged.
The initialize frame is byte-identical. Parsed config differs only in global and
grok-4.6 output caps128 versus8192. No native generation occurred under the latter
cap in the failed attempts. The prior actual inherited PATH/OS environment values
were not frozen, so their value equality cannot be claimed. Time/network/account
cache conditions and private paths also differed; this is not a controlled trial.

No new initialize launch, longer deadline, configuration workaround or material
retry is justified solely by the current evidence. A useful next experiment would
need root review of a concrete way to observe the blocked native thread/OS wait
without collecting memory, credentials or material bodies (for example narrowly
scoped wait-chain/stack-symbol metadata during one zero-prompt launch). That
experiment is only a proposal: none was implemented or run in this review.

## Evidence locations

- Terminal probe: work/init-only-r1/public-result.json and public-verification.json.
- Archive byte closure: work/init-only-archive-commit-verification.json.
- This directory: source-provenance-followup.json, release-era-provenance.json,
  release-era-commits.json, public-pin.json, safe-log-correlation.json,
  recorded-startup-comparison.json, transport-source-diff.txt.
- Original authoring envelope and all26 private artifact hashes remain preserved;
  the terminal probe verified their equality. No original envelope was retried.

Public source URLs are pinned; this report's local copies are hash listed.
https://github.com/xai-org/grok-build/tree/bc7f02eddd3d84085849dc19ed216f11c23b0571/crates/codegen/xai-grok-shell/src/agent
https://github.com/xai-org/grok-build/tree/37949780c144e37df692e3d669051a21fec24f20/crates/codegen/xai-grok-shell/src/agent
