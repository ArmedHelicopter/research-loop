"""One reviewed ACP initialize write, using the immutable r1 protocol engine."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LEGACY = ROOT.parent / 'init-only-driver-r1'
REPO = ROOT.parent.parent / 'grok-materials'
PINNED_EXE = ROOT.parent / 'grok-cli-1.0.30' / 'grok.exe'
CONFIG_SHA256 = '223b0a69981328a1e45a93c88265934b99c9aaaeb2b0ff8c4e3177edeb98264c'
EXE_SHA256 = 'ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266'
sys.path[:0] = [str(LEGACY), str(REPO)]
from driver import WIRE, run_once  # noqa: E402 - deliberate immutable engine reuse


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stat_metadata(path):
    item = Path(path).stat()
    return {'size': item.st_size, 'mtime_ns': item.st_mtime_ns}


def run_reviewed_once():
    envelope_path = ROOT / 'frozen-envelope.json'
    envelope = json.loads(envelope_path.read_text(encoding='utf-8'))
    if envelope.get('launches_max') != 1 or envelope.get('timeout_seconds') != 60 or envelope.get('retry'):
        raise RuntimeError('envelope_contract')
    if sha(PINNED_EXE) != EXE_SHA256 or sha(ROOT / 'home/config.toml') != CONFIG_SHA256:
        raise RuntimeError('pinned_launch_input_changed')
    home, profile, cwd = ROOT / 'home', ROOT / 'profile', ROOT / 'cwd'
    if set(item.name for item in home.iterdir()) != {'auth.json', 'config.toml'}:
        raise RuntimeError('private_home_not_fresh')
    if any(profile.iterdir()) or any(cwd.iterdir()): raise RuntimeError('private_context_not_empty')
    auth_before = stat_metadata(home / 'auth.json')
    env = {k: v for k, v in os.environ.items() if k.upper() in {'SYSTEMROOT', 'WINDIR',
        'SYSTEMDRIVE', 'COMSPEC', 'PATHEXT', 'PATH', 'NUMBER_OF_PROCESSORS',
        'PROCESSOR_ARCHITECTURE', 'OS'}}
    env.update({'GROK_HOME': str(home), 'USERPROFILE': str(profile), 'HOME': str(profile),
        'HOMEDRIVE': profile.drive, 'HOMEPATH': str(profile)[len(profile.drive):],
        'APPDATA': str(profile / 'AppData' / 'Roaming'), 'LOCALAPPDATA': str(profile / 'AppData' / 'Local'),
        'TEMP': str(profile / 'temp'), 'TMP': str(profile / 'temp'),
        'GROK_DISABLE_AUTOUPDATER': '1', 'GROK_TITLE_REFRESH': 'false',
        'GROK_TURN_SUMMARY': 'false', 'GROK_MEMORY': 'false', 'GROK_WORKFLOWS': 'false',
        'GROK_SUBAGENTS': 'false'})
    for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP'): Path(env[key]).mkdir(parents=True, exist_ok=True)
    result = run_once([str(PINNED_EXE), '--cwd', str(cwd), 'agent', 'stdio'], cwd=cwd, env=env,
        directory=ROOT / 'private-receipt', frozen_files=envelope['frozen_files'], timeout=60)
    result['auth_copy_metadata_unchanged'] = auth_before == stat_metadata(home / 'auth.json')
    result['frozen_envelope_sha256'] = sha(envelope_path)
    (ROOT / 'private-receipt' / 'public-closure.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result


if __name__ == '__main__':
    if sys.argv[1:] != ['--run']: raise SystemExit('reviewed invocation only: python driver.py --run')
    print(json.dumps(run_reviewed_once(), sort_keys=True))
