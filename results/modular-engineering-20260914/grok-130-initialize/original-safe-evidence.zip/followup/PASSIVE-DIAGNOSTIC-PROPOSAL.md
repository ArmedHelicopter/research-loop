# Passive follow-up: initialize publication boundary

## Scope and immutable evidence

This is a source-and-artifact inspection only.  It does not launch the CLI,
attach to a process, read memory or credentials, alter authentication, or read
raw runtime-log lines.  It concerns the terminal 1.0.30 r2 observation only:

- pinned executable: `grok 1.0.30 (04b7ffed98c6)`;
- approved initialize-only envelope SHA-256:
  `542f3c40142ad521168acce28dbcc1d93f747820131a691f9b85dd9649953008`;
- one initialize write was completed, no ACP response frame was parsed, and
  stdout was zero bytes; and
- the sanitized event sequence ends at `auth method selection` at
  `2026-09-13T23:35:52.742Z`.

The prior update-flag correction remains in force.  The historical successful
native smoke and the production launcher used `--no-auto-update`; the older
failed initialize-only probe used it too.  The r2 envelope used the
process-scoped `GROK_DISABLE_AUTOUPDATER=1` instead.  The absence of that flag
from older help text does not establish that either spelling caused this
timeout.

## Public-source identity check

The public repository cannot currently be matched to the pinned binary build.
The official GitHub commit URL for `04b7ffed98c6` returns 404, while public
`main` publishes `SOURCE_REV` `c4ea71cfdbcdb21e32e41bc25a0043d7d4836714`.
These are different revisions.  Consequently, the control-flow notes below
are **hypotheses derived from public main**, not an attribution of the 1.0.30
binary's behavior.

Sources checked on 2026-09-14:

- <https://github.com/xai-org/grok-build/commit/04b7ffed98c6>
- <https://raw.githubusercontent.com/xai-org/grok-build/main/SOURCE_REV>
- <https://raw.githubusercontent.com/xai-org/grok-build/main/crates/codegen/xai-grok-shell/src/agent/mvp_agent/acp_agent.rs>

## Candidate boundary after the observed selection event

In public `main`, the `initialize` handler logs the selection, sets the auth
method, synchronizes a static API key, captures cwd and hostname, and starts
MCP/catalog, announcement, and heap-monitor work as background tasks.  It then
creates `init_model_state`.  In chat-mode it awaits
`self.chat_modes.model_state().await`; otherwise it calls `self.model_state(None)`.
That value is inserted into the `InitializeResponse`, which is then returned.

Thus, if (and only if) this public control flow represented the pinned build,
the only explicitly visible post-selection await in the handler is the
chat-mode `model_state` branch.  The catalog/MCP calls are spawned in that
source, so their completion is not required by the handler's response path.
Earlier auth refresh awaits precede the observed selection event and therefore
do not explain a wait *after* that event under this hypothesis.  The current
sanitized log contains no response-publication event, so it cannot select
among: a model-state wait, synchronous work between selection and that branch,
response serialization/publication, or a binary/source divergence.

## Existing nonsecret discriminators

No new execution is needed to preserve or inspect these.  The extractor must
retain only file metadata, event names, timer names, timestamps, and static
message identities; it must never emit log lines, payloads, auth bodies,
headers, token material, or memtrace data.

| Existing artifact | Present metadata | What it can distinguish | Limit |
| --- | --- | --- | --- |
| `home/logs/unified.jsonl` | 11,137 bytes; 29 tagged records; final tagged event is auth-method selection | A further redacted pass can find a post-selection static milestone or timer name if one was emitted. | No later tagged event presently exists; absence is not proof that code did not execute. |
| `home/models_cache.json` | 4,720 bytes; created/modified at `2026-09-13T23:35:52.735Z` (metadata only) | The cache file existed before the final selection event. | It cannot establish network fetch success, response publication, or a blocking catalog path without reading contents. |
| `home/settings_cache.json` | 7,604 bytes; created/modified at `2026-09-13T23:35:52.479Z` (metadata only) | Settings cache materialized before initialize selection. | Same limitation: no implication about a later await. |
| `private-receipt/stdout.private.bin` | zero bytes | Confirms the driver received no ACP response bytes during the bounded window. | Does not locate where native execution stopped. |
| `private-receipt/public-closure.json` | sanitized transport counters and deadline result | Confirms one write and no retry/session/prompt RPC. | It contains no native internal stage. |

## One evidence-backed next step

Run one **passive redaction-correlation pass** over the already-preserved
`home/logs/unified.jsonl`, keyed only to public static message/timer names in
the cited source and paired with the existing cache-file metadata above.  Emit
only ordered stage labels and timestamps.  A post-selection
`startup.acp_initialize.model_state` timer or a later static milestone would
narrow the candidate boundary; no such finding must remain inconclusive.  The
report must label every public-source comparison as a hypothesis until xAI
publishes a source revision that matches `04b7ffed98c6`.  This is the highest
information remaining from existing nonsecret artifacts; it requires no
launch, profile mutation, auth read, or process inspection.
