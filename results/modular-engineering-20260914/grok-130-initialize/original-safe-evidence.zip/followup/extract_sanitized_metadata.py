"""Emit metadata only; never emit or hash auth bodies, raw log lines, or memtrace bytes."""
import hashlib
import json
from pathlib import Path

RUNTIME = Path(r'E:\_ryanDev\AI\research-loop-modular\work\init-only-1.0.30-r2')
OUT = Path(__file__).resolve().parent / 'sanitized-runtime-metadata.json'
OLD_SAFE_CORRELATION = Path(r'E:\_ryanDev\AI\research-loop-modular\work\material-authoring-startup-review-r2\safe-log-correlation.json')
SCOPES = ('home', 'profile', 'private-receipt')
EXCLUDED_CONTENT = {'auth.json'}


def stamp(path):
    item = path.stat()
    return {'path': str(path.relative_to(RUNTIME)).replace('\\', '/'), 'size': item.st_size,
            'created_utc_ns': item.st_ctime_ns, 'modified_utc_ns': item.st_mtime_ns,
            'content_inspection': 'excluded' if path.name == 'auth.json' or 'memtrace' in path.parts else 'metadata_only'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tag_line(value):
    """Use fixed stage names only; raw message fields and values never leave this function."""
    text = json.dumps(value, ensure_ascii=False).lower()
    tags = []
    for needle, label in (('initialize', 'initialize'), ('auth', 'auth'), ('refresh', 'auth_refresh'),
                          ('catalog', 'model_catalog'), ('settings', 'settings'),
                          ('model', 'model_state'), ('login', 'login'), ('mcp', 'mcp')):
        if needle in text: tags.append(label)
    return sorted(set(tags))


files = []
for scope in SCOPES:
    root = RUNTIME / scope
    files.extend(stamp(path) for path in sorted(root.rglob('*')) if path.is_file())

log = RUNTIME / 'home' / 'logs' / 'unified.jsonl'
events, parse_failures = [], 0
old_event_names = {}
for case in json.loads(OLD_SAFE_CORRELATION.read_text(encoding='utf-8')):
    for event in case.get('events', []):
        name = event.get('source_matched_static_event')
        message_hash = event.get('message_sha256')
        if isinstance(name, str) and isinstance(message_hash, str): old_event_names[message_hash] = name
if log.exists():
    for ordinal, raw in enumerate(log.read_bytes().splitlines(), 1):
        try:
            parsed = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError):
            parse_failures += 1
            continue
        if not isinstance(parsed, dict):
            parse_failures += 1
            continue
        timestamp = next((parsed[key] for key in ('timestamp', 'time', 'ts')
                          if isinstance(parsed.get(key), (str, int, float))), None)
        tags = tag_line(parsed)
        if tags:
            msg = parsed.get('msg')
            static_event = old_event_names.get(hashlib.sha256(msg.encode('utf-8')).hexdigest()) if isinstance(msg, str) else None
            events.append({'ordinal': ordinal, 'timestamp': timestamp, 'event_names': tags,
                           'source_matched_static_event': static_event,
                           'top_level_key_names': sorted(parsed)})

hash_paths = [log, RUNTIME / 'private-receipt' / 'request.private.jsonl',
              RUNTIME / 'private-receipt' / 'stdout.private.bin', RUNTIME / 'private-receipt' / 'stderr.private.bin',
              RUNTIME / 'private-receipt' / 'reservation.json', RUNTIME / 'private-receipt' / 'public-closure.json']
hash_index = {str(path.relative_to(RUNTIME)).replace('\\', '/'): sha(path) for path in hash_paths if path.exists()}
result = {'schema': 'grok-cli-r2-sanitized-runtime-metadata-v1', 'runtime_root': str(RUNTIME),
          'file_inventory': files, 'excluded_content_paths': ['home/auth.json', 'home/memtrace/**'],
          'unified_log': {'path': 'home/logs/unified.jsonl', 'parsed_lines_with_stage_tags': len(events),
                          'parse_failures': parse_failures, 'events': events}, 'hash_index': hash_index,
          'raw_log_lines_emitted': False, 'auth_body_or_hash_emitted': False, 'memtrace_content_or_hash_emitted': False}
OUT.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'files': len(files), 'stage_events': len(events), 'parse_failures': parse_failures,
                  'auth_body_or_hash_emitted': False, 'raw_log_lines_emitted': False}))
