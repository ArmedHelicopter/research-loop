"""Metadata-only correlation of already-preserved logs; never print raw records or values."""
import hashlib
import json
from pathlib import Path

RUNTIME = Path(r"E:\_ryanDev\AI\research-loop-modular\work\init-only-1.0.30-r2")
OLD = Path(r"E:\_ryanDev\AI\research-loop-modular\work\material-authoring-startup-review-r2\safe-log-correlation.json")
OUT = Path(__file__).with_name("passive-correlation-result.json")


def as_iso(ns):
    # File times are Unix nanoseconds; output an ISO UTC time, never contents.
    from datetime import UTC, datetime
    return datetime.fromtimestamp(ns / 1_000_000_000, UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


old_cases = json.loads(OLD.read_text(encoding="utf-8"))
message_names = {}
for case in old_cases:
    for event in case.get("events", []):
        name, digest = event.get("source_matched_static_event"), event.get("message_sha256")
        if isinstance(name, str) and isinstance(digest, str):
            message_names[digest] = name

log = RUNTIME / "home" / "logs" / "unified.jsonl"
events = []
runtime_mode = "unknown_no_whitelisted_boolean_mode_field_recorded"
for ordinal, raw in enumerate(log.read_bytes().splitlines(), 1):
    try:
        row = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError):
        continue
    if not isinstance(row, dict):
        continue
    message = row.get("msg")
    name = message_names.get(hashlib.sha256(message.encode("utf-8")).hexdigest()) if isinstance(message, str) else None
    if name:
        events.append({"ordinal": ordinal, "timestamp": row.get("ts"), "static_event": name})
    # A mode result may only be reported if a fixed, nonsecret boolean field exists.
    ctx = row.get("ctx")
    if isinstance(ctx, dict):
        for key in ("process_chat_mode_enabled", "chat_mode_enabled"):
            if isinstance(ctx.get(key), bool):
                runtime_mode = "chat_mode_enabled" if ctx[key] else "chat_mode_disabled"

selection = next((item for item in events if item["static_event"] == "auth method selection"), None)
catalog_names = {
    "model catalog: auth refresh watcher started": "watcher_started",
    "model catalog: fetching": "request_started",
    "model catalog: fetch succeeded": "request_completed",
    "model catalog: retry succeeded": "request_completed_after_retry",
    "model catalog: auth refresh watcher updated catalog": "watcher_updated_catalog",
}
catalog = [{"timestamp": item["timestamp"], "state": catalog_names[item["static_event"]]}
           for item in events if item["static_event"] in catalog_names]

inventory = {str(path.relative_to(RUNTIME)).replace("\\", "/"): path.stat() for path in (
    RUNTIME / "home" / "settings_cache.json", RUNTIME / "home" / "models_cache.json")}
caches = {name: {"size": stat.st_size, "created_utc": as_iso(stat.st_ctime_ns),
                 "modified_utc": as_iso(stat.st_mtime_ns), "content_inspection": "metadata_only"}
          for name, stat in inventory.items()}

historical = next(case for case in old_cases if case.get("case") == "successful_constant_smoke")
historical_events = [{"timestamp": e.get("ts"), "static_event": e.get("source_matched_static_event")}
                     for e in historical.get("events", [])
                     if e.get("source_matched_static_event") in {
                         "auth method selection", "model catalog: fetching", "model catalog: fetch succeeded",
                         "model catalog: notifying clients", "session created"}]

result = {
    "schema": "grok-cli-passive-correlation-v1",
    "inputs": {"runtime_unified_log": "home/logs/unified.jsonl",
               "historical_safe_correlation": str(OLD),
               "raw_log_lines_emitted": False, "auth_or_credential_values_emitted": False,
               "memtrace_read": False},
    "r2": {"resolved_runtime_mode": runtime_mode, "auth_selection": selection,
           "catalog_lifecycle_static_records": catalog,
           "catalog_request_start": "unknown_no_matching_static_record",
           "catalog_request_completion": "unknown_no_matching_static_record",
           "catalog_request_cancel": "unknown_no_matching_static_record",
           "cache_metadata": caches,
           "response_bytes": "zero_per_existing_public_closure"},
    "historical_success_safe_stages": historical_events,
    "interpretation_limits": [
        "Static records are not a complete execution trace.",
        "Public source is not revision-matched to the 1.0.30 binary.",
        "Cache timestamps establish file materialization only, not a network result or ACP publication."
    ]
}
OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"output": OUT.name, "r2_static_events": len(events),
                  "r2_catalog_records": len(catalog), "runtime_mode": runtime_mode,
                  "raw_log_lines_emitted": False, "memtrace_read": False}))
