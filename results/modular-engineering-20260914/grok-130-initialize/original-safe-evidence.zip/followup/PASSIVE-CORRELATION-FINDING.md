# Passive correlation closure: r2 versus historical success

## Method and safety boundary

`passive_correlation.py` read only the already-preserved r2 unified log,
metadata for the two nonsecret cache files, and the existing historical
`safe-log-correlation.json`. It outputs fixed static stage labels, timestamps,
cache metadata, and unknown states. It emits no raw log records, authentication
or credential values, request bodies, headers, or memtrace data. No process was
launched or attached.

Result: `passive-correlation-result.json` (SHA-256
`57f516401b1eed3837e6189997c3f6a610908edbe0c7ee489411b10d1a085119`).
Extractor: `passive_correlation.py` (SHA-256
`ba65762d108bfbe8d954cbe33d56d39649834af91b69f21f03c7fb122fdffbc0`).

## r2 outcome

- **Resolved runtime mode: unknown.** No whitelisted boolean runtime-mode field
  was recorded in the preserved log. The frozen configuration is not evidence
  of the native resolved mode.
- **Auth selection:** recorded at `2026-09-13T23:35:52.742Z`.
- **Catalog:** a catalog auth-refresh watcher was recorded at
  `2026-09-13T23:35:52.740Z`. There is no matching static record for a catalog
  request start, completion, retry completion, update, or cancellation. Each
  requested lifecycle state is therefore **unknown**, rather than absent.
- **Cache timing:** `settings_cache.json` was created at `23:35:52.479Z`; and
  `models_cache.json` at `23:35:52.735Z` (modified at `.736Z`). Both precede
  auth selection. Metadata establishes local file materialization only; it does
  not prove a network result, cancellation, or ACP response publication.
- **Transport:** the existing public closure records zero response bytes.

The source-to-binary limitation remains: public source is not revision-matched
to 1.0.30 build `04b7ffed98c6`. Any proposed source-path explanation remains a
hypothesis.

## Difference from the historical successful smoke

The historical safe record reached auth selection at `15:12:04.622Z`, then
recorded session creation at `15:12:11.243Z` (6.621 seconds later) and a model
catalog client-notification event at `15:12:11.520Z`. The r2 record shares the
pre-selection auth/catalog-watcher sequence but has neither a response byte nor
a session record. It offers no comparable catalog completion record.

This distinguishes an observed handshake divergence after auth selection. It
does not identify the native instruction or establish a catalog/network cause.

## One concrete next diagnostic option

Request an **official build-to-source mapping or vendor diagnostic statement
for `grok 1.0.30 (04b7ffed98c6)`**, including whether a known ACP initialize
publication defect applies. This discriminates whether the public-main
post-selection control flow can be applied to the pinned executable at all; it
cannot by itself locate the stall. It is preferable to another pass over the
same terminal log because that log has no later static record to classify.
