# Grok 1.0.30 r2 terminal follow-up

Scope: post-run, read-only inspection of files created under the r2 private `home`, `profile`, and `private-receipt` directories. No native launch, configuration change, global update, credential-body inspection, memory/stack capture, prompt, model request, account RPC, or retry was performed.

## Verified outcome

The approved r2 envelope sent exactly one client `initialize` frame. Its private request bytes hash to the approved wire SHA-256 `4ff2a6301d0f60b08451d890fb2bff5ee7067be81658cd46845e64bc1edac4dd`. The public closure records zero `session/new`, authentication, account/billing, and `session/prompt` client frames; no stdout/stderr bytes; a 60.156-second timeout; and a closed Windows process tree. The frozen five launch inputs and the global 1.0.13 executable were reverified after shutdown.

The sanitized inventory contains 46 files. `home/auth.json` appears only as filename/size/timestamp metadata and was neither read nor hashed. `home/memtrace/**` is inventory-only and its content/hash is excluded. The original raw logs remain in place; the safe hash index contains only `home/logs/unified.jsonl` plus the private request/stream/reservation/public-closure files.

## Startup stage comparison

The r2 unified log parses cleanly. A redaction extractor maps r2 message identities only to pre-existing source-matched static event names from the prior safe correlation; it emits no log text, token, header, auth body, or message hash.

The observed r2 order is:

1. Auth manager construction and isolated auth-file load.
2. Model-catalog auth-refresh watcher started at `2026-09-13T23:35:52.740Z`.
3. `agent initialized` at `23:35:52.741Z`.
4. Initialize-specific auth disk refresh, token-state handling, ACP `auth_methods` construction, and auth-method selection at `23:35:52.741Z`--`23:35:52.742Z`.
5. No subsequent ACP response byte before the bounded shutdown.

Therefore, 1.0.30 **did enter both the auth path and model-catalog setup**. The available r2 events show only the catalog watcher starting; they do not show a catalog fetch success. The older original authoring timeout separately recorded catalog fetch success before its own timeout. These observations rule out a claim that r2 stalled before auth/catalog entry, but do not identify a precise blocked operation or prove a common cause.

## Launch-vector correction

The old production `native_launch` source builds `[exe, '--no-auto-update', '--cwd', cwd, 'agent', 'stdio']`. The historical successful 1.0.13 constant-smoke frozen command also contained `--no-auto-update`; the old 1.0.13 initialize-only timeout invoked that same production constructor. Thus absence of that flag from 1.0.13 `--help` does not establish that the exact binary rejected it.

r2 used `[pinned-1.0.30-exe, '--cwd', cwd, 'agent', 'stdio']` with process-scoped `GROK_DISABLE_AUTOUPDATER=1`; its explicit configuration byte-equals the old diagnostic-8192 configuration and continues to pin `grok-4.6`. This flag-vs-environment difference is a remaining uncontrolled difference, not a demonstrated cause of the timeout. No model-pin change is proposed.

## Concrete next option

Do not retry initialization. The evidence now points past initial auth construction and into the post-auth/response-publication region, while catalog completion remains unknown in r2. The next evidence-based option is a separately reviewed, non-memory/non-stack diagnostic that can distinguish a post-auth handler wait from ACP response publication without issuing another native initialization. If no such passive artifact exists, retain the terminal finding rather than widening invasive observation.

Artifacts: [sanitized runtime metadata](sanitized-runtime-metadata.json), [safe archive index](safe-archive-index.json), and the preserved r2 public closure referenced therein.
