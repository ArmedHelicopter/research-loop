"""Prepare one zero-prompt configuration comparison; do not launch Grok."""
import hashlib
import json
from pathlib import Path
import shutil

work = Path('E:/_ryanDev/AI/research-loop-modular/work')
old = work / 'init-only-1.0.30-r2'
root = work / 'init-only-1.0.30-cap128-r1'
assert not root.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(old / 'driver.py') == '8f31e9ec44d6e864c93f5cd35ce411df8a2435df440d458553c5304a31442db0'
assert sha(old / 'home/config.toml') == '223b0a69981328a1e45a93c88265934b99c9aaaeb2b0ff8c4e3177edeb98264c'
config = (old / 'home/config.toml').read_bytes()
assert config.count(b'max_completion_tokens = 8192') == 2
config = config.replace(b'max_completion_tokens = 8192', b'max_completion_tokens = 128')
root.mkdir()
for name in ('home', 'profile', 'cwd'):
    (root / name).mkdir()
(root / 'home/config.toml').write_bytes(config)
# Copy the user's already-authorized existing login opaquely. Never parse or hash it.
auth_source = Path('C:/Users/Administrator/.grok/auth.json')
shutil.copy2(auth_source, root / 'home/auth.json')
config_sha = sha(root / 'home/config.toml')
original_wrapper = (old / 'driver.py').read_bytes()
old_sha = b'223b0a69981328a1e45a93c88265934b99c9aaaeb2b0ff8c4e3177edeb98264c'
assert original_wrapper.count(old_sha) == 1
wrapper = original_wrapper.replace(old_sha, config_sha.encode())
(root / 'driver.py').write_bytes(wrapper)
assert wrapper.replace(config_sha.encode(), old_sha) == original_wrapper
envelope = json.loads((old / 'frozen-envelope.json').read_bytes())
envelope.update(schema='reviewed-grok-initialize-cap-comparison-v1', prepared_at='2026-09-14',
    experiment='One initialize-only test of the recorded completion-cap difference; no prompt or account RPC.',
    comparator_envelope_sha256=sha(old / 'frozen-envelope.json'),
    comparator_terminal_closure_sha256=sha(old / 'private-receipt/public-closure.json'),
    interpretation='A response would justify a fresh launch-configuration investigation; a timeout does not prove cap independence. Time, paths, login state, and network are not controlled.',
    runtime_not_yet_executed=True,
    private_paths={'grok_home':str(root/'home'), 'profile':str(root/'profile'), 'cwd':str(root/'cwd')},
    explicit_config={'model':'grok-4.6','main_completion_cap':128,
        'changed_settings_from_1_0_30_r2':['models.max_completion_tokens:8192->128','model.grok-4.6.max_completion_tokens:8192->128']},
    retained_predecessors=envelope['retained_predecessors']+['work/init-only-1.0.30-r2'])
envelope['frozen_files'] = {str(root/'driver.py'):sha(root/'driver.py'),str(root/'home/config.toml'):config_sha,
    **{p:h for p,h in envelope['frozen_files'].items() if p not in (str(old/'driver.py'),str(old/'home/config.toml'))}}
stat = (root/'home/auth.json').stat()
envelope['auth_copy']['metadata_before']={'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}
(root/'frozen-envelope.json').write_text(json.dumps(envelope,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'prepared':str(root),'envelope_sha256':sha(root/'frozen-envelope.json'),
    'wrapper_sha256':sha(root/'driver.py'),'config_sha256':config_sha,
    'actual_launches':0,'only_wrapper_change':'expected config digest','only_config_changes':2,
    'zero_session_new_authenticate_account_prompt_requests':True}))
