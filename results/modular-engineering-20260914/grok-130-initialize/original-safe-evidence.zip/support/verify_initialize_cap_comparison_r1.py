"""Post-run read-back; never parse or hash login contents."""
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('E:/_ryanDev/AI/research-loop-modular/work/init-only-1.0.30-cap128-r1')
out=root/'public-verification.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
envelope=json.loads((root/'frozen-envelope.json').read_bytes())
closure=json.loads((root/'private-receipt/public-closure.json').read_bytes())
def metadata(path):
    stat=Path(path).stat();return {'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}
pid=closure['native_process_id']
listed=subprocess.check_output(['tasklist','/FI',f'PID eq {pid}','/FO','CSV','/NH'],text=True)
# tasklist has localized "no tasks" output; a live row would include this exact quoted PID.
alive=f'"{pid}"' in listed
result={'schema':'grok-initialize-cap-comparison-verification-v1',
    'envelope_sha256':sha(root/'frozen-envelope.json'),'closure_sha256':sha(root/'private-receipt/public-closure.json'),
    'frozen_files_match':{path:sha(path)==digest for path,digest in envelope['frozen_files'].items()},
    'global_executable_unchanged':sha('C:/Users/Administrator/.grok/bin/grok.exe')=='bf43dc75f5478a106eab1e86d422c963e4dbe9666cf14dab363733d27bf1e672',
    'global_auth_metadata_unchanged':metadata('C:/Users/Administrator/.grok/auth.json')==envelope['auth_copy']['metadata_before'],
    'private_auth_metadata_changed':metadata(root/'home/auth.json')!=envelope['auth_copy']['metadata_before'],
    'auth_body_or_hash_inspected':False,'native_pid_still_live':alive,
    'process_tree_closed':closure['process_tree_closed'],'accepted_initialize':closure['accepted_initialize'],
    'faults':closure['faults'],'outbound_method_counts':closure['outbound_method_counts'],
    'known_model_usage':None,'settled_additional_charge_usd':None,
    'interpretation':'128 completion cap did not restore initialize in this run; no causal exclusion or account/model readiness conclusion.'}
result['verified']=all(result['frozen_files_match'].values()) and result['global_executable_unchanged'] and result['process_tree_closed'] and not alive and closure['outbound_method_counts']=={'_x.ai/auto-topup-rule':0,'_x.ai/billing':0,'authenticate':0,'initialize':1,'session/new':0,'session/prompt':0}
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='frozen_files_match'}))
raise SystemExit(not result['verified'])
