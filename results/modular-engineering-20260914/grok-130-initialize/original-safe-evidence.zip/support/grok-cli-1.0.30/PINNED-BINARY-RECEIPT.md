# Pinned Grok CLI 1.0.30 receipt

Date: 2026-09-14 (Asia/Shanghai)  
Purpose: isolated preparation only. No Grok initialization, login, prompt, model/catalog/status/billing request, API key, or global updater was run.

## Artifact

| Item | Value |
| --- | --- |
| Binary | `E:\\_ryanDev\\AI\\research-loop-modular\\work\\grok-cli-1.0.30\\grok.exe` |
| Official source URL | `https://x.ai/cli/grok-1.0.30-windows-x86_64.exe` |
| Architecture | Windows x86_64 |
| Downloaded length | 150,036,808 bytes |
| SHA-256 (local) | `CA24EA63272BA7881261F4A52498D1F5BD884B01DA25845990422A10DD315266` |
| Binary version/build | `grok 1.0.30 (04b7ffed98c6)` |

The URL was derived from the official Windows installer: `install.ps1` resolves a version and platform then downloads `$BaseUrl/grok-$resolvedVersion-$platform.exe`. The official primary and direct-GCS locations both responded HTTP 200 with the recorded content length.

No official main-binary checksum was available at the installer-derived `.exe.sha256` URL: both `https://x.ai/cli/grok-1.0.30-windows-x86_64.exe.sha256` and `https://storage.googleapis.com/grok-build-public-artifacts/cli/grok-1.0.30-windows-x86_64.exe.sha256` returned HTTP 404. The official installer verifies a SHA-256 sidecar for its optional bundled-MinGit zip, but does not retrieve or verify one for the main executable. Thus the recorded SHA-256 is a local identity receipt, not an official release checksum.

## Isolation and safe verification

Only `--version` and `--help` were run, with these process-scoped environment variables:

* `GROK_HOME=E:\\_ryanDev\\AI\\research-loop-modular\\work\\grok-cli-1.0.30\\isolated-home`
* `GROK_DISABLE_AUTOUPDATER=1`

`GROK_HOME` is documented as the configuration-directory override. `GROK_DISABLE_AUTOUPDATER=1` is documented as process-scoped update suppression. Neither existing `C:\\Users\\Administrator\\.grok` state nor the global 1.0.13 executable was changed.

The help surface includes `-p/--single`, `--prompt-file`, `--prompt-json`, `--output-format`, `--tools`, `--disallowed-tools`, `--disable-web-search`, `--no-subagents`, `--max-turns`, `--model`, `--sandbox`, `agent`, `update`, `models`, and `inspect`. Its availability does not establish a zero-tool policy or startup success.

## Current limitation

This pin does not prove the 1.0.30 startup issue is fixed. A future test must use a newly reviewed, isolated zero-prompt envelope, retain `GROK_HOME` isolation and auto-update suppression, and verify emitted runtime events before asserting any model, tool, quota, or billing property.

Sources: https://x.ai/cli/install.ps1 and https://x.ai/build/changelog, verified 2026-09-14.
