import csv,json
with open('/input/public_csv') as f: xs=[float(r['x']) for r in csv.DictReader(f)]
result={'candidate': 49.0, 'auxiliary': [], 'state': [], 'review_checks': [], 'directions': [], 'counter_count': 0, 'choice': None, 'memory_checks': 0}
result['statistic']=sum(xs)/len(xs)+sum(result['auxiliary'])+sum(result['state'])+result['candidate']-result['counter_count']-result['memory_checks']
print(json.dumps(result))