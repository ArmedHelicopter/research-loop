import csv,json
with open('/input/public_csv') as f: rows=list(csv.DictReader(f))
print(json.dumps({'statistic':sum(float(r['x']) for r in rows)/len(rows)}))