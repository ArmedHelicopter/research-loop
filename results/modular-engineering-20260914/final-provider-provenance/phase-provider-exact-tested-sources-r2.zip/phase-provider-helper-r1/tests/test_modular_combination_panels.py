"""Engineering-only combination panel integration checks using public fixtures."""
from pathlib import Path

import pytest

from research_loop.modular.benchmarks import BladeAdapter, DiscoveryBenchAdapter
from research_loop.modular.combination_panels import CombinationPanelVerifier, compile_combination_catalogue, run_combination_cell
from research_loop.modular.combinations import default_compatibility
from research_loop.modular.contracts import DataIdentity, FrozenRecord, PublicTask
from research_loop.modular.experiments import registry
from research_loop.modular.modules.improvement import CandidatePackage, TrainingManifest
from research_loop.modular.panel_receipts import RuntimeReceipt
from research_loop.modular.runtime import AuditVerifier, RunSession
from research_loop.ontology import ContractError

SPLIT = "a" * 64


def _task(benchmark: str) -> PublicTask:
    identity = DataIdentity(benchmark, f"combination-{benchmark}", f"{benchmark}:combination", "fixture-v1", SPLIT, "train")
    if benchmark == "blade":
        return BladeAdapter().prepare(identity, {"task_id": identity.task_id, "dataset_id": "public",
            "research_question": "Which public mechanism is plausible?", "data_schema": [{"name": "x"}]})
    return DiscoveryBenchAdapter().prepare(identity, {"task_id": identity.task_id,
        "question": "Which public mechanism is plausible?", "source_kind": "synthetic",
        "dataset": [{"name": "public", "columns": [{"name": "x"}]}]})


def _inputs():
    tasks = [_task("blade"), _task("discoverybench")]
    manifest = TrainingManifest.freeze([task.identity for task in tasks])
    compatibility = default_compatibility(SPLIT)
    arms = {}
    designs = [*compatibility.all_pairs(),
               *(compatibility.conditional_factorial(triple) for triple in (("M2", "M3", "M5"), ("M4", "M5", "M6"), ("M1", "M4", "M7"), ("M3", "M6", "M9"), ("M7", "M8", "M9"))),
               compatibility.leave_one_out(compatibility.names)]
    for design in designs:
        for row in design.data()["cells"]:
            if row["status"] == "executable":
                arm = FrozenRecord.from_dict(row["arm"])
                if arm.content_hash not in arms:
                    arms[arm.content_hash] = CandidatePackage.create(parent_digest=None, manifest=manifest,
                        changes={"prompt": {"instructions": "predeclared combination arm " + arm.content_hash}}, search_cost=0)
    return tasks, arms, FrozenRecord.from_dict({"scorer": "fixture-independent-unconfigured"}), FrozenRecord.from_dict({"criterion": "engineering only", "contrast_analysis": {"schema": "frozen-combination-contrast-analysis-v1", "direction": "higher_better", "value_range": [0.0, 2.0], "scale": "unit", "missing_policy": "incomplete_reject", "group_weighting": "task_replicate_mean_then_equal_group_mean"}})


def _catalogue():
    tasks, packages, scorer, criteria = _inputs()
    return compile_combination_catalogue(stage="C2-C4-train", tasks=tasks, baseline_digest=SPLIT,
                                         packages_by_arm=packages, scorer=scorer, acceptance_criteria=criteria)


def _run(cell, task: PublicTask, sidecar: Path) -> RuntimeReceipt:
    objective = FrozenRecord.from_dict({"objective": "combination engineering fixture"})
    session = RunSession(task, package_digest=cell.package_digest, arm=cell.runtime_arm, objective=objective,
                         slots=("only",), execution_limit=0, sidecar=sidecar,
                         verifier=AuditVerifier({"audit-a": b"a" * 32, "audit-b": b"b" * 32}), required_audit=("audit",))
    candidate = FrozenRecord.from_dict({"objective_digest": objective.content_hash, "outcome": "unknown", "evidence_ids": [],
                                         "conclusion": "engineering fixture does not score the combination", "programme_complete": False})
    context = FrozenRecord.from_dict({"panel_cell": {"experiment_id": cell.coverage_id, "variant": cell.variant,
        "replicate": cell.replicate, "arm_id": cell.arm_id, "scenario_digest": cell.scenario_digest}})
    assert session.invoke("only", lambda _request: candidate, instruction="Use public inputs only.", module_context=context) == candidate
    terminal = session.finish(candidate)
    trace = sidecar / "trace.jsonl"
    lines = trace.read_text(encoding="utf-8").splitlines()
    output = FrozenRecord.from_dict({"responses": [candidate.data()], "terminal": terminal.data()}).content_hash
    return RuntimeReceipt(cell.key, "succeeded", trace, FrozenRecord(lines[-1]).content_hash, output)


def test_catalogue_freezes_all_obligations_without_relabeling_q_registry():
    catalogue = _catalogue()
    assert len(catalogue.panels) == 42
    assert catalogue.manifest.data()["pair_count"] == 36
    assert catalogue.manifest.data()["triple_count"] == 5
    assert catalogue.manifest.data()["full_loo_count"] == 1
    assert catalogue.manifest.data()["scientific_status"] == "not_measured"
    assert "pair:M1+M4" in catalogue.panels and "pair:M2+M3" in catalogue.panels and "full-loo" in catalogue.panels
    assert all(obligation not in registry() for obligation in catalogue.panels)
    assert set(catalogue.scenarios) == {cell.key for panel in catalogue.panels.values() for cell in panel.cells}
    assert all(catalogue.scenarios[cell.key].content_hash == cell.scenario_digest
               for panel in catalogue.panels.values() for cell in panel.cells)


def test_legal_pair_has_complete_two_benchmark_arm_journals_and_engineering_verification(tmp_path: Path):
    panel = _catalogue().panels["pair:M1+M4"]
    tasks, *_ = _inputs()
    by_identity = {task.identity: task for task in tasks}
    assert len(panel.cells) == 8 and panel.interaction_status == "identifiable"
    rows = tuple(_run(cell, by_identity[cell.identity], tmp_path / cell.identity.benchmark / cell.arm_id) for cell in panel.cells)
    verdict = CombinationPanelVerifier().verify(panel, rows)
    assert verdict.engineering_verified and verdict.observed_cells == 8
    assert verdict.interaction_status == "not_measured" and verdict.scientific_status == "not_measured"
    with pytest.raises(ContractError, match="coverage mismatch"):
        CombinationPanelVerifier().verify(panel, rows[:-1])


def test_dependency_pair_retains_unavailable_cell_and_only_runs_feasible_grid(tmp_path: Path):
    panel = _catalogue().panels["pair:M2+M3"]
    tasks, *_ = _inputs()
    by_identity = {task.identity: task for task in tasks}
    assert panel.interaction_status == "not_identifiable"
    assert [row["id"] for row in panel.structurally_unavailable] == ["01"]
    # The 01 arm would enable M3 without its M2 prerequisite; it has no fake
    # journal.  Every actually legal arm is still run for both adapters.
    assert len(panel.cells) == 6 and {cell.arm_id for cell in panel.cells} == {"00", "10", "11"}
    rows = tuple(_run(cell, by_identity[cell.identity], tmp_path / cell.identity.benchmark / cell.arm_id) for cell in panel.cells)
    verdict = CombinationPanelVerifier().verify(panel, rows)
    assert verdict.engineering_verified and verdict.interaction_status == "not_identifiable"
    assert verdict.scientific_status == "not_measured"


def test_compiler_rejects_candidate_manifest_for_other_training_tasks():
    tasks, arms, scorer, criteria = _inputs()
    foreign = DataIdentity("blade", "foreign", "blade:foreign", "foreign-v1", "b" * 64, "train")
    wrong = CandidatePackage.create(parent_digest=None, manifest=TrainingManifest.freeze([foreign]),
                                    changes={"prompt": {"instructions": "wrong train manifest"}}, search_cost=0)
    with pytest.raises(ContractError, match="exactly this panel task set"):
        compile_combination_catalogue(stage="C2-C4-train", tasks=tasks, baseline_digest=SPLIT,
                                      packages_by_arm={key: wrong for key in arms}, scorer=scorer,
                                      acceptance_criteria=criteria)


def test_production_combination_runner_injects_exact_package_and_scenario(tmp_path: Path):
    catalogue = _catalogue(); panel = catalogue.panels["pair:M1+M4"]
    task = catalogue.tasks[next(cell.task_digest for cell in panel.cells if cell.arm_id == "00")]
    cells = [next(cell for cell in panel.cells if cell.identity == task.identity and cell.arm_id == arm)
             for arm in ("00", "11")]
    seen = []
    def model(request):
        seen.append(request.data()["module_context"])
        objective_digest = request.data()["module_context"]["required_objective_digest"]
        return FrozenRecord.from_dict({"objective_digest": objective_digest, "outcome": "unknown", "evidence_ids": [],
                                       "conclusion": "engineering-only combination response", "programme_complete": False})
    verifier = AuditVerifier({"audit-a": b"a" * 32, "audit-b": b"b" * 32})
    rows = [run_combination_cell(panel, cell, task=task, scenario=catalogue.scenarios[cell.key],
                                 package=catalogue.packages[cell.runtime_arm.content_hash],
                                 objective=FrozenRecord.from_dict({"objective": "combination"}),
                                 sidecar=tmp_path / cell.arm_id, model=model, audit_verifier=verifier)
            for cell in cells]
    assert all(row.status == "succeeded" for row in rows)
    assert seen[0]["candidate_package"] != seen[1]["candidate_package"]
    assert all(context["combination_scenario"]["task_digest"] == task.content_hash for context in seen)
    assert all(context["package_application_status"] == "controller_binding_only_not_module_effect" for context in seen)
    assert all(context["required_objective_digest"] == FrozenRecord.from_dict({"objective": "combination"}).content_hash for context in seen)


def test_all_catalogue_cells_run_through_production_runner_and_verify(tmp_path: Path):
    catalogue = _catalogue()
    verifier = AuditVerifier({"audit-a": b"a" * 32, "audit-b": b"b" * 32})
    def model(request):
        objective_digest = request.data()["module_context"]["required_objective_digest"]
        return FrozenRecord.from_dict({"objective_digest": objective_digest, "outcome": "unknown", "evidence_ids": [],
                                       "conclusion": "synthetic engineering-only combination response", "programme_complete": False})
    total = 0
    for panel_number, (obligation, panel) in enumerate(catalogue.panels.items()):
        rows = []
        for number, cell in enumerate(panel.cells):
            rows.append(run_combination_cell(panel, cell, task=catalogue.tasks[cell.task_digest],
                scenario=catalogue.scenarios[cell.key], package=catalogue.packages[cell.runtime_arm.content_hash],
                objective=FrozenRecord.from_dict({"panel": panel.digest}), sidecar=tmp_path / str(panel_number) / str(number),
                model=model, audit_verifier=verifier))
        verdict = CombinationPanelVerifier().verify(panel, rows)
        assert verdict.decision == "engineering_verified" and not verdict.scientific_verified
        total += len(rows)
    assert total == sum(len(panel.cells) for panel in catalogue.panels.values())


def test_production_runner_retains_model_failure_for_verifier_denominator(tmp_path: Path):
    catalogue = _catalogue(); panel = catalogue.panels["pair:M1+M4"]
    cell = panel.cells[0]
    def failed(_request): raise RuntimeError("synthetic transport failure")
    receipt = run_combination_cell(panel, cell, task=catalogue.tasks[cell.task_digest],
        scenario=catalogue.scenarios[cell.key], package=catalogue.packages[cell.runtime_arm.content_hash],
        objective=FrozenRecord.from_dict({"panel": panel.digest}), sidecar=tmp_path / "failed", model=failed,
        audit_verifier=AuditVerifier({"audit-a": b"a" * 32, "audit-b": b"b" * 32}))
    assert receipt.status == "failed" and receipt.output_digest is None
    events = [FrozenRecord(line).data() for line in receipt.trace_path.read_text(encoding="utf-8").splitlines()]
    assert events[-1]["stage"] == "model_failure"


def test_context_builder_failure_retains_zero_call_cells(tmp_path: Path, monkeypatch):
    from research_loop.modular.modules.context import ContextBuilder
    tasks, packages, scorer, criteria = _inputs()
    def context_fault(*_args, **_kwargs):
        raise ContractError("injected context construction failure before request")
    monkeypatch.setattr(ContextBuilder, "build", context_fault)
    catalogue = compile_combination_catalogue(stage="context-construction-failure", tasks=tasks,
        baseline_digest=SPLIT, packages_by_arm=packages, scorer=scorer, acceptance_criteria=criteria)
    panel = catalogue.panels["pair:M1+M4"]
    calls = []
    def model(request):
        calls.append(request)
        raise AssertionError("context should fail before provider I/O")
    receipts = [run_combination_cell(panel, cell, task=catalogue.tasks[cell.task_digest],
        scenario=catalogue.scenarios[cell.key], package=catalogue.packages[cell.runtime_arm.content_hash],
        objective=FrozenRecord.from_dict({"panel": panel.digest}), sidecar=tmp_path / str(index),
        model=model, audit_verifier=AuditVerifier({"a": b"a" * 32, "b": b"b" * 32}))
        for index, cell in enumerate(panel.cells)]
    assert not calls
    assert all(row.status == "failed" for row in receipts)
    verdict = CombinationPanelVerifier().verify(panel, receipts)
    assert verdict.failures == verdict.observed_cells == len(panel.cells)
