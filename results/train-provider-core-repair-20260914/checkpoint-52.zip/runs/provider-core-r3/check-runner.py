import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path(sys.argv[1]); out=Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['TEMP']=env['TMP']=str(out/'temp');Path(env['TEMP']).mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
assert not git('status','--porcelain'), 'source not clean'
files=[p for p in git('ls-files').splitlines() if not p.startswith(('results/','data/'))]
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files if (repo/p).is_file()}
before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2))
cmd=[sys.executable,'-m','pytest','-q','tests/test_train_provider.py','tests/test_modular_model_port.py','tests/test_label_isolation.py','tests/test_grok_train_solver.py::test_native_original_substitution_closes_before_later_io','tests/test_grok_train_solver.py::test_invented_native_receipt_closes_ledger','tests/test_grok_train_solver.py::test_unknown_reserved_opportunity_stays_closed_after_restart','--basetemp',str(out/'pytest'),'--junitxml',str(out/'pytest.xml')]
start=time.time()
with (out/'pytest.stdout.txt').open('wb') as log:result=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2))
report={'source_commit':git('rev-parse','HEAD'),'command':cmd,'exit_code':result.returncode,'seconds':time.time()-start,'source_hash_count':len(before),'source_unchanged':before==after,'clean_status':git('status','--porcelain'),'real_model_or_api_calls':0,'scope':'synthetic provider core only; no scientific scoring'}
(out/'check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));sys.exit(result.returncode)

