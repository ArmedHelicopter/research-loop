# TRAIN provider core synthetic engineering evidence

Tested source: `6bae59a2258c3fbc4ecd6beaf5c4ed10cac24165`. Final frozen check: 52 tests, 0 failures, 0 errors; 631 tracked non-results/data source files unchanged. Zero real model/API calls; no scientific validation.

The first failed run is retained intact except opaque fixture login files. Its 12 failures came from two new fixture assumptions (profile directory emptiness after native environment preparation, and an unsupported schema keyword). The next checkpoint passed 20 tests. The final run covers the core plus bounded existing Codex-port, native replay and label-isolation regressions. Each run retains exact stdout/XML, source hash manifests, command, synthetic native originals, original runtime ledgers and sidecar seals. Failed and tampered outputs are evidence, never score-eligible results.

Native peers enter through the actual default run_native_train and native_launch checks; only executable identity and OS spawn are synthetic. No native Grok executable is launched. Native MAIN known usage is separate from unknown TITLE/all-opportunity totals and settlement. Codex synthetic runners preserve the reviewed context contract.

original-copy-map.json maps retained original paths to byte-identical archive members. All original paths in this archive refer to synthetic E-drive fixtures or checked public source. Opaque auth.json and synthetic login-backup.json files are excluded without reading their bodies. Source snapshots are exact bytes from the final checked worktree. Earlier source commits and exact source hashes remain recorded separately; snapshots are not substituted for earlier versions.

No existing controller admission, _safe_call, FrozenProviderLedger, legacy Codex/Grok schema, or prior archive was changed. Wave 1 enables no new experiment by itself. Controller-specific versioned envelopes and integration remain downstream work. C5 selection/calibration/validation remains unresolved.

The archive-local .gitattributes disables text conversion before staging. MANIFEST.json hashes every other archive payload member. The adjacent ZIP contains the same member bytes; committed Git blobs must also match these bytes.
