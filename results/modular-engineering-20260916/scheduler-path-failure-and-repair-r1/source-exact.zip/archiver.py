"""Retain closed scheduler startup failure and zero-call packet roundtrip evidence."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

BASE = Path('E:/_ryanDev/AI/research-loop-modular')
WORK = BASE / 'work'
OUT = BASE / 'artifact-evidence-provenance/results/modular-engineering-20260916/scheduler-path-failure-and-repair-r1'
RETAINED = BASE / 'retained-private-evidence/scheduler-path-failure-and-repair-r1'
PREP = WORK / 'actual-exploration-scheduler-grok130-preparation-r1'
RUN = WORK / 'actual-exploration-scheduler-grok130-run-r1'
PRIVATE = BASE / 'custody-private/actual-exploration-scheduler-grok130-r1'
COMMIT = '43ccf107186f730884e64c230d3abe4bfa555d65'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def secret(path):
    return path.name.lower() == 'auth.json' or path.suffix.lower() == '.key'

def inventory(root):
    rows = {}
    for here, dirs, names in os.walk(root):
        for name in dirs + names:
            p = Path(here) / name
            if p.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise RuntimeError('reparse input refused')
        for name in names:
            p = Path(here) / name
            if not secret(p):
                rows[p.relative_to(root).as_posix()] = p
    return rows

def meta(path):
    raw = path.read_bytes()
    return {'sha256': sha(raw), 'bytes': len(raw)}

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def archive(path, sources):
    before = {name: meta(p) for name, p in sources.items()}
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED) as z:
        for name, p in sources.items():
            z.writestr(name, p.read_bytes())
    with zipfile.ZipFile(path) as z:
        assert z.namelist() == list(sources)
        for name, expected in before.items():
            raw = z.read(name)
            assert {'sha256': sha(raw), 'bytes': len(raw)} == expected
    assert before == {name: meta(p) for name, p in sources.items()}
    return before

def main():
    assert not OUT.exists() and not RETAINED.exists()
    old = WORK / 'run_actual_exploration_scheduler_grok130_r1.py'
    new = WORK / 'run_actual_exploration_scheduler_grok130_r2.py'
    proof_path = WORK / 'actual-scheduler-public-packet-roundtrip-r2.json'
    proof = read(proof_path)
    assert sha(old.read_bytes()) == proof['previous_helper_sha256'] == 'cc723f75315b38517db38c67fefd58410403b64a43320d24f1fb9478e878ca27'
    assert sha(new.read_bytes()) == proof['helper_sha256'] == '99beb6de3b6bd2bb2633f2cafdf57dd2f6df99a494efdfeaf167f020501a7140'
    assert proof['source_commit'] == COMMIT and proof['original_path_failure_reproduced'] is True
    assert proof['new_keyword_packet_fields_match_export'] is True and proof['cells'] == 8
    assert all(proof[k] == 0 for k in ('model_calls', 'auth_reads', 'docker_calls'))
    assert proof['validation_opened'] is False
    public = {'repair/roundtrip.json': proof_path, 'failure/worker.json': RUN / 'actual-exploration-scheduler-worker-failure.json'}
    for kind, session, code in (('prepare', 39274, 0), ('run', 84170, 1)):
        start = WORK / f'actual-exploration-scheduler-grok130-{kind}-r1-native-start.json'
        join = WORK / f'actual-exploration-scheduler-grok130-{kind}-r1-native-join.json'
        assert read(start)['session_id'] == read(join)['native_session_id'] == session
        assert read(join)['result']['exit_code'] == code and read(join)['source_commit'] == COMMIT
        public[f'native/{kind}-start.json'] = start
        public[f'native/{kind}-join.json'] = join
    closure = read(RUN / 'parent-closure.json')
    assert closure['source_and_inputs_unchanged'] is True and closure['summary'] is None
    assert closure['process']['owned_tree_closed'] is True and closure['process']['process_exit_code'] == 1
    assert closure['process']['timed_out'] is False and closure['validation_opened'] is False
    failure = read(public['failure/worker.json'])
    assert failure['error_type'] == 'ContractError' and failure['message'] == 'prospective packet paths differ from token binding'
    ledger = read(PRIVATE / 'solver-model/ledger.json')
    assert ledger['calls'] == [] and ledger['known_main_tokens'] == 0 and ledger['usage_incomplete'] is False
    assert not (PRIVATE / 'evaluator-model').exists()
    retained = {}
    for prefix, root in (('preparation', PREP), ('run', RUN), ('private', PRIVATE)):
        retained.update({prefix + '/' + name: p for name, p in inventory(root).items()})
    OUT.mkdir(parents=True)
    RETAINED.mkdir(parents=True)
    source_members = archive(OUT / 'source-exact.zip', {'r1.py': old, 'r2.py': new, 'archiver.py': Path(__file__)})
    public_members = archive(OUT / 'public-metadata.zip', public)
    private_members = archive(RETAINED / 'retained-private-raw.zip', retained)
    manifest = {'schema': 'scheduler-path-failure-and-repair-archive-v1', 'source_commit': COMMIT,
        'attempt': {'native_session_id': 84170, 'exit_code': 1, 'expected_cells': 8, 'completed_experiment': False,
            'main_calls': 0, 'solver_reservations': 0, 'known_main_tokens': 0, 'evaluator_constructed': False},
        'repair': proof, 'validation_opened': False, 'scientific_effectiveness': 'not_measured',
        'source_members': source_members, 'public_members': public_members,
        'retained_private_members': private_members, 'credential_rule': 'auth.json and authority .key bytes excluded',
        'private_archive': {'path': str(RETAINED / 'retained-private-raw.zip'), **meta(RETAINED / 'retained-private-raw.zip')}}
    write(OUT / 'manifest.json', manifest)
    (OUT / '.gitattributes').write_bytes(b'* -text\n')
    (OUT / 'README.md').write_text('# Scheduler startup failure and repair\n\n'
        'The original eight-cell TRAIN attempt exited 1 before any model call because the reconstructed packet path was a directory instead of public.json. '
        'Its original native join, failure, empty solver ledger and parent closure are retained. '
        'The new helper reproduces the original rejection and reconstructs the same two exported public TRAIN packets to the same frozen eight-cell panel. '
        'This archive establishes the binding repair only; it contains no claim of benchmark improvement or validation acceptance.\n\n'
        'Original preparation/run/provider bytes are retained in the private archive referenced by manifest.json; auth files and signing keys are excluded. '
        'Public ZIP members and their hashes are checked byte for byte. The revised helper is frozen for a distinct r2 attempt.\n', encoding='utf-8', newline='\n')
    files = [{'path': p.name, **meta(p)} for p in sorted(OUT.iterdir()) if p.is_file()]
    write(OUT / 'published-manifest.json', {'schema': 'published-evidence-files-v1', 'files': files})
    print(json.dumps({'archive': str(OUT), 'public_members': len(public_members), 'private_members': len(private_members),
        'canonical_files': len(files) + 1, 'published_manifest': meta(OUT / 'published-manifest.json')}))

if __name__ == '__main__':
    main()
