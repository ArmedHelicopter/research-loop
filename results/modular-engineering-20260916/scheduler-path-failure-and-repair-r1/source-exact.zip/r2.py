"""Prepare and execute one bounded actual TRAIN M7xM8 scheduler panel.

The solver receives only two freshly exported public TRAIN packets.  A separate
scorer worker owns the protected reference store and its distinct authority.
Preparation freezes source, inputs, deployment and evaluator binding before any
MAIN call; a child executes once, while the parent always leaves a closure.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone

WORK = Path(__file__).parent
BASE = WORK.parent
TREE = BASE / "csv-measurement-authorities-r2"
MAP = WORK / "actual-m4m5-train-material-map-r1.json"
REQUEST = WORK / "primary-prospective-export-live-r1" / "frozen-request-r1.json"
PUBLICATION = WORK / "primary-prospective-reference-live-r1" / "reference-publication-r1.json"
EXECUTABLE = WORK / "grok-cli-1.0.30" / "grok.exe"
PREP = WORK / "actual-exploration-scheduler-grok130-preparation-r2"
RUN = WORK / "actual-exploration-scheduler-grok130-run-r2"
PRIVATE = BASE / "custody-private" / "actual-exploration-scheduler-grok130-r2"
AUTH = Path(os.environ.get("GROK_TRAIN_AUTH_PATH", "C:/Users/Administrator/.grok/auth.json"))
APPROVED_ACCOUNT_SHA256 = "b13ba3f652654cf9907b60161d7cd397e5edd8da74646e642e4105768d511c2e"
APPROVED_OIDC_CLIENT_ID = "b1a00492-073a-47ea-816f-4c329264a828"
FAMILY = "exploration_scheduler"
IMAGE = "research-benchmark-python@sha256:1433f0d223b0773b0d8c3184fa4ff6ab0a3891113442f1592d8d7e883d21a349"
EXECUTOR = "actual-exploration-scheduler-grok130-executor-r2"
SCORER = "actual-exploration-scheduler-grok130-scorer-r2"
RECOVERY = {"schema": "headless-account-read-recovery-v1", "max_attempts": 2}
sys.path.insert(0, str(TREE))


def sha(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path: Path | str) -> dict:
    return json.loads(Path(path).read_bytes())


def write(path: Path | str, body: dict) -> None:
    from research_loop.ontology import canonical
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(canonical(body) + "\n")


def desc(path: Path | str) -> dict:
    path = Path(path)
    return {"path": str(path.resolve()), "sha256": sha(path)}


def _account(path: Path) -> None:
    """Validate an OIDC-shaped account file without exposing its values."""
    records = [row for row in read(path).values() if isinstance(row, dict)
               and row.get("auth_mode") == "oidc" and row.get("oidc_issuer") == "https://auth.x.ai"
               and row.get("oidc_client_id") == APPROVED_OIDC_CLIENT_ID]
    if (len(records) != 1 or not isinstance(records[0].get("user_id"), str)
            or hashlib.sha256(records[0]["user_id"].encode()).hexdigest() != APPROVED_ACCOUNT_SHA256):
        raise RuntimeError("specifically approved OIDC TRAIN account binding is unavailable")


def _environment() -> dict[str, str]:
    allowed = {"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "PATHEXT", "PATH", "TEMP", "TMP"}
    env = {key: value for key, value in os.environ.items() if key.upper() in allowed}
    env.update(PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    return env


def _commit() -> str:
    return subprocess.check_output(["git", "-C", str(TREE), "rev-parse", "HEAD"], text=True).strip()


def _map() -> dict:
    body = read(MAP)
    rows = body.get("selected_public_train_items")
    if (body.get("schema") != "actual-m4m5-train-material-map-v1" or not isinstance(rows, list)
            or len(rows) != 2 or {row.get("source") for row in rows} != {"blade", "discoverybench"}
            or body.get("limits", {}).get("train_only") is not True
            or body.get("limits", {}).get("validation_access_enabled") is not False
            or not isinstance(body.get("selected_token_allowlist"), list)
            or any(not isinstance(row.get("identity_digest"), str) or not isinstance(row.get("task_sha256"), str)
                   or not isinstance(row.get("csv_sha256"), str) for row in rows)):
        raise RuntimeError("exact two-item TRAIN map is unavailable")
    return body


def _selected() -> list[dict]:
    mapping = _map()
    rows = mapping["selected_public_train_items"]
    selected = [min((row for row in rows if row["source"] == benchmark), key=lambda row: row["token"])
                for benchmark in ("discoverybench", "blade")]
    if [row["token"] for row in selected] != mapping["selected_token_allowlist"]:
        raise RuntimeError("exact two authorized TRAIN identities are not the frozen map allowlist")
    return selected


def _normalized(raw: bytes) -> bytes:
    return raw.replace(b"\r\n", b"\n")


def _closed_prefix(check: Path) -> Path:
    if not check.name.endswith("-closed.json"):
        raise RuntimeError("engineering evidence must be an immutable -closed.json receipt")
    return Path(str(check).removesuffix("-closed.json"))


def _junit_cases(report: Path) -> list:
    return list(ET.parse(report).getroot().iter("testcase"))


_LABEL_CASES = {
    "test_every_task_has_a_label", "test_prompts_do_not_contain_label_payloads",
    "test_error_catching_every_task_has_a_label", "test_error_catching_prompts_do_not_contain_label_payloads",
    "test_iteration_every_task_has_a_label", "test_iteration_prompts_do_not_contain_label_payloads",
    "test_audit_contrast_every_task_has_a_label", "test_audit_contrast_prompts_do_not_contain_label_payloads",
    "test_true_lock_every_task_has_a_label", "test_true_lock_prompts_omit_gold_rule",
}


def _verify_frozen_check(check: Path, commit: str, selectors: set[str]) -> tuple[dict, list[Path]]:
    """Verify the immutable r4 receipt, native join, JUnit and source ZIP as one unit."""
    prefix = _closed_prefix(check)
    before = Path(str(prefix) + "-before.json")
    start = Path(str(prefix) + "-native-start.json")
    join = Path(str(prefix) + "-native-join.json")
    members = Path(str(prefix) + "-source-members.json")
    report = Path(str(prefix) + ".xml")
    archive = Path(str(prefix) + "-sources.zip")
    gate, before_body, join_body, members_body = read(check), read(before), read(join), read(members)
    if not (gate["commit"] == before_body["commit"] == join_body["source_commit"] == members_body["commit"] == commit):
        raise RuntimeError("frozen check commit binding differs")
    if gate.get("source_unchanged") is not True or before_body["source_before"] != gate["source_after"]:
        raise RuntimeError("frozen check source receipt is incomplete")
    if gate["exit_code"] != 0 or join_body["result"]["exit_code"] != 0 or read(start)["session_id"] != join_body["native_session_id"]:
        raise RuntimeError("frozen check native execution is not cleanly joined")
    junit = gate["junit"]
    if junit["tests"] <= 0 or any(junit[name] != 0 for name in ("failures", "errors", "skipped")):
        raise RuntimeError("frozen check JUnit receipt is not clean")
    if sha(report) != gate["report_sha256"] or sha(archive) != members_body["archive_sha256"]:
        raise RuntimeError("frozen check report or source archive digest differs")
    cases = _junit_cases(report)
    observed = {name: sum(int(row.get(name, 0)) for row in ET.parse(report).getroot().iter("testsuite")) for name in junit}
    if observed != junit or len(cases) != junit["tests"]:
        raise RuntimeError("frozen check JUnit content differs from receipt")
    args = before_body.get("pytest_args")
    if not isinstance(args, list):
        raise RuntimeError("frozen check does not retain pytest selectors")
    for selector in selectors:
        if selector not in args:
            raise RuntimeError("required full-eight scheduler selector is absent")
        module, _, case_name = selector.partition("::")
        if not any(Path(module).stem in str(case.get("classname", "")) and (not case_name or case.get("name") == case_name) for case in cases):
            raise RuntimeError("required full-eight scheduler test is absent from JUnit")
    expected_members = {row["path"]: row["sha256"] for row in members_body["members"]}
    if expected_members != gate["source_after"]:
        raise RuntimeError("frozen source-member manifest differs from receipt")
    with zipfile.ZipFile(archive) as zipped:
        if zipped.namelist() != [row["path"] for row in members_body["members"]]:
            raise RuntimeError("frozen source ZIP member ordering differs")
        for row in members_body["members"]:
            raw = zipped.read(row["path"])
            if hashlib.sha256(raw).hexdigest() != row["sha256"] or len(raw) != row["bytes"]:
                raise RuntimeError("frozen source ZIP member differs")
    return gate, [check, before, start, join, members, report, archive]


def validate_source(engineering_checks: list[Path], labels_check: Path, root_source: Path, runtime_commit: str) -> dict:
    """Read-only admission gate: source, native evidence, exact full-eight test and ten labels."""
    root_source = root_source.resolve()
    if TREE.resolve() != (BASE / "csv-measurement-authorities-r2").resolve() or _commit() != runtime_commit:
        raise RuntimeError("requested immutable CSV actor is not checked out")
    if subprocess.check_output(["git", "status", "--porcelain"], cwd=TREE, text=True).strip() or not (root_source / ".git").exists():
        raise RuntimeError("actor or ROOT source is not an immutable checked-out tree")
    selector = "tests/test_headless_scheduler_evaluator_stdio.py::test_native_scheduler_closes_eight_evaluator_receipts"
    if len(engineering_checks) != 1:
        raise RuntimeError("one current M7xM8 full-eight engineering gate is required")
    engineering, engineering_paths = _verify_frozen_check(engineering_checks[0], runtime_commit, {selector})
    labels, label_paths = _verify_frozen_check(labels_check, read(labels_check)["commit"], {"tests/test_label_isolation.py"})
    label_cases = [case for case in _junit_cases(Path(str(_closed_prefix(labels_check)) + ".xml"))
                   if case.get("classname", "").split(".")[-1] == "test_label_isolation"]
    if len(label_cases) != len(_LABEL_CASES) or {case.get("name") for case in label_cases} != _LABEL_CASES:
        raise RuntimeError("labels gate lacks the exact ten label-isolation cases")
    actor_names = {name for name in subprocess.check_output(["git", "ls-files", "-z"], cwd=TREE).decode().split("\0")
                   if name and not name.startswith("results/") and name.endswith((".py", ".md"))}
    if actor_names != set(engineering["source_after"]):
        raise RuntimeError("full immutable CSV actor source set differs from engineering archive")
    source_pins = {}
    for name in actor_names:
        path = TREE / name
        if sha(path) != engineering["source_after"][name]:
            raise RuntimeError("current CSV actor source differs from frozen engineering archive")
        source_pins[str(path.resolve())] = sha(path)
    runtime_names = {name for name in actor_names if name.endswith(".py") and name.startswith(("research_loop/", "evaluation/"))}
    root_names = {str(path.relative_to(root_source)).replace("\\", "/") for base in ("research_loop", "evaluation")
                  for path in (root_source / base).rglob("*.py")}
    if runtime_names != root_names:
        raise RuntimeError("CSV actor and ROOT production source sets differ")
    for name in runtime_names:
        if _normalized((TREE / name).read_bytes()) != _normalized((root_source / name).read_bytes()):
            raise RuntimeError("CSV actor and ROOT production source differ")
    with zipfile.ZipFile(str(_closed_prefix(labels_check)) + "-sources.zip") as zipped:
        for row in read(str(_closed_prefix(labels_check)) + "-source-members.json")["members"]:
            name = row["path"]
            if name.endswith((".py", ".md")):
                live, archived = (root_source / name).read_bytes(), zipped.read(name)
                if (_normalized(live) != _normalized(archived)) if name.endswith(".md") else (live != archived):
                    raise RuntimeError("ROOT label-gate source parity differs")
    evidence_paths = [*engineering_paths, *label_paths]
    actor_tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=TREE, text=True).strip()
    return {"runtime_commit": runtime_commit, "actor_tree": actor_tree, "root_source": str(root_source), "source_pins": source_pins,
            "engineering_gates": [desc(engineering_checks[0])], "labels_gate": desc(labels_check),
            "evidence_pins": {str(path.resolve()): sha(path) for path in evidence_paths}}


def _assigned_literal(path: Path, name: str) -> dict:
    """Read the exact schema literal from the source test without importing test code."""
    for node in ast.parse(path.read_text(encoding="utf-8"), filename=str(path)).body:
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == name for target in node.targets):
            value = ast.literal_eval(node.value)
            if isinstance(value, dict):
                return value
    raise RuntimeError("validated scheduler schema literal is unavailable")


def _validated_v4_contract() -> tuple[dict, dict, dict[str, str], list[Path]]:
    """Bind schemas and the v4 evaluator fields to the reviewed production/test sources."""
    analysis_source = TREE / "tests/test_modular_combination_train_controller.py"
    final_source = TREE / "tests/test_modular_train_controller.py"
    v4_source = TREE / "tests/test_headless_scheduler_evaluator_stdio.py"
    v4_tree = ast.parse(v4_source.read_text(encoding="utf-8"), filename=str(v4_source))
    family = next((ast.literal_eval(node.value) for node in v4_tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == "FAMILY" for target in node.targets)), None)
    values = {node.value for node in ast.walk(v4_tree) if isinstance(node, ast.Constant) and isinstance(node.value, str)}
    schema = next((value for value in values if value.endswith("-train-controller-config-v4")), None)
    accounting = next((value for value in values if value.startswith("signed_headless_main_")), None)
    if not all(isinstance(value, str) for value in (family, schema, accounting)):
        raise RuntimeError("reviewed v4 scheduler construction is incomplete")
    if "-headless-evaluator-usage-declaration-v1" not in values or "grok-headless-" not in values or "-usage-v1" not in values:
        raise RuntimeError("reviewed v4 evaluator usage construction is incomplete")
    return (_assigned_literal(analysis_source, "ANALYSIS"), _assigned_literal(final_source, "FINAL"),
            {"family": family, "schema": schema, "scorer_token_accounting": accounting},
            [analysis_source, final_source, v4_source])


def _exporter(output: Path, audit: Path):
    from evaluation.modular.primary_prospective_exporter import PrimaryProspectiveTrainExporter
    request, mapping = read(REQUEST), _map()["exporter_constructor"]
    if sha(Path(request["config_path"])) != request["config_raw_sha256"]:
        raise RuntimeError("frozen prospective exporter config differs")
    return PrimaryProspectiveTrainExporter(read(request["config_path"]), Path(mapping["sealed_root"]),
        expected_split_digest=mapping["expected_split_digest"], expected_audit_digest=mapping["expected_audit_digest"],
        expected_split_sha256=mapping["expected_split_sha256"], expected_audit_sha256=mapping["expected_audit_sha256"],
        eligibility_path=Path(mapping["eligibility_path"]), eligibility_sha256=mapping["eligibility_sha256"],
        output_root=output, audit_root=audit)


def _packets(root: Path):
    from evaluation.modular.train_io import PublicTrainPacket
    from research_loop.modular.contracts import DataIdentity, FrozenRecord, PublicTask
    packets = []
    for row in _selected():
        directory, body = root / row["token"], read(root / row["token"] / "public.json")
        task = PublicTask(DataIdentity.parse(body["task"]["identity"]), FrozenRecord.from_dict(body["task"]["payload"]))
        task.identity.require_train()
        packets.append(PublicTrainPacket(task=task, packet_path=directory / "public.json", csv_path=directory / "data.csv", receipt=FrozenRecord.from_dict(body["receipt"])))
    return tuple(packets)


def _material(packet) -> dict:
    """Three independent, truthful public-CSV diagnostics in fixed main/main/probe order."""
    definitions = (
        ("shape-header-row-count", "main", """import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    row_count = sum(1 for _ in reader)
print(json.dumps({'header': header, 'row_count': row_count}, sort_keys=True))
"""),
        ("ordinary-nonempty-cell-counts", "main", """import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    counts = [0 for _ in header]
    for row in reader:
        for index, value in enumerate(row[:len(counts)]):
            if value.strip(): counts[index] += 1
print(json.dumps({'header': header, 'nonempty_by_column': counts}, sort_keys=True))
"""),
        ("probe-missing-and-duplicate-rows", "probe", """import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    rows = list(reader)
missing_cells = sum(1 for row in rows for value in row if not value.strip())
duplicate_rows = len(rows) - len({tuple(row) for row in rows})
print(json.dumps({'header': header, 'missing_cells': missing_cells, 'duplicate_rows': duplicate_rows}, sort_keys=True))
"""),
    )
    jobs = []
    for order, (identity, purpose, program) in enumerate(definitions):
        seed = f"actual-m7m8-public-csv:{packet.task.content_hash}:{order}:{identity}"
        jobs.append({"id": hashlib.sha256((seed + ":job").encode()).hexdigest(), "purpose": purpose,
            "program": "# frozen diagnostic: " + identity + "\n" + program,
            "dependencies": [], "resources": [hashlib.sha256((seed + ":resource").encode()).hexdigest()], "cost_units": 1})
    return {"schema": "exploration-scheduler-material-v1", "identity": packet.task.identity.data(),
        "task_digest": packet.task.content_hash,
        "public_artifacts": [{"artifact": {"artifact_id": "public_csv", "sha256": sha(packet.csv_path),
            "byte_count": packet.csv_path.stat().st_size}, "container_path": "/input/public_csv"}],
        "context_budget_bytes": 16000, "jobs": jobs}


def _key(name: str) -> Path:
    path = PRIVATE / (name + ".key")
    path.write_bytes(secrets.token_bytes(32))
    return path


def prepare(engineering_checks: list[Path], labels_check: Path, root_source: Path, runtime_commit: str) -> None:
    from evaluation.modular.scorer_process import headless_evaluator_descriptor, serialize_combination_panel
    from evaluation.modular.scoring_service import FrozenBenchmarkRubricEndpoint, ScorerConfig
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.exploration_scheduler_combination import SLOTS, registered_design
    from research_loop.modular.exploration_scheduler_controller import _ANALYSIS as SCHEDULER_ANALYSIS
    from research_loop.modular.exploration_scheduler_controller import FrozenExplorationSchedulerTrainConfig, compile_exploration_scheduler_train_panel
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment, GROK_130_SHA256
    from research_loop.modular.modules.improvement import CandidatePackage, TrainingManifest
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider
    from research_loop.modular.train_provider_preflight import HEADLESS_EVALUATOR_SCHEMAS
    from research_loop.ontology import digest

    gate = validate_source(engineering_checks, labels_check, root_source, runtime_commit)
    analysis_schema, final_schema, v4, schema_sources = _validated_v4_contract()
    schemas = {"analysis_program": analysis_schema, "final_answer": final_schema}
    if HEADLESS_EVALUATOR_SCHEMAS[FAMILY] != v4["schema"]:
        raise RuntimeError("production headless evaluator schema differs from reviewed v4 construction")
    if PREP.exists() or RUN.exists() or PRIVATE.exists() or not MAP.is_file() or sha(EXECUTABLE) != GROK_130_SHA256:
        raise RuntimeError("operator requires unused roots and pinned executable")
    deployment = FrozenHeadlessTrainDeployment.create(EXECUTABLE); deployment.verify_executable(EXECUTABLE)
    _account(AUTH); PREP.mkdir(); PRIVATE.mkdir(parents=True)
    exported = _exporter(PREP / "public-for-compile", PREP / "compile-export-audit").export_controller_packets([row["token"] for row in _selected()])
    if len(exported) != 2 or any(packet.task.identity.domain != "train" for packet in exported):
        raise RuntimeError("fresh exporter did not return the exact TRAIN pair")
    reference = _map()["private_reference_store"]
    if sha(PUBLICATION) != reference["publication_sha256"]:
        raise RuntimeError("protected scorer reference publication differs")
    publication = read(PUBLICATION)
    handles = {digest(packet.task.identity.data()): publication["task_handles"][digest(packet.task.identity.data())] for packet in exported}
    if handles != reference["selected_task_handles"]:
        raise RuntimeError("selected scorer handles differ")
    for packet, row in zip(exported, _selected(), strict=True):
        if (packet.task.content_hash != row["task_sha256"] or digest(packet.task.identity.data()) != row["identity_digest"]
                or sha(packet.csv_path) != row["csv_sha256"] or packet.csv_path.stat().st_size != row["csv_byte_count"]):
            raise RuntimeError("fresh exported packet differs from frozen map")
    for role in ("solver", "evaluator"):
        home = PRIVATE / (role + "-home"); home.mkdir(); shutil.copyfile(AUTH, home / "auth.json"); _account(home / "auth.json")
        (PRIVATE / (role + "-profile")).mkdir(); (PRIVATE / (role + "-cwd")).mkdir()
    executor_key, scorer_key = _key(EXECUTOR), _key(SCORER)
    audit_a, audit_b = _key("actual-exploration-scheduler-audit-a-r2"), _key("actual-exploration-scheduler-audit-b-r2")
    public_paths = [path for path in (PREP / "public-for-compile").rglob("*") if path.is_file()]
    pins = {**gate["source_pins"], **gate["evidence_pins"], str(Path(__file__).resolve()): sha(__file__), str(MAP.resolve()): sha(MAP),
        str(REQUEST.resolve()): sha(REQUEST), str(PUBLICATION.resolve()): sha(PUBLICATION), str(EXECUTABLE.resolve()): sha(EXECUTABLE)}
    pins.update({str(path.resolve()): sha(path) for path in [*public_paths, *schema_sources]})
    rubric = ScorerConfig.create(benchmark="core_pair", evaluator_id="frozen-rubric-grok-headless-train-r1", version="1",
        rubric_digest=FrozenBenchmarkRubricEndpoint.rubric_digest())
    evaluator = {"provider_kind": "grok-headless-frozen-evaluator-v1", "executable": str(EXECUTABLE.resolve()),
        "work_root": str((PRIVATE / "evaluator-model").resolve()), "private_home": str((PRIVATE / "evaluator-home").resolve()),
        "private_profile": str((PRIVATE / "evaluator-profile").resolve()), "public_cwd": str((PRIVATE / "evaluator-cwd").resolve()),
        "frozen_files": pins, "evaluator_id": rubric.record.data()["evaluator_id"], "evaluator_version": "1", "model": "grok-4.6",
        "effort": "low", "max_calls": 8, "max_tokens": 8 * 131072, "timeout_seconds": 240,
        "account_read_recovery": RECOVERY, "native_deployment": deployment.record.data()}
    evaluator_provider = {"kind": "grok-headless-frozen-evaluator-v1",
        "configuration_digest": headless_evaluator_descriptor(evaluator)["configuration_digest"]}
    solver = GrokHeadlessTrainModelPort(executable=EXECUTABLE, work_root=PRIVATE / "solver-model", private_home=PRIVATE / "solver-home",
        private_profile=PRIVATE / "solver-profile", public_cwd=PRIVATE / "solver-cwd", frozen_files=pins, max_calls=16,
        schemas=schemas, slot_output_caps={slot: 8192 if slot == "analysis_program" else 2048 for slot in SLOTS},
        slot_input_byte_caps={slot: 262144 for slot in SLOTS}, observed_main_token_cap=131072, account_read_recovery=RECOVERY,
        timeout_seconds=240, deployment=deployment)
    provider = GrokHeadlessTrainProvider(solver).configuration().data()
    baseline = digest({"stage": "actual-exploration-scheduler-grok130-r2", "source_commit": runtime_commit, "items": [row["token"] for row in _selected()]})
    design = registered_design(baseline).data()
    package = CandidatePackage.create(parent_digest=None, manifest=TrainingManifest.freeze([packet.task.identity for packet in exported]), search_cost=0,
        changes={"prompt": {"instructions": "Use only supplied public TRAIN observations. Retain uncertainty and execution failures."}})
    analysis = dict(SCHEDULER_ANALYSIS)
    body = {"schema": v4["schema"], "export_mode": "primary_prospective", "provider": provider,
        "evaluator_usage": {"schema": f'{v4["family"]}-headless-evaluator-usage-declaration-v1', "provider_kind": evaluator_provider["kind"],
            "usage_contract": f'grok-headless-{v4["family"]}-usage-v1', "evaluator_config_digest": evaluator_provider["configuration_digest"]},
        "evaluator_provider": evaluator_provider, "domain": "train", "stage": "actual-exploration-scheduler-grok130-r2",
        "item_ids": [row["token"] for row in _selected()], "task_bindings": {row["token"]: {"identity": packet.task.identity.data(),
            "task_digest": packet.task.content_hash, "csv_sha256": sha(packet.csv_path), "csv_byte_count": packet.csv_path.stat().st_size}
            for row, packet in zip(_selected(), exported, strict=True)}, "baseline_digest": baseline,
        "packages_by_arm": {row["arm_digest"]: package.record.data() for row in design["cells"] if row["status"] == "executable"},
        "scorer": rubric.record.data(), "scorer_handle_bindings": {key: hashlib.sha256(value.encode()).hexdigest() for key, value in handles.items()},
        "acceptance_criteria": {"scope": "train_adapted_only", "contrast_analysis": analysis, "allowed_failures": 0,
            "scientific_promotion": False}, "replicates": ["r1"],
        "allocation": {"model_slots_per_cell": list(SLOTS), "docker_attempts_per_cell": 3, "auxiliary_docker_attempts_per_cell": 2,
            "scorer_calls_per_cell": 1, "scorer_call_limit": 8, "scorer_token_accounting": v4["scorer_token_accounting"]},
        "image": IMAGE, "timeout_seconds": 60, "materials_by_task": {packet.task.content_hash: _material(packet) for packet in exported}}
    config = FrozenExplorationSchedulerTrainConfig(FrozenRecord.from_dict(body))
    compiled = compile_exploration_scheduler_train_panel(config, tuple(exported))
    if len(compiled.panel.cells) != 8:
        raise RuntimeError("frozen scheduler panel no longer covers eight cells")
    server = {"schema": "exploration-scheduler-scorer-process-config-v1", "panel": serialize_combination_panel(compiled.panel, exploration_scheduler=True),
        "scorer_config": rubric.record.data(), "scorer_config_digest": rubric.digest,
        "train_reference_store": {"root": reference["store_root"], "manifest_sha256": reference["manifest_sha256"],
            "inventory_digest": reference["inventory_digest"], "split_digest": reference["split_digest"]}, "task_handles": handles,
        "execution_authority_key_files": {EXECUTOR: str(executor_key.resolve())}, "scorer_authority": {"id": SCORER, "key_file": str(scorer_key.resolve())},
        "evaluator": evaluator}
    solver_spec = {"schema": "actual-exploration-scheduler-grok130-solver-spec-v1", "private_home": str((PRIVATE / "solver-home").resolve()),
        "private_profile": str((PRIVATE / "solver-profile").resolve()), "public_cwd": str((PRIVATE / "solver-cwd").resolve()), "frozen_files": pins,
        "provider_configuration": provider, "native_deployment": deployment.record.data(), "timeout_seconds": 240}
    write(PREP / "controller.json", body); write(PRIVATE / "scorer-server.json", server); write(PRIVATE / "solver-spec.json", solver_spec)
    inputs = {str(path.resolve()): sha(path) for path in (PREP / "controller.json", PRIVATE / "scorer-server.json", PRIVATE / "solver-spec.json")}
    inputs.update({str(path.resolve()): sha(path) for path in (PREP / "public-for-compile").rglob("*") if path.is_file()})
    write(PREP / "preparation.json", {"schema": "actual-exploration-scheduler-preparation-v1", **gate, "runner": desc(__file__),
        "config": desc(PREP / "controller.json"), "panel_digest": compiled.panel.digest, "scorer_server": desc(PRIVATE / "scorer-server.json"),
        "solver_spec": desc(PRIVATE / "solver-spec.json"), "frozen_inputs": {**pins, **inputs},
        "roles": {"executor": EXECUTOR, "scorer": SCORER, "executor_key": str(executor_key.resolve()), "scorer_key": str(scorer_key.resolve()),
            "audit_keys": [str(audit_a.resolve()), str(audit_b.resolve())], "key_sha256": {str(path.resolve()): sha(path) for path in (executor_key, scorer_key, audit_a, audit_b)}},
        "cells": 8, "solver_main_opportunities": 16, "evaluator_main_opportunities": 8, "docker_attempts": 24, "main_retry": False,
        "additional_paid_api_budget": 0, "validation_opened": False, "parent_timeout_seconds": 10800,
        "parent_timeout_basis": "16 solver*240 + 8 evaluator*240 + 24 Docker*60 + bounded overhead", "prepared_at": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"stage": "prepared", "cells": 8, "solver_main_opportunities": 16, "evaluator_main_opportunities": 8,
        "actual_model_calls": 0, "validation_opened": False}), flush=True)


def checked() -> tuple[dict, dict]:
    preparation, body = read(PREP / "preparation.json"), read(PREP / "controller.json")
    if (preparation.get("cells") != 8 or preparation.get("solver_main_opportunities") != 16
            or preparation.get("evaluator_main_opportunities") != 8 or preparation.get("docker_attempts") != 24
            or preparation.get("main_retry") is not False or preparation.get("validation_opened") is not False):
        raise RuntimeError("frozen scheduler allocation differs")
    if sha(__file__) != preparation["runner"]["sha256"] or sha(PREP / "controller.json") != preparation["config"]["sha256"]:
        raise RuntimeError("operator or frozen controller changed")
    if any(sha(path) != digest for path, digest in preparation["frozen_inputs"].items()):
        raise RuntimeError("frozen source or input differs")
    if any(sha(path) != digest for path, digest in preparation["roles"]["key_sha256"].items()):
        raise RuntimeError("authority key binding differs")
    return preparation, body


def worker() -> None:
    """Run exactly one prepared solver/scorer attempt; there is no retry path."""
    from evaluation.modular.linked_scoring import LinkedExecutionAuthority
    from evaluation.modular.scorer_process import CombinationScorerProcessClient
    from evaluation.modular.scoring_service import ScorerConfig
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.exploration_scheduler_controller import FrozenExplorationSchedulerTrainConfig, compile_exploration_scheduler_train_panel, run_exploration_scheduler_train_panel
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.runtime import AuditVerifier
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider

    preparation, body = checked()
    config = FrozenExplorationSchedulerTrainConfig(FrozenRecord.from_dict(body))
    compiled = compile_exploration_scheduler_train_panel(config, _packets(PREP / "public-for-compile"))
    if compiled.panel.digest != preparation["panel_digest"] or len(compiled.panel.cells) != 8:
        raise RuntimeError("prepared scheduler panel differs")
    spec, roles = read(PRIVATE / "solver-spec.json"), preparation["roles"]
    if sha(PRIVATE / "solver-spec.json") != preparation["solver_spec"]["sha256"] or sha(PRIVATE / "scorer-server.json") != preparation["scorer_server"]["sha256"]:
        raise RuntimeError("private scorer or solver specification differs")
    _account(PRIVATE / "solver-home" / "auth.json")
    native = body["provider"]["native_config"]
    backend = GrokHeadlessTrainModelPort(executable=EXECUTABLE, work_root=PRIVATE / "solver-model", private_home=Path(spec["private_home"]),
        private_profile=Path(spec["private_profile"]), public_cwd=Path(spec["public_cwd"]), frozen_files=spec["frozen_files"], max_calls=16,
        schemas=native["schemas"], slot_output_caps=native["slot_output_caps"], slot_input_byte_caps=native["slot_input_byte_caps"],
        observed_main_token_cap=native["observed_main_token_cap"], account_read_recovery=native["account_read_recovery"],
        timeout_seconds=spec["timeout_seconds"], deployment=FrozenHeadlessTrainDeployment(FrozenRecord.from_dict(spec["native_deployment"])))
    model = GrokHeadlessTrainProvider(backend)
    if model.configuration().data() != spec["provider_configuration"] or body["provider"] != spec["provider_configuration"]:
        raise RuntimeError("native solver configuration differs")
    executor_key, scorer_key = Path(roles["executor_key"]).read_bytes(), Path(roles["scorer_key"]).read_bytes()
    service = CombinationScorerProcessClient(panel=compiled.panel, config=ScorerConfig(FrozenRecord.from_dict(body["scorer"])), exploration_scheduler=True,
        evaluator_provider=body["evaluator_provider"], command=[sys.executable, "-m", "evaluation.modular.scorer_process", "--config",
            preparation["scorer_server"]["path"], "--config-sha256", preparation["scorer_server"]["sha256"], "--journal", str((PRIVATE / "scorer-worker.jsonl").resolve())],
        journal_path=RUN / "scorer-client.jsonl", environment=_environment(), response_timeout_seconds=360, task_handle_bindings=body["scorer_handle_bindings"],
        execution_authority_keys={roles["executor"]: executor_key}, scorer_authority_keys={roles["scorer"]: scorer_key})
    try:
        exporter = _exporter(RUN / "public-export", RUN / "export-audit")
        result = run_exploration_scheduler_train_panel(config, custody=None, prospective_exporter=exporter,
            snapshot_root=Path(exporter.config["snapshot_root"]), export_root=exporter.output_root, run_root=RUN / "controller", model=model,
            audit_verifier=AuditVerifier({"a": Path(roles["audit_keys"][0]).read_bytes(), "b": Path(roles["audit_keys"][1]).read_bytes()}),
            execution_authority=LinkedExecutionAuthority(roles["executor"], executor_key), scoring_service=service, scorer_authority_keys={roles["scorer"]: scorer_key})
    finally:
        service.close()
    receipt = result.receipt.data(); finalization = receipt.get("evaluator_final_verification")
    if finalization is None:
        raise RuntimeError("scheduler returned without mandatory evaluator final closure")
    write(RUN / "summary.json", {"schema": "actual-exploration-scheduler-summary-v1", "source_commit": preparation["runtime_commit"],
        "controller_receipt": desc(RUN / "controller" / "controller-receipt.json"), "status": receipt.get("status"), "cells": len(receipt.get("cells", [])),
        "scored_cells": receipt.get("scored_cells"), "eligible_scored_cells": receipt.get("eligible_scored_cells"),
        "failed_cells": receipt.get("failed_cells"), "blocked_cells": receipt.get("blocked_cells"), "actual_docker_attempts": receipt.get("actual_docker_attempts"),
        "actual_scorer_calls": receipt.get("actual_scorer_calls"), "solver_reservations": len(backend.ledger["calls"]),
        "known_solver_main_tokens": backend.ledger["known_main_tokens"], "solver_usage_incomplete": backend.ledger["usage_incomplete"],
        "evaluator_finalization_present": True, "evaluator_score_eligible": finalization.get("score_eligible"),
        "title_and_all_opportunity_settlement": "unknown", "settled_additional_charge_usd": None, "validation_opened": False,
        "scientific_effectiveness_proven": False})
    print(json.dumps(read(RUN / "summary.json")), flush=True)


def run_parent() -> None:
    from research_loop.modular.grok_headless_transport import _child
    preparation, _ = checked()
    if RUN.exists():
        raise RuntimeError("run root already exists; inspect its closure rather than retrying")
    RUN.mkdir(); command = [sys.executable, str(Path(__file__)), "worker"]; timeout = preparation["parent_timeout_seconds"]
    write(RUN / "parent-reservation.json", {"schema": "actual-exploration-scheduler-parent-reservation-v1", "command": command,
        "preparation": desc(PREP / "preparation.json"), "cells": 8, "solver_main_opportunities": 16, "evaluator_main_opportunities": 8,
        "docker_attempts": 24, "additional_paid_api_budget": 0, "main_retry": False, "validation_opened": False, "timeout_seconds": timeout,
        "timeout_basis": preparation["parent_timeout_basis"], "created_at": datetime.now(timezone.utc).isoformat()})
    frozen = {**preparation["frozen_inputs"], str((PREP / "preparation.json").resolve()): sha(PREP / "preparation.json"), **preparation["roles"]["key_sha256"]}
    _, process = _child(command, {"cwd": str(TREE)}, _environment(), RUN / "parent-process", timeout)
    unchanged = all(sha(path) == digest for path, digest in frozen.items())
    summary = read(RUN / "summary.json") if (RUN / "summary.json").is_file() else None
    attempt = read(RUN / "controller" / "controller-attempt.json") if (RUN / "controller" / "controller-attempt.json").is_file() else None
    cells = attempt.get("cells", []) if attempt else None
    complete = bool(summary and process["process_exit_code"] == 0 and not process["timed_out"] and unchanged
        and summary["status"] == "complete_train_engineering" and summary["cells"] == 8 and summary["solver_reservations"] == 16
        and summary["actual_scorer_calls"] == 8 and summary["evaluator_finalization_present"] is True and not summary["solver_usage_incomplete"])
    write(RUN / "parent-closure.json", {"schema": "actual-exploration-scheduler-parent-closure-v1", "process": process,
        "preparation": desc(PREP / "preparation.json"), "source_and_inputs_unchanged": unchanged, "summary": desc(RUN / "summary.json") if summary else None,
        "expected_cells": 8, "observed_cells": None if cells is None else len(cells),
        "observed_failed_cells": None if cells is None else sum(row.get("status") == "failed" for row in cells),
        "observed_blocked_cells": None if cells is None else sum(row.get("status") == "blocked" for row in cells),
        "allocation_observation": None if summary is None else {"solver_reservations": summary["solver_reservations"],
            "actual_scorer_calls": summary["actual_scorer_calls"], "scored_cells": summary["scored_cells"]},
        "experiment_complete": complete, "unknown_or_incomplete": not complete, "validation_opened": False})
    print(json.dumps({"stage": "closed", "exit_code": process["process_exit_code"], "timed_out": process["timed_out"],
        "summary_present": bool(summary), "source_and_inputs_unchanged": unchanged}), flush=True)
    raise SystemExit(int(not complete))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("validate-source", "prepare", "worker", "run"))
    parser.add_argument("--engineering-check", type=Path, action="append")
    parser.add_argument("--labels-check", type=Path)
    parser.add_argument("--root-source", type=Path)
    parser.add_argument("--runtime-commit")
    args = parser.parse_args()
    try:
        if args.action in {"validate-source", "prepare"}:
            if not (args.engineering_check and args.labels_check and args.root_source and args.runtime_commit):
                raise RuntimeError("source validation requires one engineering gate, labels gate, ROOT source, and runtime commit")
            if args.action == "validate-source":
                print(json.dumps(validate_source(args.engineering_check, args.labels_check, args.root_source, args.runtime_commit), sort_keys=True))
            else:
                prepare(args.engineering_check, args.labels_check, args.root_source, args.runtime_commit)
        elif args.action == "worker":
            worker()
        else:
            run_parent()
    except Exception as exc:
        root = RUN if RUN.exists() else PREP if PREP.exists() else WORK
        failure = root / ("actual-exploration-scheduler-" + args.action + "-failure.json")
        if not failure.exists():
            write(failure, {"schema": "actual-exploration-scheduler-failure-v1", "action": args.action, "status": "inconclusive",
                "error_type": type(exc).__name__, "message": str(exc)[:180], "validation_opened": False})
        print(json.dumps({"stage": "failed", "action": args.action, "error_type": type(exc).__name__}), flush=True)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
