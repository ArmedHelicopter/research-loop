"""Freeze, author, and run one actual public-TRAIN M1+M4+M7 panel.

``author`` is deliberately a separate, finite allocation.  It creates the
typed material records consumed by the 16-cell controller; its two MAIN
opportunities are never counted as any of the controller's 48 solver calls.
Nothing is launched by importing this file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import secrets
from datetime import datetime, timezone
import subprocess
import xml.etree.ElementTree as ET
import zipfile
import importlib


WORK = Path(__file__).parent
BASE = WORK.parent
MAP = WORK / 'actual-m4m5-train-material-map-r1.json'
TREE = BASE / 'csv-measurement-authorities-r2'
RUNTIME_COMMIT = '43ccf107186f730884e64c230d3abe4bfa555d65'
EXECUTABLE = WORK / 'grok-cli-1.0.30' / 'grok.exe'
PREP = WORK / 'actual-admission-prediction-exploration-grok130-preparation-r4'
RUN = WORK / 'actual-admission-prediction-exploration-grok130-run-r4'
PRIVATE = BASE / 'custody-private' / 'actual-admission-prediction-exploration-grok130-r4'
FAMILY = 'admission_prediction_exploration'
SCHEMA = 'admission-prediction-exploration-combination-train-config-v4'
DESIGN = 'triple:M1+M4+M7'
AUTH = Path('C:/Users/Administrator/.grok/auth.json')
ACCOUNT = 'b13ba3f652654cf9907b60161d7cd397e5edd8da74646e642e4105768d511c2e'
IMAGE = 'research-benchmark-python@sha256:1433f0d223b0773b0d8c3184fa4ff6ab0a3891113442f1592d8d7e883d21a349'
sys.path.insert(0, str(TREE))
sys.path.insert(0, str(BASE / 'WORK'))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path | str) -> dict:
    return json.loads(Path(path).read_bytes())


def account(path: Path) -> None:
    rows = [value for value in read(path).values() if type(value) is dict and value.get('auth_mode') == 'oidc'
            and value.get('oidc_issuer') == 'https://auth.x.ai'
            and value.get('oidc_client_id') == 'b1a00492-073a-47ea-816f-4c329264a828']
    assert len(rows) == 1 and hashlib.sha256(rows[0]['user_id'].encode()).hexdigest() == ACCOUNT


def _pins(paths) -> dict[str, str]:
    result = {}
    for raw in paths:
        path = Path(raw).resolve()
        if not path.is_file(): raise RuntimeError('required frozen file is absent: ' + str(path))
        result[str(path)] = sha(path)
    return result


def _assert_pins(pins: dict) -> None:
    if not isinstance(pins, dict) or not pins or any(sha(Path(path)) != digest for path, digest in pins.items()):
        raise RuntimeError('frozen source, config, or input pin drift')


def two_item_material_map() -> dict:
    body = read(MAP); rows = body.get('selected_public_train_items')
    limits = body.get('limits', {})
    if (body.get('schema') != 'actual-m4m5-train-material-map-v1' or not isinstance(rows, list)
            or [row.get('token') for row in rows] != body.get('selected_token_allowlist')
            or {row.get('source') for row in rows} != {'blade', 'discoverybench'}
            or limits.get('train_only') is not True or limits.get('validation_access_enabled') is not False
            or limits.get('selected_task_count') != 2):
        raise RuntimeError('exact approved two-item public TRAIN map required')
    return {'map': {'path': str(MAP.resolve()), 'sha256': sha(MAP)},
            'tokens': [row['token'] for row in rows],
            'public_items': [{key: row[key] for key in ('source', 'token', 'task_sha256', 'identity_digest',
                'public_sha256', 'receipt_sha256', 'csv_sha256', 'csv_byte_count', 'task_handle')} for row in rows],
            'exporter': body['exporter_constructor'], 'reference_store': body['private_reference_store']}


def allocation() -> dict:
    return {'cells': 16, 'factorial_arms': 8, 'solver_main_opportunities': 48,
            'docker_attempts': 48, 'auxiliary_docker_attempts': 32,
            'solver_docker_attempts': 16, 'source_calls': 32,
            'evaluator_main_opportunities': 16, 'main_retry': False,
            'additional_paid_api_budget': 0, 'validation_opened': False}


def authoring_allocation() -> dict:
    """A finite pre-controller allocation, recorded separately from ``allocation``."""
    return {'public_train_tasks': 2, 'authoring_main_opportunities': 2,
            'possible_initial_title_opportunities': 2, 'main_retry': False,
            'included_in_controller_solver_opportunities': False,
            'timeout_seconds':240, 'additional_paid_api_budget': 0, 'validation_opened': False,
            'purpose': 'construct typed M1+M4+M7 public-TRAIN material only'}


def required_inputs() -> dict:
    """Exact external evidence needed before a future write/launch action."""
    return {
        'schema': 'actual-admission-prediction-exploration-grok130-required-inputs-v1',
        'runtime_tree': str(TREE), 'runtime_commit_prefix': RUNTIME_COMMIT,
        'source_gate': {
            'caller_supplied': True,
            'must_be_passed': True,
            'must_pin_commit_and_source_hashes': True,
            'must_cover': ['research_loop/modular/admission_prediction_exploration_controller.py',
                'research_loop/modular/train_provider_preflight.py',
                'research_loop/modular/grok_headless_train_solver.py',
                'evaluation/modular/headless_evaluator_model_port.py',
                'evaluation/modular/scorer_process.py'],
        },
        'root_label_gate': {'caller_supplied': True, 'must_be_passed': True,
            'must_pin_same_source': True, 'labels_are_runtime_inputs': False},
        'fresh_export': {
            'class': 'evaluation.modular.primary_prospective_exporter.PrimaryProspectiveTrainExporter',
            'must_create_new_exactly_two_item_receipt': True,
            'public_output_root': str(PREP / 'public-for-compile'),
            'audit_root': str(PREP / 'compile-export-audit'),
            'historical_four_item_export_is_input': False,
        },
        'material_authoring_bundle': {
            'caller_supplied': False, 'synthetic_fixture_permitted': False,
            'required_records': ['materials_by_pair', 'source_verifier_bindings', 'packages_by_arm'],
            'required_bindings': ['two fresh exported task digests', 'two fresh CSV sha256/byte counts',
                'same TRAIN identities in every package manifest', 'design triple:M1+M4+M7'],
            'authoring_scope': 'the author action creates this bounded TRAIN-only bundle; no VAL payload, score, or calibration input',
        },
        'native_roles': {
            'solver': 'FrozenHeadlessTrainDeployment + GrokHeadlessTrainModelPort',
            'evaluator': 'headless_evaluator_descriptor + evaluator_usage/provider digest equality',
            'scorer': 'one scoped admission-prediction-exploration scorer process with private reference handles',
        },
    }


def operator_contract() -> dict:
    materials = two_item_material_map()
    return {
        'schema': 'actual-admission-prediction-exploration-grok130-operator-contract-v1',
        'status': 'prepared_operator_requires_frozen_engineering_gates_before_execution',
        'family': FAMILY, 'controller_schema': SCHEMA, 'design': DESIGN,
        'controller': {'config_type': 'FrozenAdmissionPredictionExplorationTrainConfig',
            'compile': 'compile_admission_prediction_exploration_train_panels',
            'run': 'run_admission_prediction_exploration_train_panels',
            'scorer_schema': 'admission-prediction-exploration-scorer-process-config-v1'},
        'roots': {'preparation': str(PREP), 'run': str(RUN), 'private': str(PRIVATE)},
        'executable': {'path': str(EXECUTABLE.resolve()),
            'sha256': 'ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266',
            'version': '1.0.30', 'model': 'grok-4.6'},
        'material_map': materials, 'allocation': allocation(), 'authoring_allocation': authoring_allocation(), 'required_inputs': required_inputs(),
        'frozen_policy': {'included_only': True, 'api_key_route_permitted': False, 'paid_fallback': False,
            'main_retry': False, 'title_and_all_opportunity_settlement': 'unknown',
            'validation_opened': False, 'scientific_effectiveness_proven': False,
            'calibration_or_daybreak_prerequisite': False},
        'existing_synthetic_evidence_only': {
            'selector': 'tests/test_headless_admission_evaluator_stdio.py::test_native_v4_controller_runs_16_cells_and_closes_the_declared_evaluator',
            'limit': 'Synthetic peer/worker evidence does not show a healthy real runtime, actual scores, billing settlement, or VAL acceptance.'},
        'unresolved_execution_gates': [
            'No verified passed same-source runtime and ROOT label gate has been supplied to this operator.',
            'The provisional 1a9fab22 runtime is under test and is not represented as passed or healthy here.'],
    }


def _write(path: Path, body: dict) -> None:
    from research_loop.ontology import canonical
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as out:
        out.write(canonical(body) + '\n')


def _author_schema() -> dict:
    # The typed constructors below are the authority for detailed shape,
    # task/CSV identity binding, and public-label exclusion.
    identifier = {'type': 'string'}
    measurement = {'type':'object','properties': {'operation':{'type':'string','enum':['row_count','nonempty_count','decimal_sum']},
        'column':{'type':['string','null']}, 'expected':{'type':'string'}},
        'required':['operation','column','expected'],'additionalProperties':False}
    original = {'type':'object','properties': {'key':{'type':'string'}, 'measurement':measurement},
        'required':['key','measurement'],'additionalProperties':False}
    representation = {'type':'object','properties': {'key':{'type':'string'},'root':{'type':'string'},
        'representation':{'type':'string','enum':['report','summary']},'content_text':{'type':'string'}},
        'required':['key','root','representation','content_text'],'additionalProperties':False}
    claim = {'type':'object','properties': {'key':{'type':'string'}, 'statement':{'type':'string'},
        'subject_bindings':{'type':'object','properties':{},'required':[],'additionalProperties':False}, 'supports':{'type':'array','items':{'type':'string'}},
        'refutes':{'type':'array','items':{'type':'string'}}, 'depends_on':{'type':'array','items':{'type':'string'}}},
        'required':['key','statement','subject_bindings','supports','refutes','depends_on'],'additionalProperties':False}
    job = {'type':'object','properties': {'id':identifier,'purpose':{'type':'string','enum':['main','probe']},'program':{'type':'string'},
        'dependencies':{'type':'array','items':identifier},'resources':{'type':'array','items':identifier},'cost_units':{'type':'integer'}},
        'required':['id','purpose','program','dependencies','resources','cost_units'],'additionalProperties':False}
    return {'type': 'object', 'properties': {
        'question': {'type': 'string'}, 'ordinary_summary': {'type': 'string'},
        'originals': {'type': 'array', 'minItems':1, 'maxItems':32, 'items':original},
        'representations': {'type': 'array', 'maxItems':32, 'items': representation},
        'claims': {'type': 'array', 'minItems':1, 'maxItems':32, 'items':claim},
        'jobs': {'type': 'array', 'minItems':3, 'maxItems':3, 'items':job}},
        'required': ['question', 'ordinary_summary', 'originals', 'representations', 'claims',
                     'jobs'], 'additionalProperties': False}


def _author_request(packet, csv_bytes: bytes):
    """A port-compatible, public-only request; it has no session or evaluator input."""
    from research_loop.modular.contracts import FrozenRecord
    return FrozenRecord.from_dict({'schema': 'public-model-request-v1', 'task': packet.task.data(),
        'lock_digest': hashlib.sha256(b'admission-material-authoring-v1').hexdigest(),
        'objective': {'purpose': 'Create bounded public TRAIN material; unknown is allowed.'},
        'slot': 'author_material',
        'instruction': ('Using only this public TRAIN CSV and task, return typed source material. Every original must be a '
            'single executable measurement {operation,row_count|nonempty_count|decimal_sum; column; expected}; expected is a canonical decimal string. '
            'Do not include prose in originals, experiment labels, validation data, private references, host paths, or scores. '
            'Return exactly three ordered standalone Python jobs: a common main job, an alternative main job, then a probe job. '
            'Their purposes must be main, main, probe in that order; each costs exactly one unit. Use distinct 64-character '
            'lowercase hexadecimal job IDs. The first job has no dependencies; later jobs may depend only on the first ID. '
            'Resource lists may be empty, otherwise use unique 64-character lowercase hexadecimal IDs. '
            'Each program uses LF newlines only, is at most 6000 UTF-8 bytes, reads only /input/public_csv, and prints its '
            'measurement result. That public container path is permitted. Do not put module/arm labels or private-source '
            'names in programs. Claims and representations must refer only to keys in the returned originals/claims. Every claim subject_bindings value must be the empty object {}; the host binds the actual public TRAIN subject.'),
        'context': {'public_csv_utf8': csv_bytes.decode('utf-8'), 'csv_sha256': hashlib.sha256(csv_bytes).hexdigest()},
        'module_context': {'stage': 'pre_controller_material_authoring', 'domain': 'train'},
        'execution_feedback': []})


def _freeze_author_response(packet, response):
    """Bind untrusted author JSON to the exported task and construct real controller inputs."""
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.admission_combination import FrozenAdmissionMaterial
    from research_loop.modular.exploration_scheduler_combination import FrozenExplorationSchedulerMaterial
    from research_loop.modular.admission_prediction_exploration_driver import freeze_material
    body = response.data(); csv = packet.csv_path.read_bytes(); public = [{'artifact': {
        'artifact_id': 'public_csv', 'sha256': hashlib.sha256(csv).hexdigest(), 'byte_count': len(csv)},
        'container_path': '/input/public_csv'}]
    bindings = {'task': packet.task.identity.task_id, 'authoring': 'public_train'}
    originals = []
    for row in body['originals']:
        measurement = row['measurement']
        if ((measurement['operation'] == 'row_count') != (measurement['column'] is None)
                or not measurement['expected'].strip()): raise ValueError('original measurement shape is invalid')
        originals.append({'key':row['key'], 'root_material':{'authoring_measurement':row['key'], 'measurement':measurement},
            'content':{'measurement':measurement}, 'subject_bindings':bindings})
    representations = [{'key':row['key'],'root':row['root'],'representation':row['representation'],
        'content':{'text':row['content_text']}} for row in body['representations']]
    claims = [{**row, 'subject_bindings':bindings} for row in body['claims']]
    observations = {row['key']:{'authoring':'unqualified'} for row in originals}
    state = FrozenAdmissionMaterial(FrozenRecord.from_dict({'schema': 'admission-combination-material-v1',
        'identity': packet.task.identity.data(), 'task_digest': packet.task.content_hash,
        'public_artifacts': public, 'question': body['question'], 'context_budget_bytes': 24000,
        'ordinary_summary': body['ordinary_summary'], 'originals': originals,
        'representations': representations, 'claims': claims, 'withdrawals': [],
        'qualification_observations': {'before':observations, 'after':observations}}))
    jobs = FrozenExplorationSchedulerMaterial(FrozenRecord.from_dict({
        'schema': 'exploration-scheduler-material-v1', 'identity': packet.task.identity.data(),
        'task_digest': packet.task.content_hash, 'public_artifacts': public,
        'context_budget_bytes': 24000, 'jobs': body['jobs']}))
    return freeze_material(packet.task, state, jobs)


def _closed_prefix(check: Path) -> Path:
    if not check.name.endswith('-closed.json'):
        raise AssertionError('engineering check must be an immutable -closed.json receipt')
    return Path(str(check).removesuffix('-closed.json'))


def _junit_cases(report: Path) -> list:
    return list(ET.parse(report).getroot().iter('testcase'))


_LABEL_CASES = {
    'test_every_task_has_a_label', 'test_prompts_do_not_contain_label_payloads',
    'test_error_catching_every_task_has_a_label', 'test_error_catching_prompts_do_not_contain_label_payloads',
    'test_iteration_every_task_has_a_label', 'test_iteration_prompts_do_not_contain_label_payloads',
    'test_audit_contrast_every_task_has_a_label', 'test_audit_contrast_prompts_do_not_contain_label_payloads',
    'test_true_lock_every_task_has_a_label', 'test_true_lock_prompts_omit_gold_rule'}


def _verify_frozen_check(check: Path, commit: str, selectors: set[str] = frozenset()) -> dict:
    """The r4 evidence rule, with an explicit admission full-grid selector."""
    prefix = _closed_prefix(check)
    gate, before = read(check), read(str(prefix)+'-before.json')
    start, join, members = read(str(prefix)+'-native-start.json'), read(str(prefix)+'-native-join.json'), read(str(prefix)+'-source-members.json')
    report, archive = Path(str(prefix)+'.xml'), Path(str(prefix)+'-sources.zip')
    assert gate['commit'] == before['commit'] == join['source_commit'] == members['commit'] == commit
    assert gate['source_unchanged'] is True and before['source_before'] == gate['source_after']
    assert gate['exit_code'] == join['result']['exit_code'] == 0 and start['session_id'] == join['native_session_id']
    assert gate['junit']['tests'] > 0 and all(gate['junit'][x] == 0 for x in ('failures','errors','skipped'))
    assert sha(report) == gate['report_sha256'] and sha(archive) == members['archive_sha256']
    cases = _junit_cases(report)
    observed = {k: sum(int(x.get(k, 0)) for x in ET.parse(report).getroot().iter('testsuite')) for k in gate['junit']}
    assert observed == gate['junit'] and len(cases) == gate['junit']['tests']
    args = before.get('pytest_args'); assert isinstance(args, list)
    for selector in selectors:
        assert selector in args
        module, _, case_name = selector.partition('::')
        assert any(Path(module).stem in str(case.get('classname', '')) and (not case_name or case.get('name') == case_name) for case in cases)
    expected_members = {row['path']: row['sha256'] for row in members['members']}
    assert expected_members == gate['source_after']
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.namelist() == [row['path'] for row in members['members']]
        for row in members['members']:
            raw = zipped.read(row['path'])
            assert hashlib.sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes']
    return gate


def _normalized(raw: bytes) -> bytes:
    return raw.replace(b'\r\n', b'\n')


def _verified_gates(checks: list[Path], labels_check: Path, root_source: Path, commit: str) -> dict:
    """Reuse the r4 current-source rule and demand the admission 16-cell proof."""
    admission = 'tests/test_headless_admission_evaluator_stdio.py::test_native_v4_controller_runs_16_cells_and_closes_the_declared_evaluator'
    assert len(checks) == 2 and isinstance(commit, str) and len(commit) == 40
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE, text=True).strip() == commit
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=TREE, text=True).strip()
    assert not (TREE/'data/labels').exists()
    gates = [_verify_frozen_check(path, commit, {admission} if admission in read(str(_closed_prefix(path))+'-before.json').get('pytest_args', []) else set()) for path in checks]
    assert gates[0]['source_after'] == gates[1]['source_after']
    assert any(admission in read(str(_closed_prefix(path))+'-before.json').get('pytest_args', []) for path in checks)
    assert all(sha(TREE/name) == digest for name, digest in gates[0]['source_after'].items())
    labels = _verify_frozen_check(labels_check, read(labels_check)['commit'], {'tests/test_label_isolation.py'})
    label_cases = [case for case in _junit_cases(Path(str(_closed_prefix(labels_check))+'.xml'))
                   if case.get('classname', '').split('.')[-1] == 'test_label_isolation']
    assert len(label_cases) == len(_LABEL_CASES) and {case.get('name') for case in label_cases} == _LABEL_CASES
    assert (root_source/'.git').exists()
    runtime_names = {name for name in gates[0]['source_after'] if name.endswith('.py') and name.startswith(('research_loop/', 'evaluation/'))}
    root_names = {str(path.relative_to(root_source)).replace('\\', '/') for base in ('research_loop', 'evaluation') for path in (root_source/base).rglob('*.py')}
    assert runtime_names == root_names
    with zipfile.ZipFile(str(_closed_prefix(labels_check))+'-sources.zip') as zipped:
        for row in read(str(_closed_prefix(labels_check))+'-source-members.json')['members']:
            name = row['path']
            if name.endswith(('.py', '.md')):
                live = (root_source/name).read_bytes(); archived = zipped.read(name)
                assert _normalized(live) == _normalized(archived) if name.endswith('.md') else live == archived
    for name in runtime_names:
        assert _normalized((TREE/name).read_bytes()) == _normalized((root_source/name).read_bytes())
    return gates[0]


def _gate_pin_paths(checks: list[Path], labels_check: Path, gate: dict) -> list[Path]:
    paths = [MAP, EXECUTABLE, Path(__file__)]
    for name in gate['source_after']:
        paths.append(TREE/name)
    for check in [*checks, labels_check]:
        prefix = _closed_prefix(check)
        paths.extend([check, Path(str(prefix)+'-before.json'), Path(str(prefix)+'-native-start.json'),
            Path(str(prefix)+'-native-join.json'), Path(str(prefix)+'-source-members.json'),
            Path(str(prefix)+'.xml'), Path(str(prefix)+'-sources.zip')])
    return paths


def author(engineering_checks: list[Path], labels_check: Path, root_source: Path, runtime_commit: str) -> None:
    """Create the fresh two-packet export and one immutable material per task.

    This is the only authoring launch point.  It is intentionally separate from
    the controller worker and leaves a terminal port ledger on any uncertain
    native response.
    """
    from evaluation.modular.primary_prospective_exporter import PrimaryProspectiveTrainExporter
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.modules.improvement import CandidatePackage, TrainingManifest
    from research_loop.modular.admission_prediction_exploration_driver import registered_design
    from research_loop.modular.contracts import FrozenRecord
    assert not PREP.exists() and not RUN.exists() and not PRIVATE.exists()
    assert sha(EXECUTABLE) == 'ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266'
    account(AUTH)
    gate = _verified_gates(engineering_checks, labels_check, root_source, runtime_commit)
    mapping = read(MAP)['exporter_constructor']; request = read(WORK / 'primary-prospective-export-live-r1/frozen-request-r1.json')
    exporter = PrimaryProspectiveTrainExporter(read(request['config_path']), Path(mapping['sealed_root']),
        expected_split_digest=mapping['expected_split_digest'], expected_audit_digest=mapping['expected_audit_digest'],
        expected_split_sha256=mapping['expected_split_sha256'], expected_audit_sha256=mapping['expected_audit_sha256'],
        eligibility_path=Path(mapping['eligibility_path']), eligibility_sha256=mapping['eligibility_sha256'],
        output_root=PREP/'public-for-compile', audit_root=PREP/'compile-export-audit')
    PREP.mkdir(); PRIVATE.mkdir(parents=True)
    exported = exporter.export_controller_packets(two_item_material_map()['tokens'])
    assert len(exported) == 2
    for packet, expected in zip(exported, two_item_material_map()['public_items'], strict=True):
        assert packet.task.identity.domain == 'train' and packet.task.content_hash == expected['task_sha256']
        assert sha(packet.csv_path) == expected['csv_sha256'] and packet.csv_path.stat().st_size == expected['csv_byte_count']
    author_pins = _pins(_gate_pin_paths(engineering_checks, labels_check, gate) +
        [PREP/'public-for-compile'/row['token']/name for row in two_item_material_map()['public_items'] for name in ('public.json', 'data.csv')])
    deployment = FrozenHeadlessTrainDeployment.create(EXECUTABLE); deployment.verify_executable(EXECUTABLE)
    home, profile, cwd = PRIVATE/'author-home', PRIVATE/'author-profile', PRIVATE/'author-cwd'
    home.mkdir(); profile.mkdir(); cwd.mkdir(); shutil.copyfile(AUTH, home/'auth.json'); account(home/'auth.json')
    _assert_pins(author_pins)
    port = GrokHeadlessTrainModelPort(executable=EXECUTABLE, work_root=PRIVATE/'author-model', private_home=home,
        private_profile=profile, public_cwd=cwd, frozen_files=author_pins, max_calls=2,
        schemas={'author_material': _author_schema()}, slot_output_caps={'author_material': 12000},
        slot_input_byte_caps={'author_material': 262144}, observed_main_token_cap=131072,
        deployment=deployment, timeout_seconds=240)
    materials = {}
    for packet in exported:
        _assert_pins(author_pins)
        response = port(_author_request(packet, packet.csv_path.read_bytes()))
        _assert_pins(author_pins)
        material = _freeze_author_response(packet, response)
        materials[packet.task.content_hash] = material.record.data()
    package = CandidatePackage.create(parent_digest=None,
        manifest=TrainingManifest.freeze(p.task.identity for p in exported), search_cost=2,
        changes={'prompt': {'instructions': 'Use only the supplied public TRAIN question, observations, and printed execution output. Preserve uncertainty.'}})
    baseline = hashlib.sha256(('actual-admission-m1m4m7:' + '|'.join(two_item_material_map()['tokens'])).encode()).hexdigest()
    design = registered_design(DESIGN, baseline)
    arms = {row['arm_digest']: row['arm'] for row in design.data()['cells'] if row['status'] == 'executable'}
    assert len(arms) == 8
    _write(PREP/'controller-material-bindings.json', {
        'schema': 'actual-admission-public-controller-material-bindings-v1', 'design': DESIGN,
        'baseline_digest': baseline, 'design_digest': design.content_hash,
        'packages_by_arm': {arm_digest: package.record.data() for arm_digest in arms},
        'materials_by_pair': {DESIGN: materials},
        'package_digest': package.digest, 'arm_count': 8,
        'scope': 'same candidate package and exact two task materials bind every factorial arm; independent measurement binding is supplied only by the external typed verifier factory'})
    _assert_pins(author_pins)
    _write(PREP/'authoring-bundle.json', {'schema': 'actual-admission-public-material-bundle-v1',
        'engineering_gates': [{'path':str(p.resolve()),'sha256':sha(p)} for p in engineering_checks],
        'label_gate': {'path':str(labels_check.resolve()),'sha256':sha(labels_check)},
        'authoring_allocation': authoring_allocation(), 'deployment': deployment.record.data(),
        'authoring_ledger': {'path': str((PRIVATE/'author-model/ledger.json').resolve()), 'sha256': sha(PRIVATE/'author-model/ledger.json')},
        'frozen_inputs': author_pins,
        'task_bindings': {p.task.content_hash: {'identity': p.task.identity.data(), 'csv_sha256': sha(p.csv_path),
            'csv_byte_count': p.csv_path.stat().st_size} for p in exported},
        'materials_by_task': materials, 'package': package.record.data(),
        'controller_material_bindings': {'path': str((PREP/'controller-material-bindings.json').resolve()),
            'sha256': sha(PREP/'controller-material-bindings.json')}, 'validation_opened': False,
        'actual_model_calls': len(port.ledger['calls']), 'authoring_search_cost': package.record.data()['search_cost'],
        'known_authoring_main_tokens': port.ledger['known_main_tokens'], 'all_opportunity_usage':'unknown',
        'prepared_at': datetime.now(timezone.utc).isoformat()})
    print(json.dumps({'stage': 'authoring_closed', 'authoring_main_opportunities': 2,
        'authoring_reservations': len(port.ledger['calls']), 'controller_solver_opportunities': 48,
        'validation_opened': False}), flush=True)


def _load_factory(spec: str):
    module, sep, name = spec.partition(':')
    if not sep or not module or not name:
        raise ValueError('verifier factory must be module:function')
    factory = getattr(importlib.import_module(module), name)
    if not callable(factory): raise TypeError('verifier factory is not callable')
    return factory


def _packets() -> tuple:
    """Reconstruct only the fresh two-packet public export authored for this run."""
    from evaluation.modular.train_io import PublicTrainPacket
    from research_loop.modular.contracts import DataIdentity, FrozenRecord, PublicTask
    packets = []
    for row in two_item_material_map()['public_items']:
        root = PREP / 'public-for-compile' / row['token']
        public = read(root/'public.json')
        task = PublicTask(DataIdentity.parse(public['task']['identity']), FrozenRecord.from_dict(public['task']['payload']))
        task.identity.require_train()
        packet = PublicTrainPacket(task, root/'public.json', root/'data.csv', FrozenRecord.from_dict(public['receipt']))
        assert task.content_hash == row['task_sha256'] and sha(root/'public.json') == row['public_sha256']
        assert sha(packet.csv_path) == row['csv_sha256']
        packets.append(packet)
    assert len(packets) == 2
    return tuple(packets)


def _environment() -> dict[str, str]:
    env = {key: value for key, value in os.environ.items() if key.upper() in {
        'SYSTEMROOT', 'WINDIR', 'SYSTEMDRIVE', 'COMSPEC', 'PATHEXT', 'PATH',
        'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE', 'OS'}}
    env.update(PYTHONPATH=str(TREE), PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8', TEMP=str(WORK), TMP=str(WORK))
    return env


def _role_key(name: str) -> Path:
    path = PRIVATE / (name + '.key')
    if path.exists():
        raise RuntimeError('role key must be newly reserved')
    path.write_bytes(secrets.token_bytes(32))
    return path


def _checked_authoring_bundle() -> tuple[dict, dict]:
    bundle, material = read(PREP/'authoring-bundle.json'), read(PREP/'controller-material-bindings.json')
    assert bundle['schema'] == 'actual-admission-public-material-bundle-v1'
    assert bundle['controller_material_bindings']['sha256'] == sha(PREP/'controller-material-bindings.json')
    _assert_pins(bundle['frozen_inputs'])
    assert material['design'] == DESIGN and set(material['materials_by_pair']) == {DESIGN}
    assert set(material['materials_by_pair'][DESIGN]) == {row['task_sha256'] for row in two_item_material_map()['public_items']}
    assert set(bundle['task_bindings']) == set(material['materials_by_pair'][DESIGN])
    _packets()
    return bundle, material


def prepare_controller(*, verifier_factory: str, evaluator_descriptor: Path, schemas_source: Path) -> None:
    """Freeze the real controller config after authoring and independent checks.

    ``verifier_factory`` is supplied by the separate deterministic CSV checker
    implementation.  It must return ``{DESIGN: AdmissionMaterialVerifier}``;
    this operator records its *actual* binding and never derives one from an
    author response or an authority name.
    """
    from evaluation.modular.scorer_process import headless_evaluator_descriptor
    from evaluation.modular.scoring_service import ScorerConfig, FrozenBenchmarkRubricEndpoint
    from research_loop.modular.admission_prediction_exploration_controller import FrozenAdmissionPredictionExplorationTrainConfig
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.combination_train_controller import _ANALYSIS
    from research_loop.modular.admission_prediction_exploration_contrasts import component_policy
    from research_loop.modular.admission_prediction_exploration_driver import SLOTS
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider
    if not (PREP/'authoring-bundle.json').is_file() or (PREP/'controller.json').exists(): raise RuntimeError('closed authoring bundle and unused controller config required')
    bundle, material = _checked_authoring_bundle()
    source_body = read(schemas_source)
    schemas = source_body.get('schemas') or source_body.get('provider', {}).get('native_config', {}).get('schemas')
    if not isinstance(schemas, dict) or set(schemas) != set(SLOTS): raise RuntimeError('verified same-family proposal/analysis/final schema source required')
    csv_a, csv_b = _role_key('actual-admission-csv-authority-a-r4'), _role_key('actual-admission-csv-authority-b-r4')
    task_rows = two_item_material_map()['public_items']
    _write(PRIVATE/'csv-authority-manifest.json', {'schema':'actual-admission-csv-authority-manifest-r1', 'design':DESIGN,
        'authorities':[{'id':'actual-admission-csv-authority-a-r4','key_file':str(csv_a.resolve()),'key_sha256':sha(csv_a)},
            {'id':'actual-admission-csv-authority-b-r4','key_file':str(csv_b.resolve()),'key_sha256':sha(csv_b)}],
        'tokens_by_task':{row['task_sha256']:row['token'] for row in task_rows},
        'csv_sha256_by_task':{row['task_sha256']:row['csv_sha256'] for row in task_rows}})
    factory = _load_factory(verifier_factory); factory_module = importlib.import_module(factory.__module__)
    factory_path = Path(factory_module.__file__).resolve()
    verifiers = factory(PREP, PRIVATE)
    if set(verifiers) != {DESIGN}: raise RuntimeError('factory must provide the exact M1+M4+M7 verifier')
    binding = verifiers[DESIGN].binding().data()
    # This is intentionally exact: a shared CSV lineage is recorded by the
    # checker receipt, while its distinct checker provenance comes only from
    # the actual supplied verifier, never from this operator.
    # The private rubric has a separately frozen, production descriptor.  The
    # descriptor itself is an input, while these role directories and the copied
    # approved account are prepared before the scorer can ever construct its port.
    descriptor = read(evaluator_descriptor)
    descriptor_required = {'provider_kind', 'executable', 'work_root', 'private_home', 'private_profile', 'public_cwd',
        'frozen_files', 'evaluator_id', 'evaluator_version', 'model', 'effort', 'max_calls', 'max_tokens',
        'timeout_seconds', 'account_read_recovery', 'native_deployment'}
    evaluator_paths = {'work_root': PRIVATE/'evaluator-model', 'private_home': PRIVATE/'evaluator-home',
        'private_profile': PRIVATE/'evaluator-profile', 'public_cwd': PRIVATE/'evaluator-cwd'}
    if (set(descriptor) != descriptor_required or descriptor.get('provider_kind') != 'grok-headless-frozen-evaluator-v1'
            or descriptor.get('executable') != str(EXECUTABLE.resolve()) or descriptor.get('model') != 'grok-4.6'
            or descriptor.get('effort') != 'low' or descriptor.get('max_calls') != 16
            or descriptor.get('max_tokens') != 16 * 131072 or descriptor.get('timeout_seconds') != 240
            or descriptor.get('account_read_recovery') != {'schema':'headless-account-read-recovery-v1','max_attempts':2}
            or descriptor.get('native_deployment') != bundle['deployment']
            or any(descriptor.get(name) != str(path.resolve()) for name, path in evaluator_paths.items())):
        raise RuntimeError('exact 16-call private Grok headless evaluator descriptor required')
    _assert_pins(descriptor['frozen_files'])
    for name, path in evaluator_paths.items():
        if name != 'work_root': path.mkdir(exist_ok=True)
    account(AUTH); shutil.copyfile(AUTH, evaluator_paths['private_home']/'auth.json')
    account(evaluator_paths['private_home']/'auth.json')
    provider = headless_evaluator_descriptor(descriptor)
    evaluator_provider={'kind':'grok-headless-frozen-evaluator-v1','configuration_digest':provider['configuration_digest']}
    usage={'schema':'admission-prediction-exploration-headless-evaluator-usage-declaration-v1',
        'provider_kind':evaluator_provider['kind'],'usage_contract':'grok-headless-admission-prediction-exploration-usage-v1',
        'evaluator_config_digest':evaluator_provider['configuration_digest']}
    rubric=ScorerConfig.create(benchmark='core_pair',evaluator_id=descriptor['evaluator_id'],version=descriptor['evaluator_version'],rubric_digest=FrozenBenchmarkRubricEndpoint.rubric_digest())
    items=two_item_material_map()['tokens']; task_bindings={}
    for digest,row in bundle['task_bindings'].items():
        task_bindings[next(x['token'] for x in two_item_material_map()['public_items'] if x['task_sha256']==digest)]={
            'identity':row['identity'],'task_digest':digest,'csv_sha256':row['csv_sha256'],'csv_byte_count':row['csv_byte_count']}
    body={'schema':'admission-prediction-exploration-combination-train-config-v4','export_mode':'primary_prospective','domain':'train',
        'stage':'actual-admission-prediction-exploration-grok130-r4','item_ids':items,'task_bindings':task_bindings,
        'baseline_digest':material['baseline_digest'],'packages_by_arm':material['packages_by_arm'],'scorer':rubric.record.data(),
        'scorer_handle_bindings':{},'acceptance_criteria':{'contrast_analysis':_ANALYSIS,'factorial_components':component_policy().data()},
        'replicates':['r4'],'materials_by_pair':material['materials_by_pair'],'source_verifier_bindings':{DESIGN:binding},
        'objective':{'purpose':'Analyze only frozen public TRAIN material.'},'image':IMAGE,'timeout_seconds':60,
        'allocation':{'model_slots_per_cell':['proposal','analysis_program','final_answer'],'docker_attempts_per_cell':3,'auxiliary_docker_attempts_per_cell':2,'solver_docker_attempts_per_cell':1,'scorer_calls_per_cell':1,'scorer_call_limit':16,'scorer_token_accounting':'transport_not_provided','source_calls_per_cell':2,'phase_cost_units_per_cell':2,'phase_job_limit':2,'phase_policy':'fifo','context_budget_bytes':24000},
        'provider':{'kind':'grok-headless-public-train-v1','model':'grok-4.6','opportunity_contract':'public-train-main-and-initial-title-v1',
            'included_only':True,'api_key_route_permitted':False,'main_calls':48,'possible_initial_title_calls':48,
            'main_output_caps':{'proposal':4096,'analysis_program':8192,'final_answer':4096},'input_byte_cap_per_request':262144,
            'observed_main_token_cap':131072,'title_requested_output_cap':100,'wall_timeout_seconds':60,'max_retries':0,
            'title_usage_and_all_call_totals':'unknown','account_read_recovery':{'schema':'headless-account-read-recovery-v1','max_attempts':2}},
        'evaluator_usage':usage,'evaluator_provider':evaluator_provider}
    handles=two_item_material_map()['reference_store']['selected_task_handles']
    body['scorer_handle_bindings']={identity:hashlib.sha256(handle.encode()).hexdigest() for identity,handle in handles.items()}
    for name in ('solver-home', 'solver-profile', 'solver-cwd'):
        (PRIVATE/name).mkdir(exist_ok=True)
    account(AUTH); shutil.copyfile(AUTH, PRIVATE/'solver-home'/'auth.json'); account(PRIVATE/'solver-home'/'auth.json')
    solver_pins = {**bundle['frozen_inputs'], str(Path(__file__).resolve()): sha(Path(__file__)), str(EXECUTABLE.resolve()): sha(EXECUTABLE), str(schemas_source.resolve()): sha(schemas_source)}
    backend = GrokHeadlessTrainModelPort(executable=EXECUTABLE, work_root=PRIVATE/'solver-model', private_home=PRIVATE/'solver-home', private_profile=PRIVATE/'solver-profile', public_cwd=PRIVATE/'solver-cwd', frozen_files=solver_pins, max_calls=48, schemas=schemas, slot_output_caps={slot:8192 if slot == 'analysis_program' else 2048 for slot in schemas}, slot_input_byte_caps={slot:262144 for slot in schemas}, observed_main_token_cap=131072, deployment=FrozenHeadlessTrainDeployment(FrozenRecord.from_dict(bundle['deployment'])), timeout_seconds=240)
    provider_config = GrokHeadlessTrainProvider(backend).configuration().data()
    body['provider'] = provider_config
    config=FrozenAdmissionPredictionExplorationTrainConfig(FrozenRecord.from_dict(body))
    compiled = __import__('research_loop.modular.admission_prediction_exploration_controller', fromlist=['compile_admission_prediction_exploration_train_panels']).compile_admission_prediction_exploration_train_panels(config, _packets())
    assert len(compiled.panels) == 1 and compiled.panels[0].obligation_id == DESIGN and len(compiled.panels[0].cells) == 16
    executor, scorer = 'actual-admission-grok130-executor-r4', 'actual-admission-grok130-scorer-r4'
    executor_key, scorer_key = _role_key(executor), _role_key(scorer)
    audit_a, audit_b = _role_key('actual-admission-audit-a-r4'), _role_key('actual-admission-audit-b-r4')
    roles = {'executor': executor, 'scorer': scorer, 'executor_key': str(executor_key.resolve()), 'scorer_key': str(scorer_key.resolve()),
        'audit_keys': [str(audit_a.resolve()), str(audit_b.resolve())],
        'key_sha256': {str(path.resolve()): sha(path) for path in (executor_key, scorer_key, audit_a, audit_b)}}
    reference = two_item_material_map()['reference_store']
    server = {'schema': 'admission-prediction-exploration-scorer-process-config-v1',
        'panel': __import__('evaluation.modular.scorer_process', fromlist=['serialize_combination_panel']).serialize_combination_panel(compiled.panels[0], admission_prediction_exploration=True),
        'scorer_config': rubric.record.data(), 'scorer_config_digest': rubric.digest,
        'train_reference_store': {'root': reference['store_root'], 'manifest_sha256': reference['manifest_sha256'],
            'inventory_digest': reference['inventory_digest'], 'split_digest': reference['split_digest']},
        'task_handles': reference['selected_task_handles'],
        'execution_authority_key_files': {executor: str(executor_key.resolve())},
        'scorer_authority': {'id': scorer, 'key_file': str(scorer_key.resolve())}, 'evaluator': descriptor}
    _write(PRIVATE/'scorer-server.json', server)
    _write(PRIVATE/'solver-spec.json', {'schema': 'actual-admission-grok130-solver-spec-v1',
        'private_home': str((PRIVATE/'solver-home').resolve()), 'private_profile': str((PRIVATE/'solver-profile').resolve()),
        'public_cwd': str((PRIVATE/'solver-cwd').resolve()), 'frozen_files': solver_pins, 'provider_configuration': provider_config,
        'native_deployment': bundle['deployment'], 'timeout_seconds': 240})
    _write(PREP/'controller.json',body)
    frozen_inputs = _pins([PREP/'authoring-bundle.json', PREP/'controller-material-bindings.json', PREP/'controller.json',
        evaluator_descriptor, factory_path, schemas_source, TREE/'research_loop/modular/csv_measurement_authorities.py',
        TREE/'research_loop/modular/csv_reader_measurement_worker.py', TREE/'research_loop/modular/csv_dictreader_measurement_worker.py',
        PRIVATE/'scorer-server.json', PRIVATE/'solver-spec.json', PRIVATE/'csv-authority-manifest.json',
        PRIVATE/'csv-authority-receipts/authority-manifest.json', csv_a, csv_b,
        *[Path(path) for path in descriptor.get('frozen_files', {})], *[PREP/'public-for-compile'/row['token']/name
          for row in two_item_material_map()['public_items'] for name in ('public.json', 'data.csv')]])
    _write(PREP/'controller-preparation.json',{'schema':'actual-admission-controller-preparation-v1','config_sha256':sha(PREP/'controller.json'),
        'config_digest':config.record.content_hash,'authoring_bundle_sha256':sha(PREP/'authoring-bundle.json'),
        'verifier_factory':verifier_factory,'verifier_binding':binding,'evaluator_descriptor':{'path':str(evaluator_descriptor.resolve()),'sha256':sha(evaluator_descriptor)},
        'scorer_server': {'path': str((PRIVATE/'scorer-server.json').resolve()), 'sha256': sha(PRIVATE/'scorer-server.json')},
        'solver_spec': {'path': str((PRIVATE/'solver-spec.json').resolve()), 'sha256': sha(PRIVATE/'solver-spec.json')}, 'roles': roles,
        'frozen_inputs': frozen_inputs, 'factory_module': {'path': str(factory_path), 'sha256': sha(factory_path)},
        'source_authority_execution': {'authorities_per_cell':2, 'cells':16, 'maximum_callbacks':32,
            'child_processes_per_callback':1, 'maximum_specs_per_dataset':32, 'child_timeout_seconds':20,
            'cleanup_timeout_seconds':5, 'callback_timeout_seconds':25, 'aggregate_callback_timeout_seconds':800},
        'cells':16,'solver_main_opportunities':48,'source_calls':32,'evaluator_main_opportunities':16,'docker_attempts':48,
        'authoring_main_opportunities':2,'authoring_is_additional_to_solver':True,'validation_opened':False})
    print(json.dumps({'stage':'controller_prepared','cells':16,'solver_main_opportunities':48,'source_calls':32,'evaluator_main_opportunities':16,'validation_opened':False}),flush=True)


def worker() -> None:
    """Run one reserved native solver/scorer child; no retry crosses this boundary."""
    from evaluation.modular.linked_scoring import LinkedExecutionAuthority
    from evaluation.modular.primary_prospective_exporter import PrimaryProspectiveTrainExporter
    from evaluation.modular.scorer_process import CombinationScorerProcessClient
    from evaluation.modular.scoring_service import ScorerConfig
    from research_loop.modular.admission_prediction_exploration_controller import FrozenAdmissionPredictionExplorationTrainConfig, compile_admission_prediction_exploration_train_panels, run_admission_prediction_exploration_train_panels
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider
    from research_loop.modular.runtime import AuditVerifier
    prep, body = read(PREP/'controller-preparation.json'), read(PREP/'controller.json')
    _assert_pins(prep['frozen_inputs'])
    _checked_authoring_bundle()
    assert sha(PREP/'controller.json') == prep['config_sha256']
    assert sha(prep['solver_spec']['path']) == prep['solver_spec']['sha256'] and sha(prep['scorer_server']['path']) == prep['scorer_server']['sha256']
    config = FrozenAdmissionPredictionExplorationTrainConfig(FrozenRecord.from_dict(body))
    compiled = compile_admission_prediction_exploration_train_panels(config, _packets())
    assert len(compiled.panels) == 1 and compiled.panels[0].obligation_id == DESIGN and len(compiled.panels[0].cells) == 16
    spec, roles = read(prep['solver_spec']['path']), prep['roles']
    assert all(sha(Path(path)) == digest for path, digest in roles['key_sha256'].items())
    account(PRIVATE/'solver-home'/'auth.json')
    account(PRIVATE/'evaluator-home'/'auth.json')
    provider = body['provider']; schemas = provider['native_config']['schemas']
    backend = GrokHeadlessTrainModelPort(executable=EXECUTABLE, work_root=PRIVATE/'solver-model', private_home=Path(spec['private_home']),
        private_profile=Path(spec['private_profile']), public_cwd=Path(spec['public_cwd']), frozen_files=spec['frozen_files'],
        max_calls=48, schemas=schemas, slot_output_caps=provider['native_config']['slot_output_caps'],
        slot_input_byte_caps=provider['native_config']['slot_input_byte_caps'], observed_main_token_cap=provider['native_config']['observed_main_token_cap'],
        account_read_recovery=provider['native_config']['account_read_recovery'], deployment=FrozenHeadlessTrainDeployment(FrozenRecord.from_dict(spec['native_deployment'])), timeout_seconds=spec['timeout_seconds'])
    port = GrokHeadlessTrainProvider(backend)
    assert port.configuration().data() == spec['provider_configuration'] == body['provider']
    executor_key, scorer_key = Path(roles['executor_key']).read_bytes(), Path(roles['scorer_key']).read_bytes()
    service = CombinationScorerProcessClient(panel=compiled.panels[0], config=ScorerConfig(FrozenRecord.from_dict(body['scorer'])),
        admission_prediction_exploration=True, evaluator_provider=body['evaluator_provider'],
        command=[sys.executable, '-m', 'evaluation.modular.scorer_process', '--config', prep['scorer_server']['path'],
            '--config-sha256', prep['scorer_server']['sha256'], '--journal', str((PRIVATE/'scorer-worker.jsonl').resolve())],
        journal_path=RUN/'scorer-client.jsonl', environment=_environment(), response_timeout_seconds=360,
        task_handle_bindings=body['scorer_handle_bindings'], execution_authority_keys={roles['executor']: executor_key}, scorer_authority_keys={roles['scorer']: scorer_key})
    try:
        mapping, request = read(MAP)['exporter_constructor'], read(WORK/'primary-prospective-export-live-r1/frozen-request-r1.json')
        exporter = PrimaryProspectiveTrainExporter(read(request['config_path']), Path(mapping['sealed_root']),
            expected_split_digest=mapping['expected_split_digest'], expected_audit_digest=mapping['expected_audit_digest'],
            expected_split_sha256=mapping['expected_split_sha256'], expected_audit_sha256=mapping['expected_audit_sha256'],
            eligibility_path=Path(mapping['eligibility_path']), eligibility_sha256=mapping['eligibility_sha256'],
            output_root=RUN/'public-export', audit_root=RUN/'export-audit')
        verifiers = _load_factory(prep['verifier_factory'])(PREP, PRIVATE)
        assert set(verifiers) == {DESIGN} and verifiers[DESIGN].binding().data() == body['source_verifier_bindings'][DESIGN]
        result = run_admission_prediction_exploration_train_panels(config, custody=None, prospective_exporter=exporter,
            snapshot_root=Path(exporter.config['snapshot_root']), export_root=exporter.output_root, run_root=RUN/'controller', model=port,
            audit_verifier=AuditVerifier({'a': Path(roles['audit_keys'][0]).read_bytes(), 'b': Path(roles['audit_keys'][1]).read_bytes()}),
            source_verifiers=verifiers, scoring_services={DESIGN: service}, execution_authority=LinkedExecutionAuthority(roles['executor'], executor_key),
            scorer_authority_keys={roles['scorer']: scorer_key})
    finally:
        service.close()
    receipt = result.receipt.data(); evaluator = read(Path(read(prep['evaluator_descriptor']['path'])['work_root'])/'ledger.json')
    _write(RUN/'summary.json', {'schema':'actual-admission-prediction-exploration-summary-v1', 'controller_receipt': {'path': str((RUN/'controller/controller-receipt.json').resolve()), 'sha256': sha(RUN/'controller/controller-receipt.json')},
        'status': receipt['status'], 'cells': 16, 'scored_cells': receipt['scored_cells'], 'eligible_scored_cells': receipt['eligible_scored_cells'],
        'failed_cells': receipt['failed_cells'], 'blocked_cells': receipt['blocked_cells'], 'source_calls': receipt['source_calls'],
        'solver_reservations': len(backend.ledger['calls']), 'known_solver_main_tokens': backend.ledger['known_main_tokens'], 'solver_usage_incomplete': backend.ledger['usage_incomplete'],
        'evaluator_reservations': len(evaluator['calls']), 'known_evaluator_main_tokens': evaluator['known_main_tokens'], 'evaluator_usage_incomplete': evaluator['usage_incomplete'],
        'scorer_usage_unknown': receipt['scorer_usage_unknown'], 'title_and_all_opportunity_settlement':'unknown', 'settled_additional_charge_usd':None,
        'validation_opened':False, 'scientific_effectiveness_proven':False})
    print(json.dumps(read(RUN/'summary.json')), flush=True)


def run_parent() -> None:
    from research_loop.modular.grok_headless_transport import _child
    assert (PREP/'controller-preparation.json').is_file() and not RUN.exists()
    RUN.mkdir(); command = [sys.executable, str(Path(__file__)), 'worker']
    preparation = PREP/'controller-preparation.json'
    parent_timeout_seconds = 24000
    timeout_basis = {'solver': {'opportunities':48, 'seconds_each':240, 'total_seconds':11520},
        'evaluator': {'opportunities':16, 'seconds_each':240, 'total_seconds':3840},
        'docker': {'attempts':48, 'seconds_each':60, 'total_seconds':2880},
        'source_authority': {'maximum_callbacks':32, 'child_seconds_each':20, 'cleanup_seconds_each':5, 'seconds_each':25,
            'total_seconds':800, 'child_processes':32, 'maximum_specs_per_dataset':32},
        'reserved_orchestration_seconds':4960, 'total_seconds':parent_timeout_seconds}
    _write(RUN/'parent-reservation.json', {'schema':'actual-admission-parent-reservation-v2', 'command':command,
        'preparation':{'path':str(preparation.resolve()),'sha256':sha(preparation)}, 'cells':16,'solver_main_opportunities':48,
        'source_calls':32,'evaluator_main_opportunities':16,'docker_attempts':48,'authoring_main_opportunities':2,
        'additional_paid_api_budget':0,'main_retry':False,'validation_opened':False,'timeout_seconds':parent_timeout_seconds, 'timeout_basis':timeout_basis,
        'created_at':datetime.now(timezone.utc).isoformat()})
    prep = read(preparation)
    _assert_pins(prep['frozen_inputs'])
    frozen = {**prep['frozen_inputs'], str(preparation.resolve()): sha(preparation),
        **prep['roles']['key_sha256']}
    _, process = _child(command, {'cwd':str(TREE)}, _environment(), RUN/'parent-process', parent_timeout_seconds)
    unchanged = all(sha(Path(path)) == digest for path, digest in frozen.items())
    summary = read(RUN/'summary.json') if (RUN/'summary.json').is_file() else None
    attempt = read(RUN/'controller/controller-attempt.json') if (RUN/'controller/controller-attempt.json').is_file() else None
    cells = attempt.get('cells', []) if attempt else None
    failed_cells = None if cells is None else sum(row.get('status') == 'failed' for row in cells)
    blocked_cells = None if cells is None else sum(row.get('status') == 'blocked' for row in cells)
    complete = bool(summary and process['process_exit_code'] == 0 and not process['timed_out']
        and summary['status'] == 'complete_train_engineering' and not summary['solver_usage_incomplete']
        and not summary['evaluator_usage_incomplete'] and summary['solver_reservations'] == 48
        and summary['evaluator_reservations'] == 16 and summary['source_calls'] == 32)
    _write(RUN/'parent-closure.json', {'schema':'actual-admission-parent-closure-v2', 'process':process,
        'preparation':{'path':str(preparation.resolve()),'sha256':sha(preparation)}, 'frozen_inputs': frozen, 'source_and_inputs_unchanged':unchanged,
        'summary': {'path':str((RUN/'summary.json').resolve()), 'sha256':sha(RUN/'summary.json')} if summary else None,
        'expected_cells':16, 'observed_cells': None if cells is None else len(cells), 'observed_failed_cells': failed_cells, 'observed_blocked_cells': blocked_cells,
        'allocation_observation': None if summary is None else {'solver_reservations': summary['solver_reservations'], 'evaluator_reservations': summary['evaluator_reservations'], 'source_calls': summary['source_calls'], 'scored_cells': summary['scored_cells']},
        'experiment_complete': complete, 'unknown_or_incomplete': not complete,
        'validation_opened':False})
    print(json.dumps({'stage':'closed','exit_code':process['process_exit_code'],'timed_out':process['timed_out'],'summary_present':bool(summary),'source_and_inputs_unchanged':unchanged}), flush=True)
    raise SystemExit(int(not unchanged or not complete))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'author', 'prepare-controller','worker','run'))
    parser.add_argument('--engineering-check', type=Path, action='append')
    parser.add_argument('--labels-check', type=Path)
    parser.add_argument('--root-source', type=Path)
    parser.add_argument('--runtime-commit')
    parser.add_argument('--verifier-factory')
    parser.add_argument('--evaluator-descriptor', type=Path)
    parser.add_argument('--schemas-source', type=Path)
    args = parser.parse_args()
    if args.action == 'plan':
        print(json.dumps(operator_contract(), indent=2, sort_keys=True))
    elif args.action == 'author':
        if not (args.engineering_check and args.labels_check and args.root_source and args.runtime_commit):
            raise SystemExit('author requires two --engineering-check values, --labels-check, --root-source, and --runtime-commit')
        author(args.engineering_check, args.labels_check, args.root_source, args.runtime_commit)
    elif args.action == 'prepare-controller':
        if not (args.verifier_factory and args.evaluator_descriptor and args.schemas_source):
            raise SystemExit('prepare-controller requires --verifier-factory module:function, --evaluator-descriptor, and --schemas-source')
        prepare_controller(verifier_factory=args.verifier_factory, evaluator_descriptor=args.evaluator_descriptor, schemas_source=args.schemas_source)
    elif args.action == 'worker': worker()
    else: run_parent()


if __name__ == '__main__':
    main()
