import csv, json
from collections import defaultdict

groups = defaultdict(lambda: {'count': 0, 'sum': 0.0})
row_count = 0
with open('/input/public_csv', newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        row_count += 1
        x = row.get('x')
        if x is None or x.strip() == '':
            continue
        try:
            x_val = float(x)
        except ValueError:
            continue
        g = row.get('group', '')
        groups[g]['count'] += 1
        groups[g]['sum'] += x_val

result = {
    'row_count': row_count,
    'groups': {g: {'count': v['count'], 'mean': v['sum'] / v['count'] if v['count'] else None} for g, v in groups.items()}
}
print(json.dumps(result))