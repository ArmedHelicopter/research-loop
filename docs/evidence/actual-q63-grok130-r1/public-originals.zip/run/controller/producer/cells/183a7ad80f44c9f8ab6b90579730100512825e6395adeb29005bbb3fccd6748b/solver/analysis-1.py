import pandas as pd
import numpy as np
from pathlib import Path

path = Path('/input/public_csv')
df = pd.read_csv(path)
print('n_rows', len(df), 'n_cols', df.shape[1])

# urban filter
u = df.copy()
if u['urban_area'].dtype == object:
    u['urban'] = u['urban_area'].astype(str).str.lower().isin(['1','true','yes','y','urban'])
else:
    u['urban'] = u['urban_area'].astype(float) > 0
urb = u[u['urban']].copy()
print('n_urban', len(urb))

x = 'tech_workshops_frequency'
y = 'tech_patent_applications_per_1000'
g = 'government_investment'
for c in [x,y,g]:
    urb[c] = pd.to_numeric(urb[c], errors='coerce')
urb = urb.dropna(subset=[x,y,g])
print('n_urban_complete', len(urb))
print('describe_workshops', urb[x].describe().to_dict())
print('describe_patents', urb[y].describe().to_dict())
print('describe_govinv', urb[g].describe().to_dict())
print('corr_workshops_patents', float(urb[[x,y]].corr().iloc[0,1]))
print('corr_govinv_patents', float(urb[[g,y]].corr().iloc[0,1]))
print('corr_workshops_govinv', float(urb[[x,g]].corr().iloc[0,1]))

# investment terciles
urb['inv_tercile'] = pd.qcut(urb[g], 3, labels=['low','mid','high'], duplicates='drop')
for t, sub in urb.groupby('inv_tercile', observed=True):
    r = float(sub[[x,y]].corr().iloc[0,1]) if len(sub) > 2 else np.nan
    print(f'tercile_{t}_n', len(sub), 'mean_patents', float(sub[y].mean()), 'mean_workshops', float(sub[x].mean()), 'corr_xy', r)

# OLS y ~ x + g + x*g
X = np.column_stack([
    np.ones(len(urb)),
    urb[x].values,
    urb[g].values,
    urb[x].values * urb[g].values,
])
Y = urb[y].values
try:
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    print('ols_intercept', float(beta[0]))
    print('ols_workshops', float(beta[1]))
    print('ols_govinv', float(beta[2]))
    print('ols_interaction', float(beta[3]))
    pred = X @ beta
    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-Y.mean())**2))
    print('ols_r2', 1 - ss_res/ss_tot if ss_tot else np.nan)
except Exception as e:
    print('ols_failed', str(e))
