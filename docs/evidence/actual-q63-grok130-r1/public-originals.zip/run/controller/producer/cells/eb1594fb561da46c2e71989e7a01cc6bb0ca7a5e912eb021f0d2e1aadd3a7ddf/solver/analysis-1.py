#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv("/input/public_csv")
for c in ["num_amtl", "sockets", "age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["is_human"] = (df["genus"].astype(str).str.lower().isin(["homo", "human", "h. sapiens", "homo sapiens"])).astype(int)
if df["is_human"].sum() == 0:
    # genus likely already Homo / Homo sapiens labels
    g = df["genus"].astype(str)
    df["is_human"] = g.str.contains("homo", case=False).astype(int)

print("N rows", len(df), "specimens", df["specimen"].nunique())
print("genera", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())

# crude frequencies
agg = df.groupby(df["is_human"].map({1: "human", 0: "nonhuman"})).agg(
    specimens=("specimen", "nunique"), sockets=("sockets", "sum"), events=("num_amtl", "sum"), mean_age=("age", "mean")
)
agg["rate"] = agg["events"] / agg["sockets"]
print("CRUDE human vs nonhuman")
print(agg.to_string())

agg2 = df.groupby("genus").agg(
    specimens=("specimen", "nunique"), sockets=("sockets", "sum"), events=("num_amtl", "sum"), mean_age=("age", "mean")
)
agg2["rate"] = agg2["events"] / agg2["sockets"]
print("CRUDE by genus")
print(agg2.to_string())

endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
# model 1: is_human
m1 = smf.glm("num_amtl + I(sockets-num_amtl) ~ is_human + age + prob_male + C(tooth_class)", data=df, family=sm.families.Binomial()).fit()
print("MODEL is_human")
print(m1.summary())
print("human OR", float(np.exp(m1.params.get("is_human", np.nan))), "p", float(m1.pvalues.get("is_human", np.nan)))

m2 = smf.glm("num_amtl + I(sockets-num_amtl) ~ C(genus) + age + prob_male + C(tooth_class)", data=df, family=sm.families.Binomial()).fit()
print("MODEL C(genus)")
print(m2.summary())

# predicted probs at mean age/sex by tooth class, human vs not
mean_age = df["age"].mean()
mean_sex = df["prob_male"].mean()
grid = []
for tc in sorted(df["tooth_class"].astype(str).unique()):
    for h in [0, 1]:
        grid.append({"tooth_class": tc, "is_human": h, "age": mean_age, "prob_male": mean_sex, "sockets": 1, "num_amtl": 0})
grid = pd.DataFrame(grid)
pred = m1.predict(grid)
grid["pred_p"] = pred
print("PRED p at mean age/sex by tooth_class and is_human")
print(grid.to_string(index=False))
print("After covariates, is_human coefficient positive?", bool(m1.params.get("is_human", 0) > 0), "p<0.05?", bool(m1.pvalues.get("is_human", 1) < 0.05))
