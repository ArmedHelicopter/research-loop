import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.genmod.families import Binomial
from statsmodels.genmod.families.links import logit

path = "/input/public_csv"
df = pd.read_csv(path)
print("n_rows", len(df))
print("columns", list(df.columns))
print("genus_counts")
print(df["genus"].value_counts(dropna=False).to_string())
print("tooth_class_counts")
print(df["tooth_class"].value_counts(dropna=False).to_string())
print("missing_by_col")
print(df.isna().sum().to_string())

for c in ["num_amtl", "sockets", "age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df.loc[df["num_amtl"] > df["sockets"], "sockets"]
df["rate"] = df["num_amtl"] / df["sockets"]

print("n_after_clean", len(df))
print("crude_rate_by_genus")
agg = df.groupby("genus").agg(n=("specimen", "nunique"), rows=("specimen", "size"), amtl=("num_amtl", "sum"), sockets=("sockets", "sum"), mean_age=("age", "mean"))
agg["rate"] = agg["amtl"] / agg["sockets"]
print(agg.to_string())
print("crude_rate_by_tooth_class")
agg2 = df.groupby("tooth_class").agg(amtl=("num_amtl", "sum"), sockets=("sockets", "sum"))
agg2["rate"] = agg2["amtl"] / agg2["sockets"]
print(agg2.to_string())

df["is_homo"] = (df["genus"].astype(str).str.lower().str.contains("homo") | (df["genus"].astype(str) == "H.sapiens") | (df["genus"].astype(str).str.contains("sapiens"))).astype(int)
print("is_homo_rows", int(df["is_homo"].sum()), "other_rows", int((1-df["is_homo"]).sum()))
print("unique_genus", sorted(df["genus"].astype(str).unique().tolist()))

endog = np.column_stack([df["num_amtl"].to_numpy(), (df["sockets"] - df["num_amtl"]).to_numpy()])
X = pd.get_dummies(df[["genus", "tooth_class"]], drop_first=False)
# reference: first non-Homo genus alphabetically if present, else first genus
genera = sorted(df["genus"].astype(str).unique())
homo_like = [g for g in genera if "homo" in g.lower() or "sapien" in g.lower()]
ref_genus = [g for g in genera if g not in homo_like]
ref_g = ref_genus[0] if ref_genus else genera[0]
tooths = sorted(df["tooth_class"].astype(str).unique())
ref_t = tooths[0]
drop_cols = [c for c in X.columns if c == f"genus_{ref_g}" or c == f"tooth_class_{ref_t}"]
X = X.drop(columns=drop_cols, errors="ignore")
X["age"] = df["age"].to_numpy()
X["prob_male"] = df["prob_male"].to_numpy()
X = sm.add_constant(X.astype(float), has_constant="add")

model = sm.GLM(endog, X, family=Binomial(link=logit()))
res = model.fit(cov_type="HC1")
print("glm_reference_genus", ref_g, "reference_tooth", ref_t)
print(res.summary())
print("params")
print(res.params.to_string())
print("pvalues")
print(res.pvalues.to_string())

# predicted mean rate by genus at mean age/sex, averaged over observed tooth-class mix via counterfactual genus
mean_age = df["age"].mean()
mean_sex = df["prob_male"].mean()
print("held_age", float(mean_age), "held_prob_male", float(mean_sex))

def predict_for_genus(g):
    d = df.copy()
    d["genus"] = g
    Xg = pd.get_dummies(d[["genus", "tooth_class"]], drop_first=False)
    for col in [c for c in X.columns if c not in ("const", "age", "prob_male")]:
        if col not in Xg.columns:
            Xg[col] = 0.0
    Xg = Xg.reindex(columns=[c for c in X.columns if c not in ("const", "age", "prob_male")], fill_value=0.0)
    Xg["age"] = mean_age
    Xg["prob_male"] = mean_sex
    Xg = sm.add_constant(Xg.astype(float), has_constant="add")
    Xg = Xg.reindex(columns=X.columns, fill_value=0.0)
    p = res.predict(Xg)
    return float(np.mean(p))

print("adjusted_mean_pred_prob_by_genus_at_mean_age_sex_obs_tooth_mix")
for g in genera:
    print(g, predict_for_genus(g))

# Homo vs others contrast on log-odds if Homo dummy present
homo_cols = [c for c in res.params.index if c.startswith("genus_") and ("homo" in c.lower() or "sapien" in c.lower())]
print("homo_related_coefficients")
for c in homo_cols:
    print(c, float(res.params[c]), "se", float(res.bse[c]), "p", float(res.pvalues[c]))
