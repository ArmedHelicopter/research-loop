#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.formula.api import glm

path = "/input/public_csv"
df = pd.read_csv(path)
print("n_rows", len(df))
print("columns", list(df.columns))
print("genus_counts", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())
print("missing", df.isna().sum().to_dict())

df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = pd.to_numeric(df["num_amtl"], errors="coerce")
df["sockets"] = pd.to_numeric(df["sockets"], errors="coerce")
df["age"] = pd.to_numeric(df["age"], errors="coerce")
df["prob_male"] = pd.to_numeric(df["prob_male"], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male"])
df["is_human"] = (df["genus"].astype(str).str.lower().str.contains("homo|sapien")).astype(int)

crude = df.groupby("genus").apply(lambda g: pd.Series({
    "n": len(g),
    "amtl": g["num_amtl"].sum(),
    "sockets": g["sockets"].sum(),
    "rate": g["num_amtl"].sum() / g["sockets"].sum(),
    "mean_age": g["age"].mean(),
    "mean_pmale": g["prob_male"].mean(),
}))
print("crude_by_genus")
print(crude.to_string())

crude_tc = df.groupby(["genus", "tooth_class"]).apply(lambda g: g["num_amtl"].sum() / g["sockets"].sum())
print("crude_rate_genus_tooth")
print(crude_tc.to_string())

endog = np.column_stack([df["num_amtl"].clip(lower=0), (df["sockets"] - df["num_amtl"]).clip(lower=0)])
# use formula GLM binomial
mod = glm(
    "num_amtl + I(sockets - num_amtl) ~ C(genus) + age + prob_male + C(tooth_class)",
    data=df,
    family=sm.families.Binomial(),
).fit()
print("model_converged", bool(mod.converged))
print("model_llf", float(mod.llf))
print("model_aic", float(mod.aic))
print("params")
print(mod.params.to_string())
print("pvalues")
print(mod.pvalues.to_string())
print("conf_int")
print(mod.conf_int().to_string())

# Homo-coded contrast if Homo present
if df["is_human"].nunique() > 1:
    mod2 = glm(
        "num_amtl + I(sockets - num_amtl) ~ is_human + age + prob_male + C(tooth_class)",
        data=df,
        family=sm.families.Binomial(),
    ).fit()
    print("human_vs_nhp_params")
    print(mod2.params.to_string())
    print("human_vs_nhp_pvalues")
    print(mod2.pvalues.to_string())
    print("human_or", float(np.exp(mod2.params.get("is_human", np.nan))))

print("age_range", float(df["age"].min()), float(df["age"].max()))
print("note_observations_only")
