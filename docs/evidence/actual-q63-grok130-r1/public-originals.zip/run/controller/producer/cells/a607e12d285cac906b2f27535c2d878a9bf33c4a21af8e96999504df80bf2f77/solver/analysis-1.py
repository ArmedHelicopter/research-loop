#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

path = "/input/public_csv"
df = pd.read_csv(path)
print("n_rows", len(df))
print("columns", list(df.columns))
print("genus_counts")
print(df["genus"].value_counts().to_string())
print("tooth_class_counts")
print(df["tooth_class"].value_counts().to_string())
print("missing_per_col")
print(df.isna().sum().to_string())

work = df.copy()
work["num_amtl"] = pd.to_numeric(work["num_amtl"], errors="coerce")
work["sockets"] = pd.to_numeric(work["sockets"], errors="coerce")
work["age"] = pd.to_numeric(work["age"], errors="coerce")
work["prob_male"] = pd.to_numeric(work["prob_male"], errors="coerce")
work = work[(work["sockets"] > 0) & work["num_amtl"].notna() & work["age"].notna()]
work["num_amtl"] = work["num_amtl"].clip(lower=0)
work.loc[work["num_amtl"] > work["sockets"], "num_amtl"] = work.loc[work["num_amtl"] > work["sockets"], "sockets"]
work["rate"] = work["num_amtl"] / work["sockets"]
work["is_human"] = (work["genus"].astype(str).str.lower().str.contains("homo")).astype(int)

print("crude_rate_by_genus")
g = work.groupby("genus").agg(amtl=("num_amtl", "sum"), sockets=("sockets", "sum"), n=("specimen", "nunique"), mean_age=("age", "mean"))
g["rate"] = g["amtl"] / g["sockets"]
print(g.to_string())
print("crude_rate_by_genus_tooth")
gt = work.groupby(["genus", "tooth_class"]).agg(amtl=("num_amtl", "sum"), sockets=("sockets", "sum"))
gt["rate"] = gt["amtl"] / gt["sockets"]
print(gt.to_string())

# binomial GLM: genus vs Homo, plus age, sex, tooth_class
work["genus_f"] = pd.Categorical(work["genus"])
if "Homo" in work["genus_f"].cat.categories:
    work["genus_f"] = work["genus_f"].cat.reorder_categories(["Homo"] + [c for c in work["genus_f"].cat.categories if c != "Homo"])
work["tooth_f"] = pd.Categorical(work["tooth_class"])

endog = np.column_stack([work["num_amtl"], work["sockets"] - work["num_amtl"]])
formula = "num_amtl + I(sockets - num_amtl) ~ C(genus_f) + age + prob_male + C(tooth_f)"
mod = smf.glm(formula=formula, data=work, family=sm.families.Binomial()).fit(cov_type="HC0")
print("glm_binomial_summary")
print(mod.summary().as_text())
print("params")
print(mod.params.to_string())
print("pvalues")
print(mod.pvalues.to_string())
print("odds_ratios")
or_ = np.exp(mod.params)
ci = np.exp(mod.conf_int())
or_tab = pd.DataFrame({"or": or_, "ci_low": ci[0], "ci_high": ci[1], "p": mod.pvalues})
print(or_tab.to_string())

# clustered by specimen if possible
try:
    mod_cl = smf.glm(formula=formula, data=work, family=sm.families.Binomial()).fit(cov_type="cluster", cov_kwds={"groups": work["specimen"]})
    print("clustered_by_specimen_params")
    print(mod_cl.params.to_string())
    print("clustered_pvalues")
    print(mod_cl.pvalues.to_string())
    orc = pd.DataFrame({"or": np.exp(mod_cl.params), "p": mod_cl.pvalues})
    print("clustered_odds_ratios")
    print(orc.to_string())
except Exception as e:
    print("clustered_fit_failed", type(e).__name__, str(e)[:200])

# human vs pooled nonhuman
formula2 = "num_amtl + I(sockets - num_amtl) ~ is_human + age + prob_male + C(tooth_f)"
mod2 = smf.glm(formula=formula2, data=work, family=sm.families.Binomial()).fit(cov_type="HC0")
print("human_indicator_params")
print(mod2.params.to_string())
print("human_indicator_pvalues")
print(mod2.pvalues.to_string())
print("human_or", float(np.exp(mod2.params["is_human"])), "p", float(mod2.pvalues["is_human"]))
