#!/usr/bin/env python3
import pandas as pd
import numpy as np
from scipy import stats

path = "/input/public_csv"
df = pd.read_csv(path)

# normalize urban flag
ua = df["urban_area"]
if ua.dtype == object:
    urban = ua.astype(str).str.strip().str.lower().isin(["1", "true", "yes", "y", "urban"])
else:
    urban = ua.astype(float) == 1.0

sub = df.loc[urban, [
    "tech_workshops_frequency",
    "tech_patent_applications_per_1000",
    "government_investment",
]].dropna()

w = sub["tech_workshops_frequency"].astype(float)
p = sub["tech_patent_applications_per_1000"].astype(float)
g = sub["government_investment"].astype(float)

print(f"n_urban_complete={len(sub)}")
print(f"workshops_mean={w.mean():.4f} patents_mean={p.mean():.4f} govinv_mean={g.mean():.4f}")

pr, ppv = stats.pearsonr(w, p)
sr, spv = stats.spearmanr(w, p)
print(f"urban_pearson_workshops_patents r={pr:.4f} p={ppv:.4g}")
print(f"urban_spearman_workshops_patents r={sr:.4f} p={spv:.4g}")

prg, _ = stats.pearsonr(g, p)
prw, _ = stats.pearsonr(g, w)
print(f"urban_pearson_govinv_patents r={prg:.4f}")
print(f"urban_pearson_govinv_workshops r={prw:.4f}")

# terciles of government investment
try:
    terc = pd.qcut(g, 3, labels=["low", "mid", "high"], duplicates="drop")
except ValueError:
    terc = pd.Series(["all"] * len(sub))

print("within_govinv_tercile_associations:")
for lab in terc.unique():
    m = terc == lab
    n = int(m.sum())
    if n < 5:
        print(f"  tercile={lab} n={n} skipped")
        continue
    r, pv = stats.pearsonr(w[m], p[m])
    rs, pvs = stats.spearmanr(w[m], p[m])
    print(f"  tercile={lab} n={n} pearson_r={r:.4f} p={pv:.4g} spearman_r={rs:.4f} mean_patents={p[m].mean():.4f} mean_workshops={w[m].mean():.4f} mean_govinv={g[m].mean():.4f}")

# OLS: patents ~ workshops + govinv + interaction (centered)
wc = w - w.mean()
gc = g - g.mean()
X = np.column_stack([np.ones(len(sub)), wc, gc, wc * gc])
beta, *_ = np.linalg.lstsq(X, p.values, rcond=None)
yhat = X @ beta
resid = p.values - yhat
df_resid = max(len(sub) - X.shape[1], 1)
sigma2 = float(np.sum(resid**2) / df_resid)
try:
    cov = sigma2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
except np.linalg.LinAlgError:
    se = np.full(4, np.nan)
print("ols_patents ~ 1 + workshops_c + govinv_c + workshops_c:govinv_c")
names = ["intercept", "workshops_c", "govinv_c", "interaction"]
for name, b, s in zip(names, beta, se):
    t = b / s if s and np.isfinite(s) and s > 0 else np.nan
    print(f"  {name} coef={b:.6f} se={s:.6f} t={t:.3f}")

# residual correlation of workshops vs patents after linear govinv
Xg = np.column_stack([np.ones(len(sub)), gc])
bp, *_ = np.linalg.lstsq(Xg, p.values, rcond=None)
bw, *_ = np.linalg.lstsq(Xg, w.values, rcond=None)
pr_res, pv_res = stats.pearsonr(w.values - Xg @ bw, p.values - Xg @ bp)
print(f"partial_pearson_workshops_patents_ctrl_govinv r={pr_res:.4f} p={pv_res:.4g}")
