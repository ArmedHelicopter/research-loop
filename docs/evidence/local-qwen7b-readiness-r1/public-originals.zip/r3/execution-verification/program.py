import csv
import json

with open('/input/public_csv') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

groups = {}
row_count = 0
for row in rows:
    x = row['x']
    group = row['group']
    if x != '':
        row_count += 1
        try:
            x_value = float(x)
            if group not in groups:
                groups[group] = {'count': 0, 'mean': 0.0}
            groups[group]['count'] += 1
            groups[group]['mean'] += x_value
        except ValueError:
            pass
for group in groups.values():
    group['mean'] /= group['count'] if group['count'] > 0 else 1

output = {'row_count': row_count, 'groups': groups}
print(json.dumps(output))