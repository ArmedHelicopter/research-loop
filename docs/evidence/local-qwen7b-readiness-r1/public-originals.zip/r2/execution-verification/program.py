import csv
import json

csv_data = [
    {'x': '1', 'group': 'A'},
    {'x': '3', 'group': 'A'},
    {'x': '2', 'group': 'B'},
    {'x': '4', 'group': 'B'}
]

stats = {}
row_count = 0
for row in csv_data:
    group = row['group']
    if group not in stats:
        stats[group] = {
            'count': 0,
            'sum_x': 0,
            'mean_x': None
        }
    try:
        x = int(row['x'])
        stats[group]['count'] += 1
        stats[group]['sum_x'] += x
    except ValueError:
        pass
    row_count += 1

for group, data in stats.items():
    if data['count'] > 0:
        data['mean_x'] = round(data['sum_x'] / data['count'], 2)

overall_stats = {
    'row_count': row_count,
}

output = {'per_group': stats, **overall_stats}
print(json.dumps(output))