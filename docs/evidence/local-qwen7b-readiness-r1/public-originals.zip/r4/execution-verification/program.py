import csv
import json

with open('/input/public_csv', 'r') as file_handle:
    rows = list(csv.DictReader(file_handle))
    row_count = len(rows)
    groups = {}
    for row in rows:
        x = row['x']
        group = row['group']
        if x != '' and x is not None:
            try:
                x_value = float(x)
                if group not in groups:
                    groups[group] = {'count': 0, 'mean': 0.0}
                groups[group]['count'] += 1
                groups[group]['mean'] = (groups[group]['mean'] * (groups[group]['count'] - 1) + x_value) / groups[group]['count']
            except ValueError:
                continue
    expected_stdout = {
        'row_count': row_count,
        'groups': groups
    }
print(json.dumps(expected_stdout))