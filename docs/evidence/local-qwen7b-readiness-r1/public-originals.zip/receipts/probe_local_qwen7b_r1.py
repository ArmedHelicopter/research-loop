"""One CPU-only local readiness probe, recorded separately from all API series."""
import datetime,hashlib,json,time,urllib.request,urllib.error
from pathlib import Path
W=Path(__file__).resolve().parent; R=W/'local-qwen7b-selection-r1'
MODEL='research-loop-qwen25-7b-q4-r1'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with urllib.request.urlopen('http://127.0.0.1:11437/api/show',data=json.dumps({'model':MODEL}).encode(),timeout=10) as r:
    show=r.read();d=json.loads(show)
assert 'num_gpu' in d['parameters'] and 'num_thread' in d['parameters']
params={line.split()[0]:line.split()[1] for line in d['parameters'].splitlines() if len(line.split())==2}
assert params['num_gpu']=='0' and params['num_thread']=='4' and params['num_ctx']=='8192'
R.mkdir(exist_ok=False);(R/'model-show.json').write_bytes(show)
source=W/'icompify-selection-r2/deepseek-v4-pro/request.json'
req=read(source);req['model']=MODEL;req['max_tokens']=1024;req.pop('thinking',None)
raw=json.dumps(req,separators=(',',':')).encode();(R/'request.json').write_bytes(raw)
receipt={'series':'local/ollama/qwen2.5-7b-instruct-q4_K_M','model':MODEL,'request_sha256':sha(R/'request.json'),'source_prompt':{'path':str(source),'sha256':sha(source)},'output_cap':1024,'context_limit':8192,'cpu_threads':4,'gpu_layers':0,'calls':1,'additional_api_spend':0,'benchmark_effect_measured':False,'validation_opened':False,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retries':0}
(R/'reservation.json').write_text(json.dumps(receipt),encoding='utf8');started=time.monotonic()
try:
    request=urllib.request.Request('http://127.0.0.1:11437/v1/messages',data=raw,headers={'Content-Type':'application/json','anthropic-version':'2023-06-01'})
    with urllib.request.urlopen(request,timeout=600) as r:
        body=r.read(2*1024*1024+1);(R/'response.json').write_bytes(body);receipt['http_status']=r.status
    assert len(body)<=2*1024*1024
    response=json.loads(body); receipt['usage']=response.get('usage');receipt['stop_reason']=response.get('stop_reason')
    assert response['stop_reason']=='end_turn'
    answer=json.loads(''.join(x['text'] for x in response['content'] if x['type']=='text'))
    assert type(answer)==dict and set(answer)=={'program','expected_stdout'} and type(answer['program'])==str and type(answer['expected_stdout'])==dict
    (R/'answer.json').write_text(json.dumps(answer),encoding='utf8');receipt['accepted']=True
except Exception as e:
    receipt.update(accepted=False,error_type=type(e).__name__)
    if isinstance(e,urllib.error.HTTPError):
        receipt['http_status']=e.code;(R/'response.json').write_bytes(e.read(2*1024*1024+1))
finally:
    receipt['elapsed_seconds']=round(time.monotonic()-started,3)
    if (R/'response.json').exists():receipt['response_sha256']=sha(R/'response.json')
    (R/'receipt.json').write_text(json.dumps(receipt),encoding='utf8');print(json.dumps(receipt))
