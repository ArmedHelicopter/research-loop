"""Separate local structured-decoding probe; preserve the invalid JSON r1 original."""
import datetime,hashlib,json,time,urllib.request,urllib.error
from pathlib import Path
W=Path(__file__).resolve().parent;R=W/'local-qwen7b-selection-r4';R.mkdir(exist_ok=False)
model='research-loop-qwen25-7b-q4-r1'
source=W/'icompify-selection-r2/deepseek-v4-pro/request.json'
messages=json.loads(source.read_bytes())['messages']
messages[0]['content'] += " The program must open /input/public_csv and iterate csv.DictReader over that file. Never embed sample rows in program; the actual CSV can have different row counts, decimal x values and missing x. Set row_count = len(rows) immediately after rows = list(csv.DictReader(file_handle)); never increment or change row_count inside the nonmissing-x branch. A missing x still belongs to the total row count. Use float for nonmissing x and skip missing x only from its group count/mean. Stdout must have exact keys row_count and groups; each group has exact keys count and mean."
schema={'type':'object','properties':{'program':{'type':'string'},'expected_stdout':{'type':'object','properties':{'row_count':{'type':'integer'},'groups':{'type':'object','additionalProperties':{'type':'object','properties':{'count':{'type':'integer'},'mean':{'type':'number'}},'required':['count','mean'],'additionalProperties':False}}},'required':['row_count','groups'],'additionalProperties':False},'limitations':{'type':'string'}},'required':['program','expected_stdout','limitations'],'additionalProperties':False}
req={'model':model,'messages':messages,'format':schema,'stream':False,'options':{'num_gpu':0,'num_thread':4,'num_ctx':8192,'num_predict':1024,'temperature':0,'seed':20260916}}
raw=json.dumps(req,separators=(',',':')).encode();(R/'request.json').write_bytes(raw)
receipt={'series':'local/ollama/qwen2.5-7b-instruct-q4_K_M/structured-r4','calls':1,'additional_api_spend':0,'validation_opened':False,'scientific_effectiveness_proven':False,'source_prompt_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'request_sha256':hashlib.sha256(raw).hexdigest(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retries':0,'change':'TRAIN-only readiness feedback corrects total row counting before the missing-x filter. All three earlier attempts remain unchanged; this is not held-out acceptance.'}
(R/'reservation.json').write_text(json.dumps(receipt),encoding='utf8');start=time.monotonic()
try:
 request=urllib.request.Request('http://127.0.0.1:11437/api/chat',data=raw,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=600) as r:
  body=r.read(2*1024*1024+1);(R/'response.json').write_bytes(body);receipt['http_status']=r.status
 assert len(body)<=2*1024*1024
 d=json.loads(body);receipt['usage']={k:d.get(k) for k in ['prompt_eval_count','eval_count','load_duration','prompt_eval_duration','eval_duration','total_duration']};receipt['done_reason']=d.get('done_reason')
 assert d['done'] and d['done_reason']=='stop' and d['model']==model
 a=json.loads(d['message']['content']);assert type(a)==dict and set(a)==set(schema['required']) and type(a['program'])==str and type(a['expected_stdout'])==dict and type(a['limitations'])==str
 (R/'answer.json').write_text(json.dumps(a),encoding='utf8');receipt['accepted']=True
except Exception as e:
 receipt.update(accepted=False,error_type=type(e).__name__)
 if isinstance(e,urllib.error.HTTPError):receipt['http_status']=e.code;(R/'response.json').write_bytes(e.read(2*1024*1024+1))
finally:
 receipt['elapsed_seconds']=round(time.monotonic()-start,3)
 if (R/'response.json').exists():receipt['response_sha256']=hashlib.sha256((R/'response.json').read_bytes()).hexdigest()
 (R/'receipt.json').write_text(json.dumps(receipt),encoding='utf8');print(json.dumps(receipt))
