import pandas as pd
import numpy as np
from pathlib import Path

path = Path('/input/public_csv')
df = pd.read_csv(path)

def to_num(s):
    return pd.to_numeric(s, errors='coerce')

def to_bool(s):
    if s.dtype == bool:
        return s
    m = s.astype(str).str.strip().str.lower()
    return m.isin(['1','true','yes','y','t'])

df['workshops'] = to_num(df['tech_workshops_frequency'])
df['patents'] = to_num(df['tech_patent_applications_per_1000'])
df['gov'] = to_num(df['government_investment'])
df['stem'] = to_num(df['stem_graduate_percentage'])
df['infra'] = to_num(df['digital_infrastructure_index'])
df['urban'] = to_bool(df['urban_area'])

print('n_rows', len(df))
print('n_urban', int(df['urban'].sum()), 'n_nonurban', int((~df['urban']).sum()))

u = df[df['urban']].dropna(subset=['workshops','patents','gov'])
r = df[~df['urban']].dropna(subset=['workshops','patents','gov'])
print('urban_complete_n', len(u), 'nonurban_complete_n', len(r))
print('urban_corr_workshops_patents', float(u['workshops'].corr(u['patents'])))
print('urban_corr_gov_patents', float(u['gov'].corr(u['patents'])))
print('urban_corr_workshops_gov', float(u['workshops'].corr(u['gov'])))
print('nonurban_corr_workshops_patents', float(r['workshops'].corr(r['patents'])) if len(r)>5 else float('nan'))

def ols(y, X):
    X = np.column_stack([np.ones(len(X))] + [np.asarray(c, float) for c in X])
    y = np.asarray(y, float)
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ coef
    sse = float(resid @ resid)
    dof = max(len(y) - X.shape[1], 1)
    xtx_inv = np.linalg.pinv(X.T @ X)
    se = np.sqrt(np.maximum(np.diag(xtx_inv) * sse / dof, 0))
    t = coef / np.where(se==0, np.nan, se)
    return coef, se, t

c, se, t = ols(u['patents'], [u['workshops'], u['gov']])
print('urban_partial_workshops_coef', float(c[1]), 'se', float(se[1]), 't', float(t[1]))
print('urban_partial_gov_coef', float(c[2]), 'se', float(se[2]), 't', float(t[2]))

wxg = u['workshops'] * u['gov']
c2, se2, t2 = ols(u['patents'], [u['workshops'], u['gov'], wxg])
print('urban_interact_workshops', float(c2[1]), 'gov', float(c2[2]), 'wxg', float(c2[3]), 'wxg_t', float(t2[3]))

q = u['gov'].quantile([1/3, 2/3])
low, high = u[u['gov']<=q.iloc[0]], u[u['gov']>=q.iloc[1]]
for name, g in [('low_gov', low), ('high_gov', high)]:
    if len(g)>8:
        cg, seg, tg = ols(g['patents'], [g['workshops']])
        print(f'urban_{name}_workshops_slope', float(cg[1]), 't', float(tg[1]), 'n', len(g))

if len(r)>8:
    cr, ser, tr = ols(r['patents'], [r['workshops'], r['gov']])
    print('nonurban_partial_workshops_coef', float(cr[1]), 't', float(tr[1]))

uc = u.dropna(subset=['stem','infra'])
if len(uc)>10:
    cc, sec, tc = ols(uc['patents'], [uc['workshops'], uc['gov'], uc['stem'], uc['infra']])
    print('urban_ctrl_stem_infra_workshops_coef', float(cc[1]), 't', float(tc[1]))
    print('urban_ctrl_stem_coef', float(cc[3]), 'infra_coef', float(cc[4]))
