import pandas as pd
import numpy as np
from scipy import stats

df = pd.read_csv('/input/public_csv')
print('n_rows', len(df))
print('cols', list(df.columns))

# normalize urban flag
ua = df['urban_area']
if ua.dtype == object:
    urban = ua.astype(str).str.lower().isin(['true','1','yes','y'])
else:
    urban = ua.astype(bool)

u = df.loc[urban].copy()
print('n_urban', len(u))

x = u['tech_workshops_frequency'].astype(float)
y = u['tech_patent_applications_per_1000'].astype(float)
g = u['government_investment'].astype(float)
print('urban_overall_pearson_r', float(stats.pearsonr(x, y)[0]))
print('urban_overall_spearman', float(stats.spearmanr(x, y)[0]))
print('govinv_median', float(g.median()))
print('workshops_govinv_r', float(stats.pearsonr(x, g)[0]))
print('patents_govinv_r', float(stats.pearsonr(y, g)[0]))

high = g >= g.median()
print('n_urban_high_govinv', int(high.sum()), 'n_urban_low_govinv', int((~high).sum()))
r_high = float(stats.pearsonr(x[high], y[high])[0])
r_low = float(stats.pearsonr(x[~high], y[~high])[0])
print('urban_high_govinv_pearson_r', r_high)
print('urban_low_govinv_pearson_r', r_low)
print('delta_r_high_minus_low', r_high - r_low)
print('urban_high_govinv_slope', float(np.polyfit(x[high], y[high], 1)[0]))
print('urban_low_govinv_slope', float(np.polyfit(x[~high], y[~high], 1)[0]))

# residualize on government investment (linear)
def resid(a, b):
    b = np.asarray(b, float)
    a = np.asarray(a, float)
    coef = np.polyfit(b, a, 1)
    return a - np.polyval(coef, b)

rx = resid(x, g)
ry = resid(y, g)
print('urban_residual_pearson_r_after_govinv', float(stats.pearsonr(rx, ry)[0]))
print('urban_residual_spearman_after_govinv', float(stats.spearmanr(rx, ry)[0]))
