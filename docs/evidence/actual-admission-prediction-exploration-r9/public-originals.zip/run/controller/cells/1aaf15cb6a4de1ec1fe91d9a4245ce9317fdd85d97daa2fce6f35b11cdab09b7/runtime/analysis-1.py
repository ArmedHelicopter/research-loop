import pandas as pd
import numpy as np
from scipy import stats

df = pd.read_csv('/input/public_csv')

def to_bool(s):
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().isin(['true','1','yes','t'])

df['urban_area'] = to_bool(df['urban_area'])
urban = df[df['urban_area']].copy()
print('n_total', len(df), 'n_urban', len(urban))

w = urban['tech_workshops_frequency'].astype(float)
p = urban['tech_patent_applications_per_1000'].astype(float)
g = urban['government_investment'].astype(float)

print('urban_overall_pearson', stats.pearsonr(w, p))
print('urban_overall_spearman', stats.spearmanr(w, p))
print('urban_gov_patent_pearson', stats.pearsonr(g, p))
print('urban_gov_workshop_pearson', stats.pearsonr(g, w))

urban['gov_tertile'] = pd.qcut(g, 3, labels=['low','mid','high'], duplicates='drop')
for t, sub in urban.groupby('gov_tertile', observed=True):
    ww = sub['tech_workshops_frequency'].astype(float)
    pp = sub['tech_patent_applications_per_1000'].astype(float)
    gg = sub['government_investment'].astype(float)
    pr = stats.pearsonr(ww, pp)
    sr = stats.spearmanr(ww, pp)
    slope = np.polyfit(ww, pp, 1)[0] if len(sub) > 2 else np.nan
    gslope = np.polyfit(gg, pp, 1)[0] if len(sub) > 2 else np.nan
    print('tertile', t, 'n', len(sub), 'pearson', pr, 'spearman', sr, 'workshop_slope', slope, 'gov_slope', gslope)

# residualize on government_investment (urban)
X = np.column_stack([np.ones(len(g)), g.values])
bw = np.linalg.lstsq(X, w.values, rcond=None)[0]
bp = np.linalg.lstsq(X, p.values, rcond=None)[0]
rw = w.values - X @ bw
rp = p.values - X @ bp
print('urban_residual_pearson', stats.pearsonr(rw, rp))
print('urban_residual_spearman', stats.spearmanr(rw, rp))
