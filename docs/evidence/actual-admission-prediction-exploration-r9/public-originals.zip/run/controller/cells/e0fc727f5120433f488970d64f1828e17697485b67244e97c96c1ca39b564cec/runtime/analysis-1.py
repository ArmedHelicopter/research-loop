import pandas as pd
import numpy as np
from pathlib import Path

p = Path('/input/public_csv')
df = pd.read_csv(p if p.is_file() else '/input/data.csv')

def to_num(s):
    return pd.to_numeric(s, errors='coerce')

def is_true(s):
    x = s.astype(str).str.strip().str.lower()
    return x.isin(['1','true','yes','y','urban','t']) | (to_num(s) == 1)

w = to_num(df['tech_workshops_frequency'])
pat = to_num(df['tech_patent_applications_per_1000'])
gov = to_num(df['government_investment'])
urb = is_true(df['urban_area'])

print('n', len(df), 'urban_n', int(urb.sum()))
print('raw_corr_all', float(pd.concat([w,pat],axis=1).corr().iloc[0,1]))
print('raw_corr_urban', float(pd.concat([w[urb],pat[urb]],axis=1).corr().iloc[0,1]))
print('raw_corr_nonurban', float(pd.concat([w[~urb],pat[~urb]],axis=1).corr().iloc[0,1]))

u = pd.DataFrame({'w': w, 'pat': pat, 'gov': gov}).loc[urb].dropna()
print('urban_complete', len(u))

# OLS pat ~ w + gov (numpy)
X = np.column_stack([np.ones(len(u)), u['w'].values, u['gov'].values])
y = u['pat'].values
coef, *_ = np.linalg.lstsq(X, y, rcond=None)
resid = y - X @ coef
se = np.sqrt(np.diag(np.linalg.pinv(X.T @ X) * (resid @ resid) / max(len(u)-3,1)))
print('urban_ols_intercept_w_gov', [float(c) for c in coef])
print('urban_ols_se', [float(s) for s in se])
print('urban_partial_slope_w', float(coef[1]), 't_approx', float(coef[1]/se[1]) if se[1] else None)

# interaction w*gov
X2 = np.column_stack([np.ones(len(u)), u['w'].values, u['gov'].values, (u['w']*u['gov']).values])
coef2, *_ = np.linalg.lstsq(X2, y, rcond=None)
resid2 = y - X2 @ coef2
se2 = np.sqrt(np.diag(np.linalg.pinv(X2.T @ X2) * (resid2 @ resid2) / max(len(u)-4,1)))
print('urban_interact_coefs', [float(c) for c in coef2])
print('urban_interact_se', [float(s) for s in se2])
print('interaction_w_gov', float(coef2[3]), 't_approx', float(coef2[3]/se2[3]) if se2[3] else None)

med = float(u['gov'].median())
lo = u[u['gov'] <= med]
hi = u[u['gov'] > med]

def slope_w(d):
    X = np.column_stack([np.ones(len(d)), d['w'].values])
    y = d['pat'].values
    c, *_ = np.linalg.lstsq(X, y, rcond=None)
    return float(c[1]), len(d)

slo, nlo = slope_w(lo)
shi, nhi = slope_w(hi)
print('gov_median_urban', med, 'n_lo', nlo, 'n_hi', nhi)
print('slope_w_low_gov', slo, 'slope_w_high_gov', shi, 'diff_hi_minus_lo', shi-slo)

# residual correlation: residualize both on gov
Xg = np.column_stack([np.ones(len(u)), u['gov'].values])
r_pat = y - Xg @ np.linalg.lstsq(Xg, y, rcond=None)[0]
r_w = u['w'].values - Xg @ np.linalg.lstsq(Xg, u['w'].values, rcond=None)[0]
rc = float(np.corrcoef(r_w, r_pat)[0,1])
print('urban_residual_corr_w_pat_given_gov', rc)

# non-urban comparison
nou = pd.DataFrame({'w': w, 'pat': pat, 'gov': gov}).loc[~urb].dropna()
Xn = np.column_stack([np.ones(len(nou)), nou['w'].values, nou['gov'].values])
cn, *_ = np.linalg.lstsq(Xn, nou['pat'].values, rcond=None)
print('nonurban_partial_slope_w', float(cn[1]), 'n', len(nou))
