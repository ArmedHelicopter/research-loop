import csv
with open("/input/public_csv", encoding="utf-8-sig", newline="") as f:
    rows=list(csv.DictReader(f))
print(sum(bool((row['tech_openness_score'] or "").strip()) for row in rows))
