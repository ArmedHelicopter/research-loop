import pandas as pd
import numpy as np
import statsmodels.api as sm
from pathlib import Path

path = Path('/input/public_csv')
df = pd.read_csv(path)

def to_bool(s):
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().isin(['true', '1', 'yes', 't'])

df['urban'] = to_bool(df['urban_area'])
u = df.loc[df['urban']].copy()
y = u['tech_patent_applications_per_1000'].astype(float)
w = u['tech_workshops_frequency'].astype(float)
g = u['government_investment'].astype(float)
print('n_total', len(df))
print('n_urban', len(u))
print('raw_corr_workshops_patents_urban', float(np.corrcoef(w, y)[0, 1]))
print('corr_workshops_gov_urban', float(np.corrcoef(w, g)[0, 1]))
print('corr_patents_gov_urban', float(np.corrcoef(y, g)[0, 1]))

X1 = sm.add_constant(pd.DataFrame({'workshops': w, 'gov': g}))
m1 = sm.OLS(y, X1).fit()
print('H1_workshops_coef', float(m1.params['workshops']))
print('H1_workshops_ci_low', float(m1.conf_int().loc['workshops', 0]))
print('H1_workshops_ci_high', float(m1.conf_int().loc['workshops', 1]))
print('H1_workshops_pvalue', float(m1.pvalues['workshops']))
print('H1_gov_coef', float(m1.params['gov']))
print('H1_r2', float(m1.rsquared))

X2 = sm.add_constant(pd.DataFrame({'workshops': w, 'gov': g, 'wxg': w * g}))
m2 = sm.OLS(y, X2).fit()
print('H2_interaction_coef', float(m2.params['wxg']))
print('H2_interaction_ci_low', float(m2.conf_int().loc['wxg', 0]))
print('H2_interaction_ci_high', float(m2.conf_int().loc['wxg', 1]))
print('H2_interaction_pvalue', float(m2.pvalues['wxg']))
print('H2_workshops_main', float(m2.params['workshops']))
print('H2_r2', float(m2.rsquared))

Xg = sm.add_constant(g)
ry = sm.OLS(y, Xg).fit().resid
rw = sm.OLS(w, Xg).fit().resid
print('H3_residual_corr', float(np.corrcoef(rw, ry)[0, 1]))
print('H3_raw_minus_residual_corr', float(np.corrcoef(w, y)[0, 1] - np.corrcoef(rw, ry)[0, 1]))
