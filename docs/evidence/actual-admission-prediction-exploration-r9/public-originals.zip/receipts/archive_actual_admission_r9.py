"""Independently reconcile and preserve the full original failed TRAIN generation."""
import collections,hashlib,json,zipfile
from pathlib import Path
W=Path(__file__).resolve().parent; B=W.parent
R=W/'actual-admission-prediction-exploration-grok130-run-r9'; P=W/'actual-admission-prediction-exploration-grok130-preparation-r9'
C=B/'custody-private/actual-admission-prediction-exploration-grok130-r9'
O=B/'artifact-evidence-provenance/docs/evidence/actual-admission-prediction-exploration-r9'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(Path(p).resolve()),'sha256':sha(p)}
def write(p,v):
 with Path(p).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,sort_keys=True,separators=(',',':'))
a=read(R/'controller/controller-attempt.json');r=read(R/'controller/controller-receipt.json');s=read(R/'summary.json');p=read(R/'parent-closure.json')
j=read(W/'actual-admission-prediction-exploration-grok130-run-r9-native-join-original.json')
rows=a['cells']; statuses=collections.Counter(c['status'] for c in rows)
assert len(rows)==a['expected_cells']==r['expected_cells']==r['observed_cells']==16
assert statuses=={'succeeded':4,'failed':2,'blocked':10}
assert sum(c['scorer_calls'] for c in rows)==a['actual_scorer_calls']==r['actual_scorer_calls']==4
assert sum(c['docker_attempts'] for c in rows)==r['actual_docker_attempts']==17
assert r['eligible_scored_cells']==0 and r['status']==s['status']=='inconclusive'
assert p['source_and_inputs_unchanged'] and p['process']['process_exit_code']==0 and j['exit_code']==1
ledgers={}; originals=[]
for role in ['solver','evaluator']:
 f=C/(role+'-model')/'ledger.json'; d=read(f);calls=d['calls']
 ledgers[role]={'original':pin(f),'opportunities':len(calls),'statuses':dict(collections.Counter(x['status'] for x in calls)),
  'known_main_tokens':d['known_main_tokens'],'usage_incomplete':d['usage_incomplete']}
 assert d['known_main_tokens']==s['known_'+role+'_main_tokens']
 for c in calls:
  if c['status']!='succeeded':
   folder=Path(c['private_directory']);process=read(folder/'process.json')
   err=(folder/'stderr.private.txt').read_text(encoding='utf8')
   assert 'error decoding response body' in err
   originals.append({'slot':c['slot'],'status':c['status'],'error_type':c['error_type'],
    'original_stderr':pin(folder/'stderr.private.txt'),'original_stream':pin(folder/'stdout.private.jsonl'),
    'process':pin(folder/'process.json'),'process_exit_code':process['process_exit_code'],'timed_out':process['timed_out'],
    'failure_summary':'Grok CLI returned reqwest stream transport error decoding response body; completion and full usage unknown'})
assert ledgers['solver']['opportunities']==17 and ledgers['evaluator']['opportunities']==4
audit={'schema':'actual-admission-r9-independent-terminal-accounting-v1','originals':[pin(R/n) for n in ['controller/controller-attempt.json','controller/controller-receipt.json','summary.json','parent-closure.json']],
 'expected_cells':16,'scored_cells':4,'failed_cells':2,'blocked_cells':10,'eligible_scored_cells':0,'docker_attempts':17,'source_calls':r['source_calls'],
 'status':'inconclusive','ledgers':ledgers,'transport_failures':originals,'native_join':pin(W/'actual-admission-prediction-exploration-grok130-run-r9-native-join-original.json'),
 'full_denominator_retained':True,'singleton_negative_pruning':False,'scientific_effectiveness_proven':False,'validation_opened':False,'all_opportunity_tokens':None,'settled_additional_charge_usd':None}
if O.exists():raise ValueError('append-only archive required')
O.mkdir(parents=True);(O/'.gitattributes').write_bytes(b'* -text\n');write(O/'terminal-accounting.json',audit)
extras=[Path(__file__),W/'actual-admission-prediction-exploration-grok130-run-r9-native-start.json',W/'actual-admission-prediction-exploration-grok130-run-r9-native-join-original.json',W/'run_actual_admission_prediction_exploration_grok130_r9.py']
files=[(f,label+'/'+f.relative_to(root).as_posix()) for root,label in [(R,'run'),(P,'preparation')] for f in sorted(root.rglob('*')) if f.is_file()]
files += [(f,'receipts/'+f.name) for f in extras];members=[]
with zipfile.ZipFile(O/'public-originals.zip','x',zipfile.ZIP_DEFLATED) as z:
 for f,n in files:
  if f.is_symlink() or f.is_junction() or f.name.lower()=='auth.json' or f.suffix.lower()=='.key':raise ValueError('private credential or linked source forbidden')
  raw=f.read_bytes();z.writestr(n,raw);members.append({'path':n,'original':str(f),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(O/'public-originals.zip') as z:
 assert z.namelist()==[x['path'] for x in members]
 for x in members:assert z.read(x['path'])==Path(x['original']).read_bytes()
write(O/'manifest.json',{'schema':'actual-admission-r9-original-archive-v1','source_commit':'16a9b96bac035709ec03c4abfeeacccceef5c493','zip_sha256':sha(O/'public-originals.zip'),'members':members,'private_evidence_root':str(C),'keys_or_auth_published':False})
(O/'README.md').write_text('真实 TRAIN M1×M4×M7 全16单元：4评分、2失败、10阻断，完整面板为 inconclusive。\n\nGrok响应流解码错误使一个生成机会成为未知/失败，完整用量未知；原机会不重试。另一个失败保留在原始执行记录。17次求解MAIN已知112844 tokens，4次评分MAIN已知20011 tokens；执行17次Docker。源代码和输入未变。\n\n原始START/JOIN、输入、控制器与评分回执逐字节归档；私有原生流按哈希定位，认证和密钥不入库。失败和阻断保留原分母，不据此删组合，不证明科学有效。\n',encoding='utf8',newline='\n')
print(json.dumps({'archive':str(O),'members':len(members),'accounting_sha256':sha(O/'terminal-accounting.json'),'zip_sha256':sha(O/'public-originals.zip')}))
