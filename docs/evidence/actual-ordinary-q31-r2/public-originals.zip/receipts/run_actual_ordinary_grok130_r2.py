"""One frozen actual Q3.1 TRAIN generation, all variants/arms on both benchmarks.

The module framework remains 48Q. This generation only allocates the Q3.1
family. Independent scorer references never enter the producer's inputs.
No automatic retry, paid fallback, validation access or effect promotion.
"""
from __future__ import annotations
import argparse, ast, csv, hashlib, io, json, os, secrets, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

WORK=Path(__file__).resolve().parent; BASE=WORK.parent
TREE=BASE/'ordinary-headless-scoring-r2'; AUDIT_TREE=BASE/'ordinary-headless-label-audit-r2'
PREP=WORK/'actual-ordinary-q31-grok130-preparation-r2'
RUN=WORK/'actual-ordinary-q31-grok130-run-r2'
PRIVATE=BASE/'custody-private/actual-ordinary-q31-grok130-r2'
MAP=WORK/'actual-m4m5-train-material-map-r1.json'
EXECUTABLE=WORK/'grok-cli-1.0.30/grok.exe'
AUTH=Path('C:/Users/Administrator/.grok/auth.json')
ACCOUNT='b13ba3f652654cf9907b60161d7cd397e5edd8da74646e642e4105768d511c2e'
IMAGE='research-benchmark-python@sha256:1433f0d223b0773b0d8c3184fa4ff6ab0a3891113442f1592d8d7e883d21a349'
sys.path.insert(0,str(TREE))


def read(path): return json.loads(Path(path).read_bytes())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path): return {'path':str(Path(path).resolve()),'sha256':sha(path)}
def write(path,value):
    from research_loop.ontology import canonical
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as stream: stream.write(canonical(value))
def check_pins(pins):
    if not pins or any(sha(path)!=value for path,value in pins.items()): raise ValueError('frozen input drift')
def account(path):
    rows=[row for row in read(path).values() if type(row) is dict and row.get('auth_mode')=='oidc'
        and row.get('oidc_issuer')=='https://auth.x.ai' and row.get('oidc_client_id')=='b1a00492-073a-47ea-816f-4c329264a828']
    if len(rows)!=1 or hashlib.sha256(rows[0]['user_id'].encode()).hexdigest()!=ACCOUNT: raise ValueError('approved included account required')
def environment():
    allowed={'SYSTEMROOT','WINDIR','SYSTEMDRIVE','COMSPEC','PATHEXT','PATH','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE','OS'}
    result={key:value for key,value in os.environ.items() if key.upper() in allowed}
    return {**result,'PYTHONPATH':str(TREE),'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','TEMP':str(WORK),'TMP':str(WORK)}
def material_map():
    data=read(MAP); rows=data['selected_public_train_items']
    if len(rows)!=2 or {r['source'] for r in rows}!={'blade','discoverybench'} or not data['limits']['train_only'] or data['limits']['validation_access_enabled']:
        raise ValueError('exact two-item public TRAIN allowlist required')
    return data
def exporter(root,audit_root):
    from evaluation.modular.primary_prospective_exporter import PrimaryProspectiveTrainExporter
    mapping=material_map()['exporter_constructor']; request=read(WORK/'primary-prospective-export-live-r1/frozen-request-r1.json')
    return PrimaryProspectiveTrainExporter(read(request['config_path']),Path(mapping['sealed_root']),
        expected_split_digest=mapping['expected_split_digest'],expected_audit_digest=mapping['expected_audit_digest'],
        expected_split_sha256=mapping['expected_split_sha256'],expected_audit_sha256=mapping['expected_audit_sha256'],
        eligibility_path=Path(mapping['eligibility_path']),eligibility_sha256=mapping['eligibility_sha256'],
        output_root=root,audit_root=audit_root)
def packets():
    from research_loop.modular.contracts import DataIdentity,FrozenRecord,PublicTask
    from evaluation.modular.train_io import PublicTrainPacket
    output=[]
    for row in material_map()['selected_public_train_items']:
        root=PREP/'public'/row['token']; data=read(root/'public.json')
        task=PublicTask(DataIdentity.parse(data['task']['identity']),FrozenRecord.from_dict(data['task']['payload']))
        if task.content_hash!=row['task_sha256'] or sha(root/'data.csv')!=row['csv_sha256']: raise ValueError('public packet differs')
        output.append(PublicTrainPacket(task,root/'public.json',root/'data.csv',FrozenRecord.from_dict(data['receipt'])))
    return tuple(output)
def compile_config(body, exported):
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.modules.improvement import CandidatePackage
    from research_loop.modular.panel_plan import compile_train_panel
    R=FrozenRecord.from_dict
    return compile_train_panel(stage=body['stage'],scope_ids=tuple(body['scope_ids']),tasks=tuple(p.task for p in exported),
        evidence_by_task={k:R(v) for k,v in body['evidence_by_task'].items()},budget=R(body['budget']),
        baseline_digest=body['baseline_digest'],p0_control=R(body['p0_control']),
        packages_by_arm={k:CandidatePackage(R(v)) for k,v in body['packages_by_arm'].items()},
        scorer=R(body['scorer']),acceptance_criteria=R(body['acceptance_criteria']),replicates=tuple(body['replicates']))
def backend(spec):
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider
    c=spec['native_config']
    native=GrokHeadlessTrainModelPort(executable=c['executable'],work_root=PRIVATE/'solver-model',private_home=c['private_home'],
        private_profile=c['private_profile_root'],public_cwd=c['public_cwd_root'],frozen_files=c['frozen_files'],
        max_calls=c['max_calls'],schemas=c['schemas'],slot_output_caps=c['slot_output_caps'],
        slot_input_byte_caps=c['slot_input_byte_caps'],observed_main_token_cap=c['observed_main_token_cap'],
        account_read_recovery=c['account_read_recovery'],timeout_seconds=c['timeout_seconds'],
        deployment=FrozenHeadlessTrainDeployment(FrozenRecord.from_dict(c['native_deployment'])))
    provider=GrokHeadlessTrainProvider(native)
    if provider.configuration().data()!=spec: raise ValueError('solver provider configuration differs')
    return native,provider
def prepare(engineering,labels):
    from verify_frozen_operator_gate_r1 import verify
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.grok_headless_train_solver import GrokHeadlessTrainModelPort
    from research_loop.modular.grok_native_deployment import FrozenHeadlessTrainDeployment
    from research_loop.modular.train_provider import GrokHeadlessTrainProvider
    from research_loop.modular.train_controller import FrozenTrainControllerConfig
    from research_loop.modular.modules.improvement import CandidatePackage,TrainingManifest
    from research_loop.modular.panel_plan import obligation_grids,executable_arms
    from evaluation.modular.scoring_service import ScorerConfig,FrozenBenchmarkRubricEndpoint
    from evaluation.modular.scorer_process import serialize_frozen_panel,headless_evaluator_descriptor,parse_server_config
    if PREP.exists() or PRIVATE.exists() or RUN.exists(): raise ValueError('fresh generation required')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE,text=True).strip()
    source,gates=verify(engineering,tree=TREE,commit=commit,selectors=('tests/test_ordinary_headless_scoring.py','tests/test_headless_evaluator_closure.py','tests/test_headless_evaluator_factory.py'),
        required_cases=('test_all_twelve_cells_reach_native_solve_live_docker_private_score_and_signed_closure',))
    _,label_pins=verify(labels,tree=AUDIT_TREE,commit=commit,selectors=('tests/test_label_isolation.py',))
    if (TREE/'data/labels').exists() or (TREE/'results').exists(): raise ValueError('actor isolation differs')
    if sha(EXECUTABLE)!='ca24ea63272ba7881261f4a52498d1f5bd884b01da25845990422a10dd315266': raise ValueError('Grok executable differs')
    PREP.mkdir(); PRIVATE.mkdir(parents=True)
    exp=exporter(PREP/'public',PREP/'export-audit')
    exported=exp.export_controller_packets([r['token'] for r in material_map()['selected_public_train_items']])
    if len(exported)!=2: raise ValueError('both primary subjects required')
    # Reopen exact fresh public bytes, not reference payloads.
    exported=packets(); R=FrozenRecord.from_dict
    source_pins={str((TREE/name).resolve()):value for name,value in source['source_after'].items()}
    pins={**source_pins,**gates,**label_pins,**{str(p.resolve()):sha(p) for p in
        [Path(__file__),WORK/'verify_frozen_operator_gate_r1.py',MAP,EXECUTABLE,
         *[PREP/'public'/row['token']/name for row in material_map()['selected_public_train_items'] for name in ('public.json','data.csv')]]}}
    # Only JSON response schema literals are extracted; no synthetic model output or test task is used.
    schema_file=TREE/'tests/test_modular_train_controller.py'; schema_literals={}
    for node in ast.parse(schema_file.read_text(encoding='utf-8')).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in {'SCENARIO','FINAL'}:
            schema_literals[node.targets[0].id]=ast.literal_eval(node.value)
    if set(schema_literals)!={'SCENARIO','FINAL'}: raise ValueError('tested schema literals absent')
    schemas={'scenario':schema_literals['SCENARIO'],'final':schema_literals['FINAL'],'final_answer':schema_literals['FINAL'],
        'analysis_program':{'type':'object','properties':{'analysis':{'type':'string'},'program':{'type':'string'}},
            'required':['analysis','program'],'additionalProperties':False}}
    write(PREP/'response-schemas.json',{'schema':'ordinary-q31-response-schemas-v1','schemas':schemas,'source':pin(schema_file)})
    pins[str((PREP/'response-schemas.json').resolve())]=sha(PREP/'response-schemas.json')
    roles={}
    for name in ('executor','scorer','audit-a','audit-b'):
        path=PRIVATE/(name+'.key'); path.write_bytes(secrets.token_bytes(32)); roles[name]=pin(path)
    for role in ('s','e'):
        for suffix in ('home','profile','cwd'): (PRIVATE/(role+'-'+suffix)).mkdir()
    deployment=FrozenHeadlessTrainDeployment.create(EXECUTABLE)
    native=GrokHeadlessTrainModelPort(executable=EXECUTABLE,work_root=PRIVATE/'solver-model',private_home=PRIVATE/'s-home',
        private_profile=PRIVATE/'s-profile',public_cwd=PRIVATE/'s-cwd',frozen_files=pins,max_calls=48,schemas=schemas,
        slot_output_caps={slot:8192 if slot == 'analysis_program' else 2048 for slot in schemas},
        slot_input_byte_caps={slot:262144 for slot in schemas},observed_main_token_cap=131072,timeout_seconds=600,deployment=deployment,
        account_read_recovery={'schema':'headless-account-read-recovery-v1','max_attempts':2})
    provider=GrokHeadlessTrainProvider(native)
    baseline=hashlib.sha256(b'ordinary-q31-public-train-generation-r1').hexdigest()
    control=R({'always_enabled':True,'purpose':'Preserve frozen objectives, typed evidence and scientific status separation.'})
    grids=obligation_grids(('Q3.1',),baseline_digest=baseline,p0_control=control)
    package=CandidatePackage.create(parent_digest=None,manifest=TrainingManifest.freeze(p.task.identity for p in exported),search_cost=0,
        changes={'prompt':{'instructions':'Use the actual public TRAIN question and CSV. Preserve uncertainty. Verify column names, dimensions and category values before choosing a statistical model.'}})
    rubric=ScorerConfig.create(benchmark='core_pair',evaluator_id='actual-ordinary-q31-grok130-r2',version='v1',rubric_digest=FrozenBenchmarkRubricEndpoint.rubric_digest())
    evidence={}
    for packet in exported:
        reader=csv.DictReader(io.StringIO(packet.csv_path.read_text(encoding='utf-8-sig'))); rows=list(reader)
        evidence[packet.task.content_hash]={'observations':[{'kind':'public_csv_shape','rows':len(rows),'columns':reader.fieldnames,
            'csv_sha256':sha(packet.csv_path),'scientific_support':'unknown'}]}
    body={'schema':'train-panel-controller-v2','engineering_scope':'train_only_panel_engineering','stage':'actual-ordinary-q31-grok130-r2',
        'scope_ids':['Q3.1'],'item_ids':[r['token'] for r in material_map()['selected_public_train_items']],
        'evidence_by_task':evidence,'budget':{'model_calls':2,'execution_limit':0},'baseline_digest':baseline,'p0_control':control.data(),
        'packages_by_arm':{arm.content_hash:package.record.data() for grid in grids.values() for arm in executable_arms(grid).values()},
        'scorer':rubric.record.data(),'acceptance_criteria':{'scope':'train_only','optimization_uses':'train_only','validation_role':'acceptance_only'},
        'replicates':['r1'],'execution_mode':'linked_benchmark_solve','provider':provider.configuration().data()}
    frozen=FrozenTrainControllerConfig(R(body)); compiled=compile_config(body,exported)
    if len(compiled.panel.cells)!=12: raise ValueError('full Q3.1 grid must contain twelve cells')
    reference=material_map()['private_reference_store']; manifest=read(reference['manifest_path'])
    if sha(reference['manifest_path'])!=reference['manifest_sha256']: raise ValueError('private reference manifest differs')
    selected={row['identity_digest']:row['task_handle'] for row in manifest['rows'] if row['task_digest'] in {p.task.content_hash for p in exported}}
    if len(selected)!=2: raise ValueError('independent reference identity bindings missing')
    evaluator={'provider_kind':'grok-headless-frozen-evaluator-v1','executable':str(EXECUTABLE.resolve()),
        'work_root':str((PRIVATE/'evaluator-model').resolve()),'private_home':str((PRIVATE/'e-home').resolve()),
        'private_profile':str((PRIVATE/'e-profile').resolve()),'public_cwd':str((PRIVATE/'e-cwd').resolve()),'frozen_files':pins,
        'evaluator_id':'actual-ordinary-q31-grok130-r2','evaluator_version':'v1','model':'grok-4.6','effort':'low',
        'max_calls':12,'max_tokens':12*131072,'timeout_seconds':600,
        'account_read_recovery':{'schema':'headless-account-read-recovery-v1','max_attempts':2},'native_deployment':deployment.record.data()}
    descriptor=headless_evaluator_descriptor(evaluator)
    server={'schema':'linked-scorer-process-config-v1','panel':serialize_frozen_panel(compiled.panel),
        'scorer_config':rubric.record.data(),'scorer_config_digest':rubric.digest,
        'train_reference_store':{'root':str(Path(reference['manifest_path']).parent.resolve()),'manifest_sha256':reference['manifest_sha256'],
            'inventory_digest':manifest['inventory_digest'],'split_digest':manifest['split_digest']},
        'task_handles':selected,'execution_authority_key_files':{'ordinary-q31-executor-r2':roles['executor']['path']},
        'scorer_authority':{'id':'ordinary-q31-scorer-r2','key_file':roles['scorer']['path']},'evaluator':evaluator}
    parse_server_config(server)
    write(PREP/'controller.json',body); write(PREP/'scorer.json',server); write(PREP/'panel.json',serialize_frozen_panel(compiled.panel))
    write(PREP/'preparation.json',{'schema':'actual-ordinary-q31-preparation-v1','runtime_tree':str(TREE),'runtime_commit':commit,
        'controller':pin(PREP/'controller.json'),'scorer':pin(PREP/'scorer.json'),'panel':pin(PREP/'panel.json'),
        'frozen_inputs':pins,'roles':roles,'evaluator_provider':{'kind':'grok-headless-frozen-evaluator-v1','configuration_digest':descriptor['configuration_digest']},
        'task_handle_bindings':{key:hashlib.sha256(handle.encode()).hexdigest() for key,handle in selected.items()},
        'allocation':{'scope_ids':['Q3.1'],'cells':12,'producer_main':48,'evaluator_main':12,'docker':12,'replicates':1,
            'main_retry':False,'additional_paid_api_budget':0,'validation_opened':False},'created_at':datetime.now(timezone.utc).isoformat()})
    print(json.dumps({'stage':'prepared','cells':12,'producer_main':48,'evaluator_main':12,'actual_calls':0}))
def checked():
    preparation=read(PREP/'preparation.json'); check_pins(preparation['frozen_inputs'])
    for key in ('controller','scorer','panel'):
        if sha(preparation[key]['path'])!=preparation[key]['sha256']: raise ValueError('prepared binding differs')
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE,text=True).strip()!=preparation['runtime_commit'] or subprocess.check_output(['git','status','--porcelain'],cwd=TREE).strip():
        raise ValueError('runtime source drift')
    if (TREE/'data/labels').exists() or (TREE/'results').exists(): raise ValueError('actor isolation differs')
    for role in preparation['roles'].values():
        if sha(role['path'])!=role['sha256']: raise ValueError('authority key differs')
    return preparation,read(preparation['controller']['path'])
def evaluator_accounting():
    path=PRIVATE/'evaluator-model/ledger.json'
    if not path.exists():
        return {'ledger_available':False,'main_opportunities':None,'known_main_tokens':None,
            'usage_incomplete':None,'all_opportunity_tokens':None,'settled_additional_charge_usd':None}
    try:
        ledger=read(path)
        return {'ledger_available':True,'ledger':pin(path),'main_opportunities':len(ledger['calls']),
            'known_main_tokens':ledger['known_main_tokens'],'usage_incomplete':ledger['usage_incomplete'],
            'call_statuses':[row['status'] for row in ledger['calls']],
            'all_opportunity_tokens':None,'settled_additional_charge_usd':None}
    except Exception as exc:
        return {'ledger_available':True,'ledger':pin(path),'accounting_error':type(exc).__name__,
            'main_opportunities':None,'known_main_tokens':None,'usage_incomplete':True,
            'all_opportunity_tokens':None,'settled_additional_charge_usd':None}
def provision():
    checked(); account(AUTH)
    if RUN.exists(): raise ValueError('cannot provision a started generation')
    for role in ('s','e'):
        target=PRIVATE/(role+'-home')/'auth.json'
        if target.exists(): raise ValueError('role already provisioned')
        shutil.copyfile(AUTH,target); account(target)
    print(json.dumps({'stage':'provisioned','roles':2,'actual_calls':0}))
def worker():
    from evaluation.modular.linked_scoring import LinkedExecutionAuthority,issue_linked_score_input,verify_linked_adapted_receipt
    from evaluation.modular.scorer_process import LinkedScorerProcessClient,serialize_frozen_panel
    from evaluation.modular.scoring_service import ScorerConfig
    from research_loop.modular.contracts import FrozenRecord
    from research_loop.modular.train_controller import FrozenTrainControllerConfig,run_train_panel
    from research_loop.modular.runtime import AuditVerifier
    from research_loop.modular.benchmark_cell import verify_linked_benchmark_cell
    reservation=read(RUN/'parent-reservation.json')
    if reservation['preparation']!=pin(PREP/'preparation.json'): raise ValueError('original supervised reservation required')
    prep,body=checked(); write(RUN/'worker-start.json',{'preparation':pin(PREP/'preparation.json'),'pid':os.getpid()})
    R=FrozenRecord.from_dict; compiled=compile_config(body,packets())
    if serialize_frozen_panel(compiled.panel)!=read(PREP/'panel.json'): raise ValueError('frozen panel recomputation differs')
    for role in ('s','e'): account(PRIVATE/(role+'-home')/'auth.json')
    native,provider=backend(body['provider'])
    keys={name:Path(row['path']).read_bytes() for name,row in prep['roles'].items()}
    authority=LinkedExecutionAuthority('ordinary-q31-executor-r2',keys['executor']); rubric=ScorerConfig(R(body['scorer']))
    scorer=LinkedScorerProcessClient(panel=compiled.panel,config=rubric,
        command=[sys.executable,'-m','evaluation.modular.scorer_process','--config',prep['scorer']['path'],
            '--config-sha256',prep['scorer']['sha256'],'--journal',str(PRIVATE/'scorer-worker.jsonl')],
        journal_path=RUN/'scorer-client.jsonl',environment=environment(),response_timeout_seconds=720,
        task_handle_bindings=prep['task_handle_bindings'],execution_authority_keys={authority.authority_id:authority.key},
        scorer_authority_keys={'ordinary-q31-scorer-r2':keys['scorer']},evaluator_provider=prep['evaluator_provider'])
    scores=[]; statuses=[]; closure=None
    try:
        exp=exporter(RUN/'public-export',RUN/'export-audit')
        result=run_train_panel(FrozenTrainControllerConfig(R(body)),custody=None,prospective_exporter=exp,
            snapshot_root=Path(exp.config['snapshot_root']),export_root=exp.output_root,run_root=RUN/'controller',model=provider,
            audit_verifier=AuditVerifier({'a':keys['audit-a'],'b':keys['audit-b']}))
        if result.compiled.panel!=compiled.panel: raise ValueError('executed panel differs')
        by_key={row.cell.key:row for row in result.linked_results}
        for index,cell in enumerate(compiled.panel.cells):
            row=by_key.get(cell.key); status={'cell_key':list(cell.key),'status':'not_completed','score_eligible':False}
            if row is not None:
                status['status']=row.status
                if row.status=='linked_succeeded':
                    task=result.compiled.tasks[cell.task_digest]; scenario=result.compiled.scenarios[cell.key]
                    package=result.compiled.packages[cell.runtime_arm.content_hash]
                    try:
                        verify_linked_benchmark_cell(row,task=task,scenario=scenario,package=package)
                        linked=issue_linked_score_input(panel=compiled.panel,result=row,task=task,scenario=scenario,package=package,authority=authority)
                        write(RUN/'score-inputs'/f'{index:03d}.json',linked.data())
                        score=scorer.submit(cell_key=cell.key,linked_input=linked)
                        verified=verify_linked_adapted_receipt(score,authority_keys={'ordinary-q31-scorer-r2':keys['scorer']},
                            config=rubric,panel=compiled.panel,cell=cell,linked_input=linked,execution_authority_keys={authority.authority_id:authority.key})
                        scores.append(score); status.update(status='scored',score=score.receipt.data(),verification=verified.data())
                    except Exception as exc:
                        status.update(status='score_failed_or_unknown',error_type=type(exc).__name__,error=str(exc))
            statuses.append(status); write(RUN/'score-attempts'/f'{index:03d}.json',status)
        if scores:
            try:
                closure=scorer.finalize_headless_evaluator(receipts=scores)
                write(RUN/'scorer-closure.json',closure.data())
            except Exception as exc:
                write(RUN/'scorer-closure-failure.json',{'error_type':type(exc).__name__,'error':str(exc),'score_eligible':False})
        final_producer={'eligible':False}
        try:
            calls=provider.inspect()
            for row in result.linked_results:
                verify_linked_benchmark_cell(row,task=result.compiled.tasks[row.cell.task_digest],
                    scenario=result.compiled.scenarios[row.cell.key],package=result.compiled.packages[row.cell.runtime_arm.content_hash])
            checked()
            final_producer={'eligible':all(c.data()['originals_verified'] and c.data()['successful'] for c in calls),
                'native_ledger':pin(native.ledger_path),'provider_state':pin(provider.state_path),
                'original_call_views':[c.data() for c in calls],'readback_after_scoring':True}
        except Exception as exc:
            final_producer={'eligible':False,'error_type':type(exc).__name__,'error':str(exc),'readback_after_scoring':True}
        write(RUN/'producer-final-readback.json',final_producer)
        complete=(len(scores)==len(compiled.panel.cells) and closure is not None and final_producer['eligible']
            and result.receipt.data()['execution_status']=='engineering_complete')
        final_statuses=[{**row,'score_eligible':bool(complete and row['status']=='scored')} for row in statuses]
        write(RUN/'summary.json',{'schema':'actual-ordinary-q31-summary-v1','status':'scored_training_complete' if complete else 'inconclusive',
            'expected_cells':len(compiled.panel.cells),'scored_cells':len(scores),'eligible_scored_cells':len(scores) if complete else 0,
            'failed_or_unscored_cells':len(compiled.panel.cells)-len(scores),'cells':final_statuses,'provider_receipt':result.receipt.data(),
            'solver_reservations':len(native.ledger['calls']),'known_solver_main_tokens':native.ledger['known_main_tokens'],
            'solver_usage_incomplete':native.ledger['usage_incomplete'],'evaluator_finalization_present':closure is not None,
            'evaluator_accounting':evaluator_accounting(),'producer_final_readback':pin(RUN/'producer-final-readback.json'),
            'scientific_effectiveness_proven':False,'validation_opened':False,'settled_additional_charge_usd':None})
    finally:
        scorer.close()
        write(RUN/'evaluator-terminal-accounting.json',evaluator_accounting())
    print(json.dumps({'stage':'worker_closed','status':read(RUN/'summary.json')['status'],'scored_cells':len(scores)}))
def run():
    from research_loop.modular.grok_headless_transport import _child
    prep,_=checked()
    if RUN.exists(): raise ValueError('new generation required; no MAIN retry')
    RUN.mkdir(); write(RUN/'parent-reservation.json',{'schema':'actual-ordinary-q31-parent-v1','preparation':pin(PREP/'preparation.json'),
        'allocation':prep['allocation'],'timeout_seconds':40000,'timeout_basis':'60 native MAIN at 600s plus bounded Docker/stdio/verification overhead',
        'created_at':datetime.now(timezone.utc).isoformat()})
    _,process=_child([sys.executable,str(Path(__file__)),'worker'],{'cwd':str(TREE)},environment(),RUN/'parent-process',40000)
    unchanged=all(sha(path)==value for path,value in prep['frozen_inputs'].items())
    summary=read(RUN/'summary.json') if (RUN/'summary.json').exists() else None
    declared=read(PREP/'panel.json')['panel']['cells']
    attempts={}
    for path in sorted((RUN/'score-attempts').glob('*.json')):
        row=read(path); attempts[tuple(row['cell_key'])]={'observation':pin(path),'status':row['status']}
    compiled=compile_config(read(PREP/'controller.json'),packets())
    denominator=[{'cell_key':list(cell.key),**attempts.get(cell.key,{'status':'not_observed_by_scorer',
        'producer_state':'see_original_controller_attempt_and_native_ledger'})} for cell in compiled.panel.cells]
    if len(declared)!=12 or len(denominator)!=12: raise ValueError('parent denominator differs')
    write(RUN/'parent-closure.json',{'schema':'actual-ordinary-q31-parent-closure-v1','process':process,'source_and_inputs_unchanged':unchanged,
        'summary':pin(RUN/'summary.json') if summary else None,'planned_cells':12,'cell_denominator':denominator,
        'controller_attempt':pin(RUN/'controller/controller-attempt.json') if (RUN/'controller/controller-attempt.json').exists() else None,
        'evaluator_accounting':evaluator_accounting(),'validation_opened':False})
    good=(process['process_exit_code']==0 and not process['timed_out'] and process['failure'] is None
        and process['owned_tree_closed'] is True and unchanged and summary and summary['status']=='scored_training_complete')
    print(json.dumps({'stage':'closed','exit_code':process['process_exit_code'],'timed_out':process['timed_out'],'summary_present':summary is not None,'source_and_inputs_unchanged':unchanged}))
    raise SystemExit(0 if good else 1)
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('action',choices=('prepare','provision','worker','run'))
    parser.add_argument('--engineering',type=Path); parser.add_argument('--labels',type=Path); args=parser.parse_args()
    if args.action=='prepare':
        if not args.engineering or not args.labels: raise SystemExit('same-source passed engineering and label gates required')
        prepare(args.engineering,args.labels)
    else: globals()[args.action]()
