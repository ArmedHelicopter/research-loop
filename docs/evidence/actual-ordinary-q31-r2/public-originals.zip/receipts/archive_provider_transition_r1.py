"""Retain exact public originals, reject credentials, and verify archive bytes."""
import collections, hashlib, json, zipfile
from pathlib import Path

W=Path(__file__).resolve().parent; B=W.parent
DEST=B/'artifact-evidence-provenance/docs/evidence'
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p): return {'path':str(p), 'sha256':sha(p)}
def write(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f: json.dump(v,f,ensure_ascii=False,sort_keys=True,separators=(',',':'))
secret=read(B/'custody-private/icompify-provider-r1/auth.json')['token'].encode()
def archive(name, roots, extras, accounting, description):
    out=DEST/name
    if out.exists(): raise ValueError('append-only destination exists')
    files=[(f,label+'/'+f.relative_to(root).as_posix()) for label,root in roots for f in sorted(root.rglob('*')) if f.is_file()]
    files += [(f,'receipts/'+f.name) for f in extras]
    for f,_ in files:
        assert f.name.lower()!='auth.json' and f.suffix.lower()!='.key'
        assert not f.is_symlink() and not f.is_junction()
        assert secret not in f.read_bytes(), 'credential in proposed public archive'
    out.mkdir(parents=True); (out/'.gitattributes').write_bytes(b'* -text\n')
    write(out/'accounting.json',accounting)
    members=[]
    with zipfile.ZipFile(out/'public-originals.zip','x',zipfile.ZIP_DEFLATED) as z:
        for f,n in files:
            data=f.read_bytes();z.writestr(n,data)
            members.append({'member':n,'original':str(f),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    with zipfile.ZipFile(out/'public-originals.zip') as z:
        assert z.namelist()==[m['member'] for m in members]
        for m in members: assert z.read(m['member'])==Path(m['original']).read_bytes()
    write(out/'manifest.json',{'schema':'provider-transition-originals-v1','zip_sha256':sha(out/'public-originals.zip'),'members':members,'secrets_published':False})
    (out/'README.md').write_text(description,encoding='utf8',newline='\n')
    return {'archive':str(out),'members':len(members),'zip_sha256':sha(out/'public-originals.zip')}

R=W/'actual-ordinary-q31-grok130-run-r2'; P=W/'actual-ordinary-q31-grok130-preparation-r2'
C=B/'custody-private/actual-ordinary-q31-grok130-r2'
s=read(R/'summary.json'); a=read(R/'controller/controller-attempt.json'); r=read(R/'controller/controller-receipt.json'); p=read(R/'parent-closure.json')
jp=W/'actual-ordinary-q31-grok130-run-r2-native-join-original.json'; j=read(jp)
assert s['expected_cells']==a['expected_cells']==r['expected_cells']==len(s['cells'])==12
assert s['scored_cells']==s['eligible_scored_cells']==0 and s['status']=='inconclusive'
assert p['source_and_inputs_unchanged'] and p['process']['process_exit_code']==0 and j['exit_code']==1
ledgers={}
for role in ['solver','evaluator']:
    f=C/(role+'-model')/'ledger.json'; d=read(f)
    ledgers[role]={'original':pin(f),'opportunities':len(d['calls']),'statuses':dict(collections.Counter(c['status'] for c in d['calls'])),'known_main_tokens':d['known_main_tokens'],'usage_incomplete':d['usage_incomplete']}
assert ledgers['solver']['opportunities']==13 and ledgers['solver']['known_main_tokens']==81279
assert ledgers['evaluator']['opportunities']==1 and ledgers['evaluator']['known_main_tokens']==0
accounting={'schema':'actual-q31-r2-independent-accounting-v1','series':'grok-4.6','source_commit':'214231cfd3eee589829065951579096e0a28a69f','expected_cells':12,'scored_cells':0,'eligible_scored_cells':0,'cell_status_counts':dict(collections.Counter(c['status'] for c in s['cells'])),'ledgers':ledgers,'original_join':pin(jp),'status':'inconclusive','full_denominator_retained':True,'all_opportunity_tokens':None,'settled_additional_charge_usd':None,'scientific_effectiveness_proven':False,'validation_opened':False}
one=archive('actual-ordinary-q31-r2',[('run',R),('preparation',P)],[Path(__file__),W/'actual-ordinary-q31-grok130-run-r2-native-start.json',jp,W/'run_actual_ordinary_grok130_r2.py'],accounting,'真实 Grok TRAIN Q3.1：完整12单元，0评分、0可验收，结论 inconclusive。失败、未知和未完成机会全部保留；完整费用与用量未知。原始 START/JOIN、源码与输入绑定逐字节归档。此结果不支持删去任何模块或组合。\n')
S=W/'icompify-selection-r2'; selection=read(S/'selection.json')
assert selection['selected_model']=='deepseek-v4-pro' and selection['generation_calls_in_discovery_and_selection']==6
assert all(x['passed'] for x in selection['docker_cases'])
two=archive('icompify-provider-selection-r2',[('discovery',W/'icompify-model-discovery-r1'),('selection-r1',W/'icompify-selection-r1'),('selection-r2',S)],[],{'schema':'supplier-selection-archive-v1','selection':selection,'all_opportunity_tokens':None,'settled_additional_charge_usd':None,'full_benchmark_dispatched':False,'full_api_budget':'pending_user_boundary','series_separate_from_grok_and_local':True},'已从 /v1/models 获取真实可用列表，再对3个候选进行两轮共6次接口探针。deepseek-v4-pro 通过严格 JSON 和2个真实 Docker 输入案例；其余失败原件保留。这是工程选型证据，不是科学能力排名或 benchmark 效果。thinking disabled 仅为请求参数。完整实验额度仍待明确，未开启 VAL。\n')
print(json.dumps([one,two],ensure_ascii=False))
