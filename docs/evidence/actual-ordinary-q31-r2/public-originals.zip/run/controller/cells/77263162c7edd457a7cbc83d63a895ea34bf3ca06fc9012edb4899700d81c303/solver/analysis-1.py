#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

path = "/input/public_csv"
df = pd.read_csv(path)
print("n_rows", len(df))
print("columns", list(df.columns))
print("genus_counts", df["genus"].value_counts(dropna=False).to_dict())
print("tooth_class_counts", df["tooth_class"].value_counts(dropna=False).to_dict())

for c in ["num_amtl", "sockets", "age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df.loc[df["num_amtl"] > df["sockets"], "sockets"]

df["is_homo"] = df["genus"].astype(str).str.lower().str.contains("homo").astype(int)
df["crude_rate"] = df["num_amtl"] / df["sockets"]

print("n_used", len(df))
print("n_homo", int(df["is_homo"].sum()), "n_nonhuman", int((1 - df["is_homo"]).sum()))
print("crude_rate_homo", float(df.loc[df["is_homo"]==1, "num_amtl"].sum() / df.loc[df["is_homo"]==1, "sockets"].sum()))
print("crude_rate_nonhuman", float(df.loc[df["is_homo"]==0, "num_amtl"].sum() / df.loc[df["is_homo"]==0, "sockets"].sum()))
print("mean_age_homo", float(df.loc[df["is_homo"]==1, "age"].mean()))
print("mean_age_nonhuman", float(df.loc[df["is_homo"]==0, "age"].mean()))
print("mean_prob_male_homo", float(df.loc[df["is_homo"]==1, "prob_male"].mean()))
print("mean_prob_male_nonhuman", float(df.loc[df["is_homo"]==0, "prob_male"].mean()))

endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
model = smf.glm(
    formula="endog ~ is_homo + age + prob_male + C(tooth_class)",
    data=df.assign(endog=endog),
    family=sm.families.Binomial(),
).fit()
print(model.summary())
print("homo_coef", float(model.params.get("is_homo", np.nan)))
print("homo_se", float(model.bse.get("is_homo", np.nan)))
ci = model.conf_int().loc["is_homo"] if "is_homo" in model.params.index else (np.nan, np.nan)
print("homo_ci_low", float(ci[0]), "homo_ci_high", float(ci[1]))
print("homo_pvalue", float(model.pvalues.get("is_homo", np.nan)))
print("homo_or", float(np.exp(model.params.get("is_homo", np.nan))))
print("sign_homo", "positive" if model.params.get("is_homo", 0) > 0 else ("negative" if model.params.get("is_homo", 0) < 0 else "zero"))
