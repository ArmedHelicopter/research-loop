#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from pathlib import Path

path = Path("/input/public_csv")
df = pd.read_csv(path)
print("n_rows", len(df))
print("columns", list(df.columns))
print("genus_counts", df["genus"].value_counts().to_dict())
print("tooth_class_counts", df["tooth_class"].value_counts().to_dict())
print("missing", df.isna().sum().to_dict())

for c in ["num_amtl", "sockets", "age", "stdev_age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df.loc[df["num_amtl"] > df["sockets"], "sockets"]
df["prop"] = df["num_amtl"] / df["sockets"]
df["is_human"] = (df["genus"].astype(str).str.lower().isin(["homo", "homo sapiens", "hsapiens", "human"])).astype(int)
# normalize genus labels
gmap = {}
for g in df["genus"].unique():
    gl = str(g).lower()
    if "homo" in gl or "sapien" in gl or gl in {"human", "hs"}:
        gmap[g] = "Homo"
    elif "pan" in gl:
        gmap[g] = "Pan"
    elif "pongo" in gl:
        gmap[g] = "Pongo"
    elif "papio" in gl:
        gmap[g] = "Papio"
    else:
        gmap[g] = str(g)
df["genus_n"] = df["genus"].map(gmap)
print("genus_normalized", df["genus_n"].value_counts().to_dict())

agg = df.groupby("genus_n").agg(n=("specimen", "nunique"), rows=("specimen", "size"), amtl=("num_amtl", "sum"), sock=("sockets", "sum"), mean_age=("age", "mean"), mean_pmale=("prob_male", "mean"), mean_prop=("prop", "mean"))
agg["crude_rate"] = agg["amtl"] / agg["sock"]
print("crude_by_genus")
print(agg.to_string())

print("crude_by_genus_tooth")
print(df.groupby(["genus_n", "tooth_class"]).apply(lambda x: pd.Series({"amtl": x.num_amtl.sum(), "sock": x.sockets.sum(), "rate": x.num_amtl.sum()/x.sockets.sum()}), include_groups=False).to_string())

# binomial GLM: genus vs Homo as reference
df["genus_n"] = pd.Categorical(df["genus_n"], categories=[c for c in ["Homo", "Pan", "Pongo", "Papio"] if c in set(df["genus_n"])])
endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
formula = "prop ~ C(genus_n) + age + prob_male + C(tooth_class)"
mod = smf.glm(formula=formula, data=df, family=sm.families.Binomial(), freq_weights=df["sockets"]).fit(disp=False)
print("model_formula", formula)
print(mod.summary())
print("params")
print(mod.params.to_string())
print("pvalues")
print(mod.pvalues.to_string())
print("conf_int")
print(mod.conf_int().to_string())

# Homo vs others contrast via dummy is_human
formula2 = "prop ~ is_human + age + prob_male + C(tooth_class)"
mod2 = smf.glm(formula=formula2, data=df, family=sm.families.Binomial(), freq_weights=df["sockets"]).fit(disp=False)
print("human_vs_rest")
print(mod2.params.to_string())
print("human_vs_rest_p", mod2.pvalues.get("is_human"))
print("human_vs_rest_ci", mod2.conf_int().loc["is_human"].tolist() if "is_human" in mod2.conf_int().index else None)

# predicted probability at mean age/sex, each tooth class
age_m = df["age"].mean()
sex_m = df["prob_male"].mean()
rows = []
for g in df["genus_n"].cat.categories:
    for tc in sorted(df["tooth_class"].astype(str).unique()):
        pred = pd.DataFrame({"genus_n": [g], "age": [age_m], "prob_male": [sex_m], "tooth_class": [tc], "sockets": [1]})
        p = float(mod.predict(pred).iloc[0])
        rows.append((g, tc, p))
print("pred_at_mean_age_sex", {"age": age_m, "prob_male": sex_m})
for r in rows:
    print("pred", r[0], r[1], round(r[2], 6))

print("or_genus_vs_Homo")
for name, val in mod.params.items():
    if "genus_n" in name:
        print(name, "OR", float(np.exp(val)), "p", float(mod.pvalues[name]))
