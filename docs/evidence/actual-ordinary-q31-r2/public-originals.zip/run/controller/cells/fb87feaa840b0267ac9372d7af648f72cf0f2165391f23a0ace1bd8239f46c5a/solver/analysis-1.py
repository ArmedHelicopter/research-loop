#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv("/input/public_csv")
for c in ["num_amtl", "sockets", "age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df.loc[df["num_amtl"] > df["sockets"], "sockets"]
df["genus"] = df["genus"].astype(str).str.strip()
df["tooth_class"] = df["tooth_class"].astype(str).str.strip()

print("n_rows", len(df))
print("genera", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())

crude = df.groupby("genus").agg(amtl=("num_amtl", "sum"), sock=("sockets", "sum"), n=("specimen", "nunique"))
crude["rate"] = crude["amtl"] / crude["sock"]
print("crude_rates")
print(crude.sort_values("rate", ascending=False).to_string())

# Homo as reference if present
gens = sorted(df["genus"].unique())
ref = "Homo" if "Homo" in gens else gens[0]
df["genus"] = pd.Categorical(df["genus"], categories=[ref] + [g for g in gens if g != ref])

endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
mod = smf.glm(
    "num_amtl + I(sockets - num_amtl) ~ C(genus) + age + prob_male + C(tooth_class)",
    data=df,
    family=sm.families.Binomial(),
).fit()
print("converged", mod.converged)
print(mod.summary())
print("params")
print(mod.params.to_string())
print("pvalues")
print(mod.pvalues.to_string())
nh = [p for p in mod.params.index if p.startswith("C(genus)")]
print("nonhuman_genus_coefs_vs_ref", {k: float(mod.params[k]) for k in nh})
print("nonhuman_genus_p", {k: float(mod.pvalues[k]) for k in nh})
# negative NH coef => humans higher residual AMTL than that genus
