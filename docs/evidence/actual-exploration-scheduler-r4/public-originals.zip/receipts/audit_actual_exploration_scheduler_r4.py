"""Independent terminal accounting from frozen controller and original tool receipts."""
from pathlib import Path
import hashlib,json,collections
WORK=Path(__file__).parent; RUN=WORK/'actual-exploration-scheduler-grok130-run-r4'
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p): return {'path':str(Path(p).resolve()),'sha256':sha(p)}
receipt=read(RUN/'controller/controller-receipt.json'); attempt=read(RUN/'controller/controller-attempt.json')
summary=read(RUN/'summary.json'); parent=read(RUN/'parent-closure.json')
rows=attempt['cells']; statuses=collections.Counter(row['status'] for row in rows)
assert len(rows)==attempt['expected_cells']==receipt['expected_cells']==receipt['observed_cells']==8
assert statuses=={'succeeded':6,'failed':2}
assert sum(row['scorer_calls'] for row in rows)==receipt['actual_scorer_calls']==6
assert sum(row['docker_attempts'] for row in rows)==receipt['actual_docker_attempts']==24
gate=receipt['evaluator_final_verification']; closure=gate['closure']['body']
assert gate['score_eligible'] is False and gate['failure_reason']=='incomplete_panel_closure'
assert closure['scope']['unscored_cell_count']==2 and len(closure['calls'])==6
known_eval=sum(call['known_main_tokens'] for call in closure['calls'])
assert known_eval==gate['known_headless_main_tokens']
public_rows=[]
for row in rows:
    cell=row['cell']; public_rows.append({'cell':cell,'status':row['status'],'docker_attempts':row['docker_attempts'],
        'scorer_calls':row['scorer_calls'],'runtime_status':row.get('runtime',{}).get('status'),
        'historical_score_receipt_preserved':row.get('scorer_receipt') is not None})
out={'schema':'actual-exploration-scheduler-r4-independent-terminal-accounting-v1',
    'parents':[pin(RUN/'controller/controller-receipt.json'),pin(RUN/'controller/controller-attempt.json'),pin(RUN/'summary.json'),pin(RUN/'parent-closure.json')],
    'expected_cells':8,'observed_cells':8,'scored_cells':6,'failed_cells':2,'blocked_cells':0,'eligible_scored_cells':0,
    'status':'inconclusive','cells':public_rows,'solver_main_opportunities':16,'known_solver_main_tokens':114122,
    'evaluator_main_opportunities':6,'known_evaluator_main_tokens':known_eval,'docker_attempts':24,
    'summary_discrepancy':{'field':'cells','original_value':summary['cells'],'recomputed_value':8,
        'cause':'original helper reads a nonexistent receipt member; exact controller attempt and expected/observed fields contain all8',
        'original_edited':False},
    'failure_reason':'incomplete_panel_closure','singleton_negative_pruning':False,'scientific_effectiveness_proven':False,
    'validation_opened':False,'all_opportunity_tokens':None,'settled_additional_charge_usd':None,
    'audit_script':pin(__file__)}
target=WORK/'actual-exploration-scheduler-r4-independent-terminal-accounting-r1.json'
with target.open('x',encoding='utf-8',newline='\n') as stream: json.dump(out,stream,sort_keys=True,separators=(',',':'))
print(json.dumps({k:out[k] for k in ('status','expected_cells','scored_cells','failed_cells','eligible_scored_cells','known_solver_main_tokens','known_evaluator_main_tokens')}))
