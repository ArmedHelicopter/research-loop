#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv("/input/public_csv")
for c in ["num_amtl", "sockets", "age", "stdev_age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df["sockets"]
df["rate"] = df["num_amtl"] / df["sockets"]
df["is_human"] = (df["genus"].astype(str).str.lower().str.contains("homo")).astype(int)

print("n_rows", len(df), "n_specimens", df["specimen"].nunique())
print("genus_counts", df.groupby("genus").size().to_dict())
print("crude_rate_by_genus", df.groupby("genus").apply(lambda g: g["num_amtl"].sum()/g["sockets"].sum()).to_dict())
print("crude_rate_human_vs_nhp", df.groupby("is_human").apply(lambda g: g["num_amtl"].sum()/g["sockets"].sum()).to_dict())
print("mean_age_by_genus", df.groupby("genus")["age"].mean().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())

# binomial GLM: endog is successes/failures
endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
mod = smf.glm(
    "num_amtl + I(sockets - num_amtl) ~ C(genus, Treatment('Homo')) + age + prob_male + C(tooth_class)",
    data=df,
    family=sm.families.Binomial(),
)
# formula with two-column endog via GLM from arrays
X = pd.get_dummies(df[["genus", "tooth_class"]], drop_first=False)
# set Homo as reference for genus
genus_cols = [c for c in X.columns if c.startswith("genus_")]
tooth_cols = [c for c in X.columns if c.startswith("tooth_class_")]
ref_g = [c for c in genus_cols if "Homo" in c]
if ref_g:
    X = X.drop(columns=ref_g)
ref_t = tooth_cols[0] if tooth_cols else None
if ref_t:
    X = X.drop(columns=[ref_t])
X["age"] = df["age"].values
X["prob_male"] = df["prob_male"].values
X = X.astype(float)
X = sm.add_constant(X, has_constant="add")
fit = sm.GLM(endog, X, family=sm.families.Binomial()).fit(cov_type="HC1")
print("glm_converged", fit.converged)
print("glm_params")
print(fit.params.to_string())
print("glm_pvalues")
print(fit.pvalues.to_string())
print("glm_or")
print(np.exp(fit.params).to_string())

# cluster-robust by specimen if possible
try:
    fit_cl = sm.GLM(endog, X, family=sm.families.Binomial()).fit(
        cov_type="cluster", cov_kwds={"groups": df["specimen"]}
    )
    print("cluster_pvalues")
    print(fit_cl.pvalues.to_string())
except Exception as e:
    print("cluster_failed", type(e).__name__)

# predicted mean rate holding covariates at overall means, by genus
means = {"age": df["age"].mean(), "prob_male": df["prob_male"].mean()}
pred_rows = []
for g in sorted(df["genus"].unique()):
    for tc in sorted(df["tooth_class"].unique()):
        row = {c: 0.0 for c in X.columns if c != "const"}
        gcol = f"genus_{g}"
        tcol = f"tooth_class_{tc}"
        if gcol in row:
            row[gcol] = 1.0
        if tcol in row:
            row[tcol] = 1.0
        row["age"] = means["age"]
        row["prob_male"] = means["prob_male"]
        xr = pd.DataFrame([row])
        xr = sm.add_constant(xr, has_constant="add")
        xr = xr.reindex(columns=X.columns, fill_value=0.0)
        p = float(fit.predict(xr)[0])
        pred_rows.append((g, tc, p))
print("pred_rate_age_sex_mean_by_genus_tooth")
for r in pred_rows:
    print(r[0], r[1], round(r[2], 5))

# average predicted by genus
from collections import defaultdict
acc = defaultdict(list)
for g, tc, p in pred_rows:
    acc[g].append(p)
print("avg_pred_rate_by_genus", {k: float(np.mean(v)) for k, v in acc.items()})
nhp = [acc[k] for k in acc if "Homo" not in str(k)]
homo = acc.get("Homo", next((v for k,v in acc.items() if "Homo" in str(k)), []))
print("human_pred_avg", float(np.mean(homo)) if homo else None)
print("nhp_pred_avg", float(np.mean([np.mean(v) for v in nhp])) if nhp else None)
print("conclusion_note", "Positive human excess in crude rates should be interpreted via genus dummies vs Homo reference; negative genus coeffs mean non-humans have lower AMTL odds after age/sex/tooth class.")
