import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv("/input/public_csv")
df["num_amtl"] = pd.to_numeric(df["num_amtl"], errors="coerce")
df["sockets"] = pd.to_numeric(df["sockets"], errors="coerce")
df["age"] = pd.to_numeric(df["age"], errors="coerce")
df["prob_male"] = pd.to_numeric(df["prob_male"], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["is_homo"] = (df["genus"].astype(str).str.contains("Homo", case=False)).astype(int)
df["failures"] = df["sockets"] - df["num_amtl"]

print("N_rows", len(df))
print("genera", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())

crude = df.groupby("genus").agg(amtl=("num_amtl", "sum"), sockets=("sockets", "sum"))
crude["rate"] = crude["amtl"] / crude["sockets"]
print("crude_rate_by_genus")
print(crude.round(4).to_string())

endog = np.column_stack([df["num_amtl"], df["failures"]])
mod = smf.glm(
    "num_amtl + failures ~ C(is_homo) + age + prob_male + C(tooth_class)",
    data=df,
    family=sm.families.Binomial(),
).fit()
print("glm_summary")
print(mod.summary())
coef = mod.params.get("C(is_homo)[T.1]", mod.params.get("is_homo", np.nan))
pv = mod.pvalues.get("C(is_homo)[T.1]", mod.pvalues.get("is_homo", np.nan))
or_ = float(np.exp(coef)) if pd.notna(coef) else np.nan
print("homo_logodds", round(float(coef), 4), "OR", round(or_, 4), "p", round(float(pv), 6))
print("homo_higher_amtl_after_covariates", bool(coef > 0 and pv < 0.05))
