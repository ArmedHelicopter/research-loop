import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.api as sm

df = pd.read_csv('/input/public_csv')

# urban filter (handle bool/string encodings)
u = df['urban_area']
if u.dtype == object:
    urban = u.astype(str).str.strip().str.lower().isin(['1','true','yes','y','urban'])
else:
    urban = u.astype(float) == 1.0
sub = df.loc[urban, ['tech_workshops_frequency','tech_patent_applications_per_1000','government_investment']].dropna()
print('urban_n', int(len(sub)), 'total_n', int(len(df)))

x = sub['tech_workshops_frequency']
y = sub['tech_patent_applications_per_1000']
g = sub['government_investment']
r, p = stats.pearsonr(x, y)
rs, ps = stats.spearmanr(x, y)
print('pearson_workshops_patents_urban', round(float(r),4), 'p', round(float(p),6))
print('spearman_workshops_patents_urban', round(float(rs),4), 'p', round(float(ps),6))
print('pearson_gov_patents', round(float(stats.pearsonr(g,y)[0]),4))
print('pearson_gov_workshops', round(float(stats.pearsonr(g,x)[0]),4))

# OLS: patents ~ workshops + gov + interaction
X = sm.add_constant(pd.DataFrame({
    'workshops': x.astype(float),
    'gov': g.astype(float),
    'workshops_x_gov': x.astype(float)*g.astype(float)
}))
model = sm.OLS(y.astype(float), X).fit()
print('ols_r2', round(float(model.rsquared),4))
print('ols_coef_workshops', round(float(model.params['workshops']),6), 'p', round(float(model.pvalues['workshops']),6))
print('ols_coef_gov', round(float(model.params['gov']),6), 'p', round(float(model.pvalues['gov']),6))
print('ols_coef_interaction', round(float(model.params['workshops_x_gov']),6), 'p', round(float(model.pvalues['workshops_x_gov']),6))

# tertiles of government investment
try:
    tert = pd.qcut(g, 3, labels=['low','mid','high'], duplicates='drop')
except Exception:
    tert = pd.cut(g, 3, labels=['low','mid','high'])
for lab in tert.dropna().unique():
    m = tert == lab
    if m.sum() < 5:
        continue
    rr, pp = stats.pearsonr(x[m], y[m])
    print('gov_tertile', str(lab), 'n', int(m.sum()), 'pearson', round(float(rr),4), 'p', round(float(pp),6), 'mean_patents', round(float(y[m].mean()),4))
