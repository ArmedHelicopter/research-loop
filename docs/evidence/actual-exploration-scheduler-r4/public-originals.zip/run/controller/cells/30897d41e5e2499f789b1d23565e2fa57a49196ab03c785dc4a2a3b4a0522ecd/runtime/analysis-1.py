import pandas as pd
import numpy as np
from pathlib import Path

path = Path('/input/public_csv')
df = pd.read_csv(path)

def to_num(s):
    return pd.to_numeric(s, errors='coerce')

work = to_num(df['tech_workshops_frequency'])
pat = to_num(df['tech_patent_applications_per_1000'])
gov = to_num(df['government_investment'])
urb_raw = df['urban_area']

def is_urban(x):
    if pd.isna(x):
        return np.nan
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    s = str(x).strip().lower()
    if s in {'1', 'true', 'yes', 'y', 'urban'}:
        return True
    if s in {'0', 'false', 'no', 'n', 'rural', 'non-urban', 'nonurban'}:
        return False
    try:
        return float(s) > 0
    except Exception:
        return np.nan

urban = urb_raw.map(is_urban)
base = pd.DataFrame({'work': work, 'pat': pat, 'gov': gov, 'urban': urban}).dropna()

u = base[base['urban'] == True]
n = base[base['urban'] == False]

def corr_pair(a, b):
    if len(a) < 3:
        return np.nan, np.nan
    return float(a.corr(b, method='pearson')), float(a.corr(b, method='spearman'))

print('n_total', len(base), 'n_urban', len(u), 'n_nonurban', len(n))
print('urban_mean_workshops', round(u['work'].mean(), 4), 'urban_mean_patents', round(u['pat'].mean(), 4))
print('nonurban_mean_workshops', round(n['work'].mean(), 4) if len(n) else None, 'nonurban_mean_patents', round(n['pat'].mean(), 4) if len(n) else None)

rp, rs = corr_pair(u['work'], u['pat'])
print('urban_pearson_workshops_patents', round(rp, 4) if pd.notna(rp) else None, 'spearman', round(rs, 4) if pd.notna(rs) else None)
rp2, rs2 = corr_pair(n['work'], n['pat']) if len(n) else (np.nan, np.nan)
print('nonurban_pearson_workshops_patents', round(rp2, 4) if pd.notna(rp2) else None, 'spearman', round(rs2, 4) if pd.notna(rs2) else None)
rpg, rsg = corr_pair(u['gov'], u['pat'])
print('urban_pearson_gov_patents', round(rpg, 4) if pd.notna(rpg) else None)
rpw, rsw = corr_pair(u['work'], u['gov'])
print('urban_pearson_workshops_gov', round(rpw, 4) if pd.notna(rpw) else None)

if len(u) >= 9:
    u = u.copy()
    u['gov_tertile'] = pd.qcut(u['gov'], 3, duplicates='drop')
    for i, (lab, g) in enumerate(u.groupby('gov_tertile', observed=True)):
        rp_t, rs_t = corr_pair(g['work'], g['pat'])
        print('urban_gov_tertile', i+1, 'n', len(g), 'gov_range', round(g['gov'].min(), 3), round(g['gov'].max(), 3),
              'pearson_work_pat', round(rp_t, 4) if pd.notna(rp_t) else None,
              'mean_patents', round(g['pat'].mean(), 4), 'mean_workshops', round(g['work'].mean(), 4))

# OLS: pat ~ work + gov + work*gov on urban

def ols(y, X):
    X = np.column_stack([np.ones(len(X))] + list(X.T) if False else np.c_[np.ones(len(y)), X])
    yv = np.asarray(y, dtype=float)
    XtX = X.T @ X
    try:
        beta = np.linalg.solve(XtX, X.T @ yv)
    except np.linalg.LinAlgError:
        beta = np.linalg.lstsq(X, yv, rcond=None)[0]
    resid = yv - X @ beta
    nobs, k = X.shape
    dof = max(nobs - k, 1)
    sigma2 = float(resid @ resid) / dof
    try:
        cov = sigma2 * np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        cov = sigma2 * np.linalg.pinv(XtX)
    se = np.sqrt(np.clip(np.diag(cov), 0, None))
    t = beta / np.where(se == 0, np.nan, se)
    r2 = 1 - float(resid @ resid) / float(((yv - yv.mean()) ** 2).sum()) if nobs > 1 else np.nan
    return beta, se, t, r2, nobs

if len(u) >= 8:
    X = np.column_stack([u['work'].values, u['gov'].values, u['work'].values * u['gov'].values])
    beta, se, t, r2, nobs = ols(u['pat'].values, X)
    names = ['intercept', 'workshops', 'gov_investment', 'workshops_x_gov']
    print('urban_ols_r2', round(r2, 4), 'n', nobs)
    for name, b, s, tv in zip(names, beta, se, t):
        print('urban_ols', name, 'coef', round(float(b), 6), 'se', round(float(s), 6), 't', round(float(tv), 3) if pd.notna(tv) else None)

if len(base) >= 8:
    urb_i = base['urban'].astype(int).values
    Xf = np.column_stack([
        base['work'].values,
        base['gov'].values,
        urb_i,
        base['work'].values * urb_i,
        base['work'].values * base['gov'].values,
    ])
    beta, se, t, r2, nobs = ols(base['pat'].values, Xf)
    names = ['intercept', 'workshops', 'gov_investment', 'urban', 'workshops_x_urban', 'workshops_x_gov']
    print('full_ols_r2', round(r2, 4), 'n', nobs)
    for name, b, s, tv in zip(names, beta, se, t):
        print('full_ols', name, 'coef', round(float(b), 6), 'se', round(float(s), 6), 't', round(float(tv), 3) if pd.notna(tv) else None)
