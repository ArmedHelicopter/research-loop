# frozen diagnostic: shape-header-row-count
import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    row_count = sum(1 for _ in reader)
print(json.dumps({'header': header, 'row_count': row_count}, sort_keys=True))
