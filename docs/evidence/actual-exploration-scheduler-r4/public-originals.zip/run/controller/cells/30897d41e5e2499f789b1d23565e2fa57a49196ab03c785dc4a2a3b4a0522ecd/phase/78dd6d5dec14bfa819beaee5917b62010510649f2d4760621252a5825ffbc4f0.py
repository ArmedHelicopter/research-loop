# frozen diagnostic: ordinary-nonempty-cell-counts
import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    counts = [0 for _ in header]
    for row in reader:
        for index, value in enumerate(row[:len(counts)]):
            if value.strip(): counts[index] += 1
print(json.dumps({'header': header, 'nonempty_by_column': counts}, sort_keys=True))
