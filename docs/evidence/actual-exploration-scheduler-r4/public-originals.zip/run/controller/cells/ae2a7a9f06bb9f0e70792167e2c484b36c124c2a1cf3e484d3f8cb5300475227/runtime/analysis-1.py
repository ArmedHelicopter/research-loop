import pandas as pd
import numpy as np
from pathlib import Path

path = Path('/input/public_csv')
if not path.exists():
    path = Path('/input/data.csv')
df = pd.read_csv(path)

# normalize urban flag
u = df['urban_area']
if u.dtype == object:
    urban = u.astype(str).str.strip().str.lower().isin(['1','true','yes','urban','y'])
else:
    urban = u.fillna(0).astype(float) != 0

work = 'tech_workshops_frequency'
pat = 'tech_patent_applications_per_1000'
inv = 'government_investment'

sub = df.loc[urban, [work, pat, inv]].apply(pd.to_numeric, errors='coerce').dropna()
print(f'urban_n={len(sub)} total_n={len(df)}')

def pearson(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])

def spearman(a, b):
    return pearson(pd.Series(a).rank(), pd.Series(b).rank())

r = pearson(sub[work], sub[pat])
rs = spearman(sub[work], sub[pat])
print(f'urban_pearson_workshops_patents={r:.4f}')
print(f'urban_spearman_workshops_patents={rs:.4f}')
print(f'urban_pearson_investment_patents={pearson(sub[inv], sub[pat]):.4f}')
print(f'urban_pearson_investment_workshops={pearson(sub[inv], sub[work]):.4f}')

# residual association after linear control for investment
X = np.column_stack([np.ones(len(sub)), sub[inv].values])
beta, *_ = np.linalg.lstsq(X, sub[pat].values, rcond=None)
resid = sub[pat].values - X @ beta
print(f'urban_pearson_workshops_patents_resid_on_investment={pearson(sub[work], resid):.4f}')

# tertiles of government investment
try:
    bands = pd.qcut(sub[inv], 3, labels=['low','mid','high'], duplicates='drop')
except Exception:
    bands = pd.cut(sub[inv], 3, labels=['low','mid','high'])
for lab in list(bands.dropna().unique()):
    g = sub[bands == lab]
    print(f'urban_inv_{lab}_n={len(g)} pearson={pearson(g[work], g[pat]):.4f} spearman={spearman(g[work], g[pat]):.4f} mean_patents={g[pat].mean():.3f} mean_workshops={g[work].mean():.3f}')

# OLS patents ~ workshops + investment + interaction (centered)
w = sub[work].values; i = sub[inv].values; y = sub[pat].values
wc, ic = w - w.mean(), i - i.mean()
X2 = np.column_stack([np.ones(len(sub)), wc, ic, wc * ic])
coef, *_ = np.linalg.lstsq(X2, y, rcond=None)
print(f'ols_intercept={coef[0]:.4f} ols_workshops={coef[1]:.4f} ols_investment={coef[2]:.4f} ols_interaction={coef[3]:.4f}')
# r2
pred = X2 @ coef
ss_res = ((y - pred)**2).sum(); ss_tot = ((y - y.mean())**2).sum()
print(f'ols_r2={1 - ss_res/ss_tot if ss_tot else np.nan:.4f}')
print(f'mean_patents_urban={y.mean():.3f} mean_workshops_urban={w.mean():.3f} mean_investment_urban={i.mean():.3f}')
