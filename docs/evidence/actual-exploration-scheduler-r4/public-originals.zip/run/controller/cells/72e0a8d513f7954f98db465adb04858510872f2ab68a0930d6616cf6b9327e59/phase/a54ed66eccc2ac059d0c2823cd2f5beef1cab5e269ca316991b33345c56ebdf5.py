# frozen diagnostic: probe-missing-and-duplicate-rows
import csv, json
with open('/input/public_csv', newline='', encoding='utf-8') as stream:
    reader = csv.reader(stream)
    header = next(reader, [])
    rows = list(reader)
missing_cells = sum(1 for row in rows for value in row if not value.strip())
duplicate_rows = len(rows) - len({tuple(row) for row in rows})
print(json.dumps({'header': header, 'missing_cells': missing_cells, 'duplicate_rows': duplicate_rows}, sort_keys=True))
