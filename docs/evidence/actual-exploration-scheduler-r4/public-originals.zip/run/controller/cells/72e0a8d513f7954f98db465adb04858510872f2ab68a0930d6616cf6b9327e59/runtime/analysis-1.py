import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.api as sm

df = pd.read_csv("/input/public_csv")

# normalize urban flag
u = df["urban_area"]
if u.dtype == object:
    urban_mask = u.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "urban"])
else:
    urban_mask = u.astype(float) == 1

urban = df.loc[urban_mask, [
    "tech_workshops_frequency",
    "tech_patent_applications_per_1000",
    "government_investment",
]].dropna()

n = len(urban)
w = urban["tech_workshops_frequency"]
p = urban["tech_patent_applications_per_1000"]
g = urban["government_investment"]

r_wp, p_wp = stats.pearsonr(w, p)
r_wg, p_wg = stats.pearsonr(w, g)
r_pg, p_pg = stats.pearsonr(p, g)

print(f"urban_n={n}")
print(f"pearson_workshops_patents r={r_wp:.4f} p={p_wp:.4g}")
print(f"pearson_workshops_govinv r={r_wg:.4f} p={p_wg:.4g}")
print(f"pearson_patents_govinv r={r_pg:.4f} p={p_pg:.4g}")

urban = urban.copy()
urban["gov_tertile"] = pd.qcut(g, 3, labels=["low", "mid", "high"], duplicates="drop")
print("stratified_pearson_workshops_patents_by_gov_tertile:")
for lab, sub in urban.groupby("gov_tertile", observed=True):
    if len(sub) < 5:
        print(f"  {lab}: n={len(sub)} insufficient")
        continue
    rr, pp = stats.pearsonr(sub["tech_workshops_frequency"], sub["tech_patent_applications_per_1000"])
    print(f"  {lab}: n={len(sub)} r={rr:.4f} p={pp:.4g} mean_patents={sub['tech_patent_applications_per_1000'].mean():.3f} mean_workshops={sub['tech_workshops_frequency'].mean():.3f}")

X = sm.add_constant(pd.DataFrame({
    "workshops": w.values,
    "gov_inv": g.values,
    "workshops_x_gov": (w.values * g.values),
}))
model = sm.OLS(p.values, X).fit()
print("ols_patents ~ workshops + gov_inv + workshops*gov_inv")
for name, coef, pv in zip(model.params.index, model.params.values, model.pvalues.values):
    print(f"  {name}: coef={coef:.6g} p={pv:.4g}")
print(f"  r2={model.rsquared:.4f} adj_r2={model.rsquared_adj:.4f}")
print("interpretation: workshops-patent association in urban rows; interaction tests whether government investment changes that slope.")
