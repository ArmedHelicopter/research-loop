#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_csv("/input/public_csv")
for c in ["num_amtl", "sockets", "age", "stdev_age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["prop"] = df["num_amtl"] / df["sockets"]
df["is_human"] = (df["genus"].astype(str).str.lower().str.contains("homo|human|sapiens")).astype(int)

print("n_rows", len(df), "n_specimens", df["specimen"].nunique())
print("genera", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())
print("mean_prop_by_genus", df.groupby("genus")["prop"].mean().round(4).to_dict())
print("mean_age_by_genus", df.groupby("genus")["age"].mean().round(2).to_dict())

endog = np.column_stack([df["num_amtl"], df["sockets"] - df["num_amtl"]])
# treatment contrast: Homo as reference if present
g = df["genus"].astype(str)
ref = None
for cand in ["Homo", "H. sapiens", "Homo sapiens", "human"]:
    if (g == cand).any():
        ref = cand
        break
if ref is None:
    # pick most frequent genus containing homo
    for u in g.unique():
        if "homo" in u.lower() or "sapien" in u.lower() or "human" in u.lower():
            ref = u
            break
if ref is None:
    ref = g.value_counts().index[0]
df["genus"] = pd.Categorical(g, categories=[ref] + [x for x in sorted(g.unique()) if x != ref])

formula = "prop ~ C(genus) + age + prob_male + C(tooth_class)"
mod = smf.glm(formula, data=df, family=sm.families.Binomial(), freq_weights=df["sockets"]).fit()
print("glm_converged", bool(mod.converged))
print("aic", round(float(mod.aic), 2))
params = mod.params
pvals = mod.pvalues
ci = mod.conf_int()
print("reference_genus", ref)
for name in params.index:
    if name == "Intercept" or name.startswith("C(genus)"):
        or_ = float(np.exp(params[name]))
        lo, hi = np.exp(ci.loc[name].values)
        print(f"term {name} coef={params[name]:.4f} OR={or_:.3f} CI=({lo:.3f},{hi:.3f}) p={pvals[name]:.4g}")
print("age_coef", round(float(params.get("age", np.nan)), 4), "p", float(pvals.get("age", np.nan)))
print("sex_coef", round(float(params.get("prob_male", np.nan)), 4), "p", float(pvals.get("prob_male", np.nan)))
# Wald test of all non-human genera jointly vs Homo
genus_terms = [t for t in params.index if t.startswith("C(genus)")]
if genus_terms:
    hyp = ", ".join([f"{t}=0" for t in genus_terms])
    w = mod.wald_test(hyp, scalar=True)
    print("joint_nonhuman_vs_ref_wald_p", float(w.pvalue))
# predicted rates at mean covariates
means = {"age": df["age"].mean(), "prob_male": df["prob_male"].mean()}
tc = df["tooth_class"].mode().iloc[0]
print("adj_pred_at_mean_age_sex_modal_tooth")
for gen in df["genus"].cat.categories:
    nd = pd.DataFrame({"genus": [gen], "age": [means["age"]], "prob_male": [means["prob_male"]], "tooth_class": [tc]})
    pred = float(mod.predict(nd).iloc[0])
    print(gen, round(pred, 4))
