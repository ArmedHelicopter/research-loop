#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
from pathlib import Path

path = Path("/input/public_csv")
df = pd.read_csv(path)
for c in ["num_amtl", "sockets", "age", "stdev_age", "prob_male"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["num_amtl", "sockets", "age", "prob_male", "genus", "tooth_class"])
df = df[df["sockets"] > 0].copy()
df["num_amtl"] = df["num_amtl"].clip(lower=0)
df.loc[df["num_amtl"] > df["sockets"], "num_amtl"] = df.loc[df["num_amtl"] > df["sockets"], "sockets"]
df["rate"] = df["num_amtl"] / df["sockets"]
df["is_human"] = (df["genus"].astype(str).str.lower().str.contains("homo|sapiens|human")).astype(int)
# crude genus flags if not already human
print("N_rows", len(df), "N_specimens", df["specimen"].nunique())
print("genera", df["genus"].value_counts().to_dict())
print("tooth_class", df["tooth_class"].value_counts().to_dict())
print("mean_rate_by_genus", df.groupby("genus")["rate"].mean().round(4).to_dict())
print("mean_rate_human_vs_other", {"human": float(df.loc[df.is_human==1, "rate"].mean()), "other": float(df.loc[df.is_human==0, "rate"].mean())})
print("mean_age_by_human", df.groupby("is_human")["age"].mean().round(2).to_dict())

tooth_d = pd.get_dummies(df["tooth_class"].astype(str), prefix="tc", drop_first=True, dtype=float)
X = pd.concat([
    df[["age", "prob_male", "is_human"]].astype(float),
    tooth_d,
], axis=1)
X = sm.add_constant(X)
y = df["num_amtl"].astype(int)
n = df["sockets"].astype(int)
endog = np.column_stack([y, n - y])
mod = sm.GLM(endog, X, family=sm.families.Binomial())
try:
    res = mod.fit(cov_type="cluster", cov_kwds={"groups": df["specimen"].astype(str)})
except Exception:
    res = mod.fit()
print("glm_converged", bool(res.converged))
params = res.params
pvals = res.pvalues
ci = res.conf_int()
print("coef_is_human", float(params.get("is_human", np.nan)))
print("or_is_human", float(np.exp(params.get("is_human", np.nan))))
print("pval_is_human", float(pvals.get("is_human", np.nan)))
print("ci95_is_human", [float(ci.loc["is_human", 0]), float(ci.loc["is_human", 1])] if "is_human" in ci.index else None)
print("coef_age", float(params.get("age", np.nan)), "pval_age", float(pvals.get("age", np.nan)))
print("coef_prob_male", float(params.get("prob_male", np.nan)), "pval_prob_male", float(pvals.get("prob_male", np.nan)))
# genus-level vs Pan reference if multiple genera
g = pd.get_dummies(df["genus"].astype(str), prefix="g", drop_first=True, dtype=float)
Xg = pd.concat([df[["age", "prob_male"]].astype(float), tooth_d, g], axis=1)
Xg = sm.add_constant(Xg)
resg = sm.GLM(endog, Xg, family=sm.families.Binomial()).fit()
human_cols = [c for c in resg.params.index if "homo" in c.lower() or "sapien" in c.lower() or "human" in c.lower()]
print("genus_model_human_related_coefs", {c: {"coef": float(resg.params[c]), "or": float(np.exp(resg.params[c])), "p": float(resg.pvalues[c])} for c in human_cols})
print("higher_human_amtl_after_controls", bool(params.get("is_human", 0) > 0 and pvals.get("is_human", 1) < 0.05))
